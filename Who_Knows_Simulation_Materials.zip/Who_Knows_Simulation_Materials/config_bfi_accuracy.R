# ==============================================================================
# config_bfi_accuracy.R
# Settings for Simulation 2: generalized negativity x distinctive accuracy
# ============================================================================== 
#
# Source this AFTER config.R. The general Who Knows engagement settings in
# config.R are reused here; this file only adds settings specific to the BFI-30
# simulation.


# ------------------------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------------------------

SEED_BFI_DESIGN <- 20260926L
SEED_BFI_SIMULATION <- 20260927L


# ------------------------------------------------------------------------------
# BFI-30 design
# ------------------------------------------------------------------------------

BFI_N_ITEMS <- 30L
BFI_ITEMS_PER_ROUND <- 1L
BFI_RESPONSE_MIN <- 1L
BFI_RESPONSE_MAX <- 5L

# One BFI item is shown in every normal Who Knows round. Across successive
# blocks of 30 BFI trials for a user, all 30 BFI items are sampled once before
# an item is repeated, subject to the small amount of missing target data.
BFI_SAMPLE_ITEMS_WITHOUT_REPLACEMENT <- TRUE


# ------------------------------------------------------------------------------
# Calibration files
# ------------------------------------------------------------------------------

BFI_ITEM_PARAMETERS_FILE <- here::here(
  "data",
  "calibration",
  "bfi30_item_parameters.csv"
)

BFI_TARGET_RESPONSES_FILE <- here::here(
  "data",
  "calibration",
  "bfi30_target_responses_long.csv"
)


# ------------------------------------------------------------------------------
# Empirical DGP calibration
# ------------------------------------------------------------------------------
#
# The historical Who Knows calibration used 1-10 judgments. The planned BFI
# judgments use the original 1-5 response scale. Outcome-scale parameters are
# therefore multiplied by 4/9, the endpoint-preserving linear rescaling from
# 1-10 to 1-5.
#
# Historical 1-10 estimates:
#   SD(response-style intercept R) = 0.310
#   SD(negativity N)                = 0.185
#   mean distinctive accuracy      = 0.302
#   SD(distinctive accuracy A)      = 0.111
#   residual SD                     = 2.249

BFI_SCALE_MULTIPLIER <- 4 / 9

BFI_SD_RESPONSE_STYLE <- 0.310 * BFI_SCALE_MULTIPLIER
BFI_SD_NEGATIVITY <- 0.185 * BFI_SCALE_MULTIPLIER
BFI_MEAN_ACCURACY_SLOPE <- 0.302 * BFI_SCALE_MULTIPLIER
BFI_SD_ACCURACY <- 0.111 * BFI_SCALE_MULTIPLIER
BFI_RESIDUAL_SD <- 2.249 * BFI_SCALE_MULTIPLIER

# The only person-level covariance manipulated in the DGP. Response style is
# independent of both negativity and distinctive accuracy.
BFI_RHO_NEGATIVITY_ACCURACY <- c(0, 0.15, 0.30)


# ------------------------------------------------------------------------------
# Outcome generation
# ------------------------------------------------------------------------------

# Generate a latent Gaussian judgment from the DGP, then round and restrict it
# to the actual 1-5 response categories used for the BFI judgments.
BFI_ROUND_TO_INTEGER <- TRUE
BFI_CLIP_TO_SCALE <- TRUE


# ------------------------------------------------------------------------------
# Monte Carlo settings
# ------------------------------------------------------------------------------

BFI_N_REP_PILOT <- 1L
BFI_N_REP_DEV <- 25L
BFI_N_REP_FINAL <- 200L

