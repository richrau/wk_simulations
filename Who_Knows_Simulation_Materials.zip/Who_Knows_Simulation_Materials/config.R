# ==============================================================================
# config.R
# Global settings for the DFG follow-up simulations
# ==============================================================================


# ------------------------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------------------------

SEED_DESIGN <- 20260918L
SEED_SIMULATION <- 20260919L
SEED_ITEM_PROPERTIES <- 20260920L


# ------------------------------------------------------------------------------
# Who Knows structure
# ------------------------------------------------------------------------------

N_TARGETS <- 75L
N_ITEMS <- 811L
JUDGMENTS_PER_ROUND <- 5L

# The empirical correctness model contained 6,026 observed target × item
# combinations. This corresponds to about 80 available items per target.
N_ITEM_TARGET_PAIRS <- 6026L
ITEMS_PER_TARGET <- 80L

# Targets are shown in randomized cycles: within each block of 75 rounds,
# each target is shown exactly once.
TARGETS_WITHOUT_REPLACEMENT <- TRUE


# ------------------------------------------------------------------------------
# Item types
# ------------------------------------------------------------------------------

# Empirical composition of the Who Knows item pool.
# Item type is assigned independently of target × item availability.

ITEM_TYPE_COUNTS <- c(
  knowledge = 307L,
  true_false = 213L,
  open = 154L,
  scale = 137L
)

stopifnot(sum(ITEM_TYPE_COUNTS) == N_ITEMS)


# ------------------------------------------------------------------------------
# Natural app engagement
# ------------------------------------------------------------------------------

# Future versions of the app are assumed not to contain sharp survey gates.
# We therefore use a smooth right-skewed distribution of total rounds played.
#
# These values are provisional and will be checked in 01_calibrate_design.R.
# They are chosen to approximate the broad engagement pattern in the historical
# data after smoothing over the survey-gate effects.

ENGAGEMENT_DISTRIBUTION <- "lognormal"

ENGAGEMENT_MEDIAN_ROUNDS <- 8
ENGAGEMENT_MEAN_ROUNDS <- 18

# Convert intuitive mean/median specifications to lognormal parameters.
ENGAGEMENT_MEANLOG <- log(ENGAGEMENT_MEDIAN_ROUNDS)
ENGAGEMENT_SDLOG <- sqrt(
  2 * log(ENGAGEMENT_MEAN_ROUNDS / ENGAGEMENT_MEDIAN_ROUNDS)
)

MIN_ROUNDS <- 1L

# Technical upper bound. This allows a long right tail while preventing
# extremely large simulated user histories.
MAX_ROUNDS <- 500L


# ------------------------------------------------------------------------------
# Empirical calibration: correctness model
# ------------------------------------------------------------------------------

CORRECTNESS_CALIBRATION_FILE <- here::here(
  "data",
  "calibration",
  "correctness_parameters.csv"
)

correctness_calibration <- read.csv(
  CORRECTNESS_CALIBRATION_FILE,
  stringsAsFactors = FALSE
)

get_correctness_parameter <- function(parameter_name) {
  value <- correctness_calibration$estimate[
    correctness_calibration$parameter == parameter_name
  ]

  if (length(value) != 1L) {
    stop(
      "Expected exactly one calibration value for parameter: ",
      parameter_name
    )
  }

  value
}


# Random-effect SDs on the logistic latent scale.

SD_USER <- get_correctness_parameter("sd_user")
SD_ITEM <- get_correctness_parameter("sd_item")
SD_TARGET <- get_correctness_parameter("sd_target")
SD_ITEM_TARGET <- get_correctness_parameter("sd_item_target")
SD_ITEM_USER <- get_correctness_parameter("sd_item_user")
SD_TARGET_USER <- get_correctness_parameter("sd_target_user")


# Fixed effects from the same empirical model.
#
# These are retained as empirical reference values. We will decide in
# simulate_correctness.R which of them need to enter a given data-generating
# process.

CORRECTNESS_INTERCEPT <- get_correctness_parameter("intercept")

B_ITEM_TYPE_OPEN <- get_correctness_parameter("item_type_open")
B_ITEM_TYPE_SCALE <- get_correctness_parameter("item_type_scale")
B_ITEM_TYPE_TRUE_FALSE <- get_correctness_parameter("item_type_true_false")

B_LOG_PLAYED_GAMES <- get_correctness_parameter("log1p_played_games")
B_LOG_TARGET_REPETITION <- get_correctness_parameter(
  "log1p_target_repetition"
)
B_LOG_ITEM_REPETITION <- get_correctness_parameter(
  "log1p_item_repetition"
)


# ------------------------------------------------------------------------------
# Design-check settings
# ------------------------------------------------------------------------------

# Large synthetic sample used only to inspect whether the generated design
# has the intended properties. This is not a planned study sample size.
N_USERS_DESIGN_CHECK <- 5000L


# ------------------------------------------------------------------------------
# Monte Carlo settings
# ------------------------------------------------------------------------------

# Start cheaply while developing/debugging. We can increase this for the
# final simulations once everything is stable.
N_REP_DEV <- 50L
N_REP_FINAL <- 200L

# ------------------------------------------------------------------------------
# Focal correctness effect
# ------------------------------------------------------------------------------

# Association between standardized generalized negativity and the latent
# person-level tendency to make correct judgments.
#
# The effect is parameterized as a correlation with the total user-level
# accuracy propensity. This preserves the empirically calibrated total
# between-user SD (SD_USER).

RHO_NEGATIVITY_ACCURACY_DEV <- 0.20

RHO_NEGATIVITY_ACCURACY_SCENARIOS <- c(
  0.00,
  0.15,
  0.30
)
