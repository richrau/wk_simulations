# ==============================================================================
# helpers/simulate_bfi_moderation.R
# DGP for Simulation 2: baseline negativity as moderator of distinctive accuracy
# ==============================================================================
#
# Core model:
#
#   Y_pit = alpha_i + R_p - b_ND * N_p * D_i
#            + (beta_C + b_NA * N_p + U_Ap) * C_it + epsilon_pit
#
# where:
#   alpha_i = calibrated mean judge response for item i
#   R_p     = general numerical response-style tendency
#   N_p     = standardized baseline negativity score
#   D_i     = standardized signed item desirability
#   beta_C  = average distinctive-accuracy slope
#   b_NA    = fixed negativity x criterion interaction
#   U_Ap    = residual person-specific distinctive-accuracy deviation
#   C_it    = target response centered within item and pooled-standardized
#
# The simulation parameter rho_negativity_accuracy is translated into b_NA via
#
#   b_NA = rho * SD(A)
#
# and the residual accuracy SD is reduced to
#
#   SD(U_A) = SD(A) * sqrt(1 - rho^2)
#
# so that the total SD of person-specific accuracy remains constant at the
# empirical calibration value BFI_SD_ACCURACY.


simulate_bfi_moderation <- function(
  design,
  item_parameters,
  rho_negativity_accuracy,
  keep_components = FALSE
) {

  required_design_cols <- c(
    "user_id",
    "round",
    "target_id",
    "item_id",
    "criterion_raw",
    "criterion_z"
  )

  required_item_cols <- c(
    "item_id",
    "desirability_z",
    "judge_mean_pred"
  )

  if (!all(required_design_cols %in% names(design))) {
    stop(
      "design must contain: ",
      paste(required_design_cols, collapse = ", ")
    )
  }

  if (!all(required_item_cols %in% names(item_parameters))) {
    stop(
      "item_parameters must contain: ",
      paste(required_item_cols, collapse = ", ")
    )
  }

  if (
    length(rho_negativity_accuracy) != 1L ||
    !is.finite(rho_negativity_accuracy) ||
    abs(rho_negativity_accuracy) >= 1
  ) {
    stop("rho_negativity_accuracy must lie strictly between -1 and 1.")
  }

  # --------------------------------------------------------------------------
  # Add fixed item parameters
  # --------------------------------------------------------------------------

  dat <- merge(
    design,
    item_parameters[, required_item_cols],
    by = "item_id",
    all.x = TRUE,
    sort = FALSE
  )

  dat <- dat[order(dat$user_id, dat$round), ]
  rownames(dat) <- NULL

  if (anyNA(dat$desirability_z) || anyNA(dat$judge_mean_pred)) {
    stop("Missing item calibration values after merging item parameters.")
  }

  # --------------------------------------------------------------------------
  # Generate person-level components
  # --------------------------------------------------------------------------

  user_ids <- sort(unique(dat$user_id))
  n_users <- length(user_ids)

  # Baseline negativity is standardized and, for this first simulation, treated
  # as measured without error. Reliability sensitivity can be added later.
  negativity_z <- rnorm(n_users)

  # Translate the desired latent correlation into a fixed moderation effect.
  beta_negativity_accuracy <- (
    rho_negativity_accuracy * BFI_SD_ACCURACY
  )

  residual_accuracy_sd <- (
    BFI_SD_ACCURACY *
      sqrt(1 - rho_negativity_accuracy^2)
  )

  response_style <- rnorm(
    n = n_users,
    mean = 0,
    sd = BFI_SD_RESPONSE_STYLE
  )

  accuracy_residual <- rnorm(
    n = n_users,
    mean = 0,
    sd = residual_accuracy_sd
  )

  total_accuracy_deviation <- (
    beta_negativity_accuracy * negativity_z +
      accuracy_residual
  )

  user_effects <- data.frame(
    user_id = user_ids,
    negativity_z = negativity_z,
    response_style = response_style,
    accuracy_residual = accuracy_residual,
    total_accuracy_deviation = total_accuracy_deviation
  )

  dat <- merge(
    dat,
    user_effects,
    by = "user_id",
    all.x = TRUE,
    sort = FALSE
  )

  dat <- dat[order(dat$user_id, dat$round), ]
  rownames(dat) <- NULL

  # --------------------------------------------------------------------------
  # Generate judgments
  # --------------------------------------------------------------------------

  dat$accuracy_slope <- (
    BFI_MEAN_ACCURACY_SLOPE +
      dat$total_accuracy_deviation
  )

  dat$mu <- (
    dat$judge_mean_pred +
      dat$response_style -
      BFI_SD_NEGATIVITY *
        dat$negativity_z *
        dat$desirability_z +
      dat$accuracy_slope *
        dat$criterion_z
  )

  dat$judgment_latent <- rnorm(
    n = nrow(dat),
    mean = dat$mu,
    sd = BFI_RESIDUAL_SD
  )

  dat$judgment <- dat$judgment_latent

  if (isTRUE(BFI_ROUND_TO_INTEGER)) {
    dat$judgment <- round(dat$judgment)
  }

  if (isTRUE(BFI_CLIP_TO_SCALE)) {
    dat$judgment <- pmin(
      BFI_RESPONSE_MAX,
      pmax(BFI_RESPONSE_MIN, dat$judgment)
    )
  }

  # --------------------------------------------------------------------------
  # Return compact or diagnostic dataset
  # --------------------------------------------------------------------------

  if (!isTRUE(keep_components)) {
    keep <- c(
      "user_id",
      "round",
      "target_id",
      "item_id",
      "criterion_raw",
      "criterion_z",
      "desirability_z",
      "negativity_z",
      "judgment"
    )

    dat <- dat[, keep]
  }

  attr(dat, "rho_negativity_accuracy") <- rho_negativity_accuracy
  attr(dat, "beta_negativity_accuracy") <- beta_negativity_accuracy
  attr(dat, "residual_accuracy_sd") <- residual_accuracy_sd

  dat
}
