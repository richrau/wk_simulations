# ==============================================================================
# helpers/simulate_metacognition.R
# Simulation 3 helpers: three-point confidence
# FIX: preserve generating-value attributes after compacting the data frame
# ==============================================================================

generate_metacognition_design <- function(
  n_users,
  n_pre_rounds,
  n_post_rounds = 0L,
  availability_matrix,
  judgments_per_round = META_JUDGMENTS_PER_ROUND
) {

  n_users <- as.integer(n_users)
  n_pre_rounds <- as.integer(n_pre_rounds)
  n_post_rounds <- as.integer(n_post_rounds)

  if (n_users < 1L) stop("n_users must be positive.")
  if (n_pre_rounds < 1L || n_post_rounds < 0L) {
    stop("Invalid number of module rounds.")
  }

  n_rounds <- n_pre_rounds + n_post_rounds

  if (
    !is.matrix(availability_matrix) ||
    nrow(availability_matrix) != N_TARGETS ||
    ncol(availability_matrix) != N_ITEMS
  ) {
    stop("availability_matrix has the wrong dimensions.")
  }

  if (any(rowSums(availability_matrix) < judgments_per_round)) {
    stop("Some targets have too few available items.")
  }

  user_id <- rep(
    seq_len(n_users),
    each = n_rounds
  )

  round_number <- rep.int(
    seq_len(n_rounds),
    times = n_users
  )

  target_id <- unlist(
    replicate(
      n = n_users,
      expr = assign_targets(
        n_rounds = n_rounds,
        n_targets = N_TARGETS
      ),
      simplify = FALSE
    ),
    use.names = FALSE
  )

  round_design <- data.frame(
    user_id = user_id,
    round = round_number,
    target_id = target_id
  )

  available_items <- lapply(
    seq_len(N_TARGETS),
    function(target) which(availability_matrix[target, ])
  )

  sampled_items <- lapply(
    round_design$target_id,
    function(target) {
      candidates <- available_items[[target]]
      candidates[
        sample.int(
          length(candidates),
          size = judgments_per_round,
          replace = FALSE
        )
      ]
    }
  )

  item_matrix <- do.call(rbind, sampled_items)

  dat <- data.frame(
    user_id = rep(round_design$user_id, each = judgments_per_round),
    round = rep(round_design$round, each = judgments_per_round),
    target_id = rep(round_design$target_id, each = judgments_per_round),
    judgment_within_round = rep.int(
      seq_len(judgments_per_round),
      times = nrow(round_design)
    ),
    item_id = as.vector(t(item_matrix))
  )

  dat$post <- as.integer(dat$round > n_pre_rounds)

  dat$phase <- factor(
    ifelse(dat$post == 1L, "post", "pre"),
    levels = c("pre", "post")
  )

  rownames(dat) <- NULL
  dat
}


generate_three_point_confidence <- function(
  dat,
  randomized_feedback
) {

  user_ids <- sort(unique(dat$user_id))
  n_users <- length(user_ids)

  general_confidence <- rnorm(
    n_users,
    mean = 0,
    sd = META_SD_GENERAL_CONFIDENCE
  )

  if (isTRUE(randomized_feedback)) {
    feedback_condition <- sample(
      rep(c(0L, 1L), length.out = n_users),
      size = n_users,
      replace = FALSE
    )
  } else {
    feedback_condition <- rep.int(0L, n_users)
  }

  person_table <- data.frame(
    user_id = user_ids,
    general_confidence = general_confidence,
    feedback_condition_num = feedback_condition
  )

  dat <- merge(
    dat,
    person_table,
    by = "user_id",
    all.x = TRUE,
    sort = FALSE
  )

  dat <- dat[
    order(dat$user_id, dat$round, dat$judgment_within_round),
  ]
  rownames(dat) <- NULL

  dat$confidence_latent <- (
    dat$general_confidence +
      rnorm(
        nrow(dat),
        mean = 0,
        sd = META_SD_TRIAL_CONFIDENCE
      )
  )

  lower_cut <- META_CONFIDENCE_THRESHOLDS[1]
  upper_cut <- META_CONFIDENCE_THRESHOLDS[2]

  dat$confidence <- ifelse(
    dat$confidence_latent <= lower_cut,
    1L,
    ifelse(dat$confidence_latent <= upper_cut, 2L, 3L)
  )

  dat$feedback_condition <- factor(
    dat$feedback_condition_num,
    levels = c(0, 1),
    labels = c("control", "feedback")
  )

  dat
}


add_confidence_decomposition <- function(dat) {

  phase_key <- interaction(
    dat$user_id,
    dat$phase,
    drop = TRUE
  )

  dat$confidence_pm_phase <- ave(
    dat$confidence,
    phase_key,
    FUN = mean
  )

  dat$confidence_wc_phase <- (
    dat$confidence -
      dat$confidence_pm_phase
  )

  dat
}


add_metacognitive_correctness <- function(
  dat,
  rho_negativity_sensitivity,
  feedback_delta
) {

  if (
    length(rho_negativity_sensitivity) != 1L ||
    !is.finite(rho_negativity_sensitivity) ||
    abs(rho_negativity_sensitivity) >= 1
  ) {
    stop("rho_negativity_sensitivity must lie strictly between -1 and 1.")
  }

  if (
    length(feedback_delta) != 1L ||
    !is.finite(feedback_delta)
  ) {
    stop("feedback_delta must be a single finite value.")
  }

  user_ids <- sort(unique(dat$user_id))
  n_users <- length(user_ids)

  negativity_by_user <- tapply(
    dat$negativity_z,
    dat$user_id,
    function(x) x[1]
  )

  negativity_by_user <- as.numeric(
    negativity_by_user[as.character(user_ids)]
  )

  beta_negativity_sensitivity <- (
    rho_negativity_sensitivity *
      META_SD_SENSITIVITY
  )

  residual_sensitivity_sd <- (
    META_SD_SENSITIVITY *
      sqrt(1 - rho_negativity_sensitivity^2)
  )

  sensitivity_residual <- rnorm(
    n_users,
    mean = 0,
    sd = residual_sensitivity_sd
  )

  person_table <- data.frame(
    user_id = user_ids,
    negativity_z_person = negativity_by_user,
    sensitivity_residual = sensitivity_residual
  )

  dat <- merge(
    dat,
    person_table,
    by = "user_id",
    all.x = TRUE,
    sort = FALSE
  )

  dat <- dat[
    order(dat$user_id, dat$round, dat$judgment_within_round),
  ]
  rownames(dat) <- NULL

  dat$sensitivity_pre <- (
    META_MEAN_SENSITIVITY +
      beta_negativity_sensitivity *
        dat$negativity_z_person +
      dat$sensitivity_residual
  )

  dat$sensitivity_current <- (
    dat$sensitivity_pre +
      feedback_delta *
        dat$feedback_condition_num *
        dat$post
  )

  dat$linear_predictor_meta <- (
    dat$linear_predictor +
      dat$sensitivity_current *
        dat$confidence_wc_phase
  )

  dat$p_correct_meta <- plogis(
    dat$linear_predictor_meta
  )

  dat$is_correct <- rbinom(
    nrow(dat),
    size = 1L,
    prob = dat$p_correct_meta
  )

  dat$item_target_id <- interaction(
    dat$item_id,
    dat$target_id,
    drop = TRUE
  )

  attr(dat, "beta_negativity_sensitivity") <- beta_negativity_sensitivity
  attr(dat, "feedback_delta") <- feedback_delta

  dat
}


simulate_metacognition_dataset <- function(
  n_users,
  n_pre_rounds,
  n_post_rounds = 0L,
  availability_matrix,
  item_properties,
  rho_negativity_sensitivity = 0,
  feedback_delta = 0,
  randomized_feedback = FALSE,
  keep_components = FALSE
) {

  design <- generate_metacognition_design(
    n_users = n_users,
    n_pre_rounds = n_pre_rounds,
    n_post_rounds = n_post_rounds,
    availability_matrix = availability_matrix
  )

  dat <- simulate_correctness(
    design = design,
    item_properties = item_properties,
    include_exposure_effects = TRUE,
    rho_negativity_accuracy = 0,
    keep_components = TRUE
  )

  dat <- generate_three_point_confidence(
    dat = dat,
    randomized_feedback = randomized_feedback
  )

  dat <- add_confidence_decomposition(dat)

  dat <- add_metacognitive_correctness(
    dat = dat,
    rho_negativity_sensitivity = rho_negativity_sensitivity,
    feedback_delta = feedback_delta
  )

  # Store generating values BEFORE any data-frame subsetting.
  beta_true <- rho_negativity_sensitivity * META_SD_SENSITIVITY
  delta_true <- feedback_delta

  if (!isTRUE(keep_components)) {

    keep <- c(
      "user_id",
      "round",
      "target_id",
      "item_id",
      "item_target_id",
      "judgment_within_round",
      "item_type",
      "played_games",
      "target_repetition",
      "item_repetition",
      "phase",
      "post",
      "negativity_z_person",
      "feedback_condition",
      "confidence",
      "confidence_pm_phase",
      "confidence_wc_phase",
      "is_correct"
    )

    dat <- dat[, keep]
  }

  # Reattach after subsetting so downstream code cannot receive NULL.
  attr(dat, "beta_negativity_sensitivity") <- beta_true
  attr(dat, "feedback_delta") <- delta_true

  dat
}
