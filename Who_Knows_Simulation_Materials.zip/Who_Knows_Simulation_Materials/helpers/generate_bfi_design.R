# ==============================================================================
# helpers/generate_bfi_design.R
# Generate the BFI-30 trial structure for Simulation 2
# ============================================================================== 
#
# Assumes config.R and config_bfi_accuracy.R have already been sourced.
# Also assumes helpers/generate_design.R has been sourced so that
# draw_round_counts() is available.


# ------------------------------------------------------------------------------
# Target sequence: randomized cycles without replacement
# ------------------------------------------------------------------------------

assign_bfi_targets <- function(n_rounds, eligible_target_ids) {

  if (length(n_rounds) != 1L || n_rounds < 0L) {
    stop("n_rounds must be a single non-negative integer.")
  }

  eligible_target_ids <- as.integer(eligible_target_ids)
  n_rounds <- as.integer(n_rounds)

  if (length(eligible_target_ids) < 1L) {
    stop("eligible_target_ids must contain at least one target.")
  }

  if (n_rounds == 0L) {
    return(integer(0))
  }

  n_targets <- length(eligible_target_ids)
  n_full_cycles <- n_rounds %/% n_targets
  n_remaining <- n_rounds %% n_targets

  out <- integer(0)

  if (n_full_cycles > 0L) {
    out <- unlist(
      replicate(
        n = n_full_cycles,
        expr = sample(eligible_target_ids, size = n_targets, replace = FALSE),
        simplify = FALSE
      ),
      use.names = FALSE
    )
  }

  if (n_remaining > 0L) {
    out <- c(
      out,
      sample(eligible_target_ids, size = n_remaining, replace = FALSE)
    )
  }

  out
}


# ------------------------------------------------------------------------------
# Assign one BFI item per round
# ------------------------------------------------------------------------------

assign_bfi_items_for_user <- function(
  target_ids,
  available_items_by_target,
  item_ids,
  max_attempts = 200L
) {

  n_rounds <- length(target_ids)

  if (n_rounds == 0L) {
    return(integer(0))
  }

  item_ids <- as.integer(item_ids)
  out <- integer(n_rounds)

  # Within each block of at most 30 BFI trials, use each BFI item at most once.
  # Some legacy targets have incomplete BFI self-reports. We therefore solve
  # each block as a small constrained assignment problem, always assigning the
  # currently most constrained target-round first. If a random choice paints us
  # into a corner, the block is restarted.
  block_starts <- seq.int(1L, n_rounds, by = length(item_ids))

  for (block_start in block_starts) {

    block_end <- min(block_start + length(item_ids) - 1L, n_rounds)
    block_rows <- block_start:block_end
    block_targets <- as.integer(target_ids[block_rows])

    assigned <- NULL

    for (attempt in seq_len(max_attempts)) {

      remaining_items <- item_ids
      remaining_positions <- seq_along(block_rows)
      block_assignment <- rep(NA_integer_, length(block_rows))
      failed <- FALSE

      while (length(remaining_positions) > 0L) {

        candidate_lists <- lapply(
          remaining_positions,
          function(pos) {
            target_key <- as.character(block_targets[pos])
            intersect(
              remaining_items,
              available_items_by_target[[target_key]]
            )
          }
        )

        n_candidates <- lengths(candidate_lists)

        if (any(n_candidates == 0L)) {
          failed <- TRUE
          break
        }

        # Assign the currently most constrained target-round first.
        min_n <- min(n_candidates)
        tied <- which(n_candidates == min_n)
        pick_within_remaining <- tied[sample.int(length(tied), size = 1L)]
        pos <- remaining_positions[pick_within_remaining]
        candidates <- candidate_lists[[pick_within_remaining]]

        chosen <- candidates[sample.int(length(candidates), size = 1L)]
        block_assignment[pos] <- chosen

        remaining_items <- remaining_items[remaining_items != chosen]
        remaining_positions <- remaining_positions[-pick_within_remaining]
      }

      if (!failed && !anyNA(block_assignment)) {
        assigned <- block_assignment
        break
      }
    }

    if (is.null(assigned)) {
      stop(
        "Could not construct a valid BFI item assignment after ",
        max_attempts,
        " attempts for rounds ", block_start, "-", block_end,
        ". Check target-level BFI missingness."
      )
    }

    out[block_rows] <- assigned
  }

  out
}


# ------------------------------------------------------------------------------
# Generate complete BFI design
# ------------------------------------------------------------------------------

generate_bfi_design <- function(
  n_users,
  target_responses,
  engagement_scale = 1
) {

  required_cols <- c(
    "target_id",
    "item_id",
    "criterion_raw",
    "criterion_z"
  )

  if (!all(required_cols %in% names(target_responses))) {
    stop(
      "target_responses must contain: ",
      paste(required_cols, collapse = ", ")
    )
  }

  if (length(n_users) != 1L || n_users < 1L) {
    stop("n_users must be a single positive integer.")
  }

  if (length(engagement_scale) != 1L || engagement_scale <= 0) {
    stop("engagement_scale must be a single positive number.")
  }

  n_users <- as.integer(n_users)

  # Basic integrity checks before simulation.
  if (anyNA(target_responses$target_id) || anyNA(target_responses$item_id)) {
    stop("target_responses contains missing target_id or item_id values.")
  }

  if (anyDuplicated(target_responses[c("target_id", "item_id")])) {
    stop("target_responses contains duplicate target_id x item_id rows.")
  }

  # Reuse the natural-engagement distribution from config.R, shifting the
  # lognormal mean by log(engagement_scale).
  base_meanlog <- ENGAGEMENT_MEANLOG
  assign(
    "ENGAGEMENT_MEANLOG",
    base_meanlog + log(engagement_scale),
    envir = .GlobalEnv
  )

  on.exit(
    assign("ENGAGEMENT_MEANLOG", base_meanlog, envir = .GlobalEnv),
    add = TRUE
  )

  round_counts <- draw_round_counts(n_users)

  item_ids <- sort(unique(as.integer(target_responses$item_id)))

  if (length(item_ids) != BFI_N_ITEMS) {
    stop(
      "Expected ", BFI_N_ITEMS,
      " BFI items but found ", length(item_ids), "."
    )
  }

  # Use one and the same non-missing table for (a) deciding which target x item
  # cells can be sampled and (b) looking up the criterion afterwards. This
  # guarantees that every generated trial has an observed criterion.
  valid_responses <- target_responses[
    !is.na(target_responses$criterion_raw) &
      !is.na(target_responses$criterion_z),
    required_cols,
    drop = FALSE
  ]

  valid_responses$target_id <- as.integer(valid_responses$target_id)
  valid_responses$item_id <- as.integer(valid_responses$item_id)

  if (nrow(valid_responses) == 0L) {
    stop("No non-missing BFI target responses are available.")
  }

  available_items_by_target <- split(
    valid_responses$item_id,
    as.character(valid_responses$target_id)
  )
  available_items_by_target <- lapply(
    available_items_by_target,
    function(x) sort(unique(as.integer(x)))
  )

  eligible_target_ids <- sort(
    as.integer(names(available_items_by_target))
  )

  user_designs <- vector("list", n_users)

  for (user in seq_len(n_users)) {

    n_rounds <- round_counts[user]

    targets <- assign_bfi_targets(
      n_rounds = n_rounds,
      eligible_target_ids = eligible_target_ids
    )

    items <- assign_bfi_items_for_user(
      target_ids = targets,
      available_items_by_target = available_items_by_target,
      item_ids = item_ids
    )

    user_designs[[user]] <- data.frame(
      user_id = user,
      round = seq_len(n_rounds),
      target_id = targets,
      item_id = items
    )
  }

  design <- do.call(rbind, user_designs)
  rownames(design) <- NULL

  # Keyed criterion lookup. Avoid merge(): the same set of non-missing cells
  # that defined availability above is now used for the lookup.
  lookup_key <- paste(
    valid_responses$target_id,
    valid_responses$item_id,
    sep = "::"
  )

  design_key <- paste(
    design$target_id,
    design$item_id,
    sep = "::"
  )

  idx <- match(design_key, lookup_key)

  if (anyNA(idx)) {
    bad <- unique(
      design[is.na(idx), c("target_id", "item_id"), drop = FALSE]
    )
    stop(
      "Internal error: generated unavailable target x item combinations: ",
      paste(
        paste0(bad$target_id, " x ", bad$item_id),
        collapse = ", "
      )
    )
  }

  design$criterion_raw <- valid_responses$criterion_raw[idx]
  design$criterion_z <- valid_responses$criterion_z[idx]

  if (anyNA(design$criterion_raw) || anyNA(design$criterion_z)) {
    stop("Generated design contains missing target criteria after keyed lookup.")
  }

  attr(design, "round_counts") <- round_counts
  attr(design, "eligible_target_ids") <- eligible_target_ids

  design
}
