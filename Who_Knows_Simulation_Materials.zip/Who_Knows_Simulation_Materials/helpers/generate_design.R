# ==============================================================================
# helpers/generate_design.R
# Functions for generating the sparse Who Knows observation structure
# ==============================================================================

# This file defines functions only. It assumes that config.R has already been
# sourced by the calling script.


# ------------------------------------------------------------------------------
# Generate sparse target × item availability
# ------------------------------------------------------------------------------

generate_availability_matrix <- function(
  n_targets = N_TARGETS,
  n_items = N_ITEMS,
  n_pairs = N_ITEM_TARGET_PAIRS,
  min_items_per_target = JUDGMENTS_PER_ROUND,
  require_all_items = TRUE,
  max_attempts = 100L
) {

  if (n_pairs > n_targets * n_items) {
    stop("n_pairs cannot exceed n_targets * n_items.")
  }

  if (n_pairs < n_items && require_all_items) {
    stop("n_pairs must be at least n_items when require_all_items = TRUE.")
  }

  if (n_pairs < n_targets * min_items_per_target) {
    stop(
      "n_pairs is too small to guarantee min_items_per_target for all targets."
    )
  }

  for (attempt in seq_len(max_attempts)) {

    sampled_pairs <- sample.int(
      n = n_targets * n_items,
      size = n_pairs,
      replace = FALSE
    )

    availability <- matrix(
      FALSE,
      nrow = n_targets,
      ncol = n_items,
      dimnames = list(
        target_id = seq_len(n_targets),
        item_id = seq_len(n_items)
      )
    )

    availability[sampled_pairs] <- TRUE

    target_counts <- rowSums(availability)
    item_counts <- colSums(availability)

    valid_targets <- all(target_counts >= min_items_per_target)
    valid_items <- !require_all_items || all(item_counts >= 1L)

    if (valid_targets && valid_items) {
      return(availability)
    }
  }

  stop(
    "Could not generate a valid availability matrix after ",
    max_attempts,
    " attempts."
  )
}



# ------------------------------------------------------------------------------
# Generate fixed item properties
# ------------------------------------------------------------------------------

generate_item_properties <- function(
  n_items = N_ITEMS,
  item_type_counts = ITEM_TYPE_COUNTS
) {

  if (sum(item_type_counts) != n_items) {
    stop("item_type_counts must sum to n_items.")
  }

  item_types <- rep(
    names(item_type_counts),
    times = as.integer(item_type_counts)
  )

  # Randomly permute item types across item IDs. This assignment is generated
  # independently of target × item availability.
  item_types <- sample(item_types, size = n_items, replace = FALSE)

  data.frame(
    item_id = seq_len(n_items),
    item_type = item_types,
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# Draw total number of rounds for each user
# ------------------------------------------------------------------------------

draw_round_counts <- function(
  n_users,
  distribution = ENGAGEMENT_DISTRIBUTION,
  min_rounds = MIN_ROUNDS,
  max_rounds = MAX_ROUNDS
) {

  if (length(n_users) != 1L || n_users < 1L) {
    stop("n_users must be a single positive integer.")
  }

  n_users <- as.integer(n_users)

  if (distribution == "lognormal") {

    raw_rounds <- rlnorm(
      n = n_users,
      meanlog = ENGAGEMENT_MEANLOG,
      sdlog = ENGAGEMENT_SDLOG
    )

  } else {

    stop("Unsupported engagement distribution: ", distribution)
  }

  round_counts <- as.integer(round(raw_rounds))

  round_counts <- pmax(round_counts, min_rounds)
  round_counts <- pmin(round_counts, max_rounds)

  round_counts
}


# ------------------------------------------------------------------------------
# Assign targets to rounds
# ------------------------------------------------------------------------------

assign_targets <- function(
  n_rounds,
  n_targets = N_TARGETS
) {

  if (length(n_rounds) != 1L || n_rounds < 0L) {
    stop("n_rounds must be a single non-negative integer.")
  }

  n_rounds <- as.integer(n_rounds)

  if (n_rounds == 0L) {
    return(integer(0))
  }

  n_full_cycles <- n_rounds %/% n_targets
  n_remaining <- n_rounds %% n_targets

  targets <- integer(0)

  if (n_full_cycles > 0L) {
    targets <- unlist(
      replicate(
        n = n_full_cycles,
        expr = sample.int(n_targets),
        simplify = FALSE
      ),
      use.names = FALSE
    )
  }

  if (n_remaining > 0L) {
    targets <- c(
      targets,
      sample.int(n_targets, size = n_remaining, replace = FALSE)
    )
  }

  targets
}


# ------------------------------------------------------------------------------
# Generate complete trial-level design
# ------------------------------------------------------------------------------

generate_design <- function(
  n_users,
  availability_matrix,
  judgments_per_round = JUDGMENTS_PER_ROUND
) {

  if (!is.matrix(availability_matrix)) {
    stop("availability_matrix must be a matrix.")
  }

  if (
    nrow(availability_matrix) != N_TARGETS ||
    ncol(availability_matrix) != N_ITEMS
  ) {
    stop(
      "availability_matrix must have ",
      N_TARGETS,
      " rows and ",
      N_ITEMS,
      " columns."
    )
  }

  if (any(rowSums(availability_matrix) < judgments_per_round)) {
    stop(
      "Every target must have at least judgments_per_round available items."
    )
  }

  round_counts <- draw_round_counts(n_users)

  # Construct the round-level structure first.
  user_id <- rep.int(seq_len(n_users), round_counts)
  round_number <- sequence(round_counts)

  target_id <- unlist(
    lapply(round_counts, assign_targets),
    use.names = FALSE
  )

  round_design <- data.frame(
    user_id = user_id,
    round = round_number,
    target_id = target_id
  )

  # Precompute the available item IDs for each target.
  available_items <- lapply(
    seq_len(N_TARGETS),
    function(target) which(availability_matrix[target, ])
  )

  # Sample five distinct permissible items within each round.
  sampled_items <- lapply(
    round_design$target_id,
    function(target) {
      sample(
        available_items[[target]],
        size = judgments_per_round,
        replace = FALSE
      )
    }
  )

  item_matrix <- do.call(rbind, sampled_items)

  design <- data.frame(
    user_id = rep(round_design$user_id, each = judgments_per_round),
    round = rep(round_design$round, each = judgments_per_round),
    target_id = rep(round_design$target_id, each = judgments_per_round),
    judgment_within_round = rep.int(
      seq_len(judgments_per_round),
      times = nrow(round_design)
    ),
    item_id = as.vector(t(item_matrix))
  )

  rownames(design) <- NULL

  attr(design, "round_counts") <- round_counts

  design
}
