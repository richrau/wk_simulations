# ==============================================================================
# helpers/simulate_target_learning.R
# Simulation 4 helpers: target-specific learning
# ==============================================================================


# ------------------------------------------------------------------------------
# Generate target-learning module design
# ------------------------------------------------------------------------------

generate_target_learning_design <- function(
  n_users,
  n_targets_per_user,
  rounds_per_target,
  availability_matrix,
  judgments_per_round = TL_JUDGMENTS_PER_ROUND
) {

  n_users <- as.integer(n_users)
  n_targets_per_user <- as.integer(n_targets_per_user)
  rounds_per_target <- as.integer(rounds_per_target)

  if (n_users < 1L) stop("n_users must be positive.")
  if (n_targets_per_user < 1L) stop("n_targets_per_user must be positive.")
  if (rounds_per_target < 2L) stop("rounds_per_target must be at least 2.")

  if (
    !is.matrix(availability_matrix) ||
    nrow(availability_matrix) != N_TARGETS ||
    ncol(availability_matrix) != N_ITEMS
  ) {
    stop("availability_matrix has the wrong dimensions.")
  }

  items_needed_per_target <- (
    rounds_per_target *
      judgments_per_round
  )

  eligible_targets <- which(
    rowSums(availability_matrix) >=
      items_needed_per_target
  )

  if (
    length(eligible_targets) <
      n_targets_per_user
  ) {
    stop(
      "Too few targets have at least ",
      items_needed_per_target,
      " available unique items."
    )
  }

  available_items <- lapply(
    seq_len(N_TARGETS),
    function(target) which(
      availability_matrix[target, ]
    )
  )

  user_parts <- vector(
    "list",
    n_users
  )

  for (u in seq_len(n_users)) {

    targets_u <- sample(
      eligible_targets,
      size = n_targets_per_user,
      replace = FALSE
    )

    target_parts <- vector(
      "list",
      n_targets_per_user
    )

    for (b in seq_len(n_targets_per_user)) {

      target <- targets_u[b]

      # New information throughout the target block: no item is repeated for
      # the same user-target pair.
      items_u_t <- sample(
        available_items[[target]],
        size = items_needed_per_target,
        replace = FALSE
      )

      target_parts[[b]] <- data.frame(
        user_id = u,
        target_block = b,
        within_target_round = seq_len(
          rounds_per_target
        )[
          rep(
            seq_len(rounds_per_target),
            each = judgments_per_round
          )
        ],
        target_id = target,
        item_id = items_u_t,
        judgment_within_round = rep(
          seq_len(judgments_per_round),
          times = rounds_per_target
        )
      )
    }

    user_parts[[u]] <- do.call(
      rbind,
      target_parts
    )
  }

  dat <- do.call(
    rbind,
    user_parts
  )

  rownames(dat) <- NULL

  dat$round <- (
    (dat$target_block - 1L) *
      rounds_per_target +
      dat$within_target_round
  )

  dat$target_progress <- (
    (dat$within_target_round - 1) /
      (rounds_per_target - 1)
  )

  dat$total_games_before <- (
    TL_PRIOR_NORMAL_ROUNDS +
      dat$round -
      1L
  )

  dat$user_target_id <- interaction(
    dat$user_id,
    dat$target_id,
    drop = TRUE
  )

  attr(
    dat,
    "n_eligible_targets"
  ) <- length(
    eligible_targets
  )

  dat
}


# ------------------------------------------------------------------------------
# Simulate correctness with target-specific learning
# ------------------------------------------------------------------------------

simulate_target_learning_dataset <- function(
  n_users,
  n_targets_per_user,
  rounds_per_target,
  availability_matrix,
  item_properties,
  rho_negativity_learning = 0,
  keep_components = FALSE
) {

  if (
    length(rho_negativity_learning) != 1L ||
    !is.finite(rho_negativity_learning) ||
    abs(rho_negativity_learning) >= 1
  ) {
    stop(
      "rho_negativity_learning must lie strictly between -1 and 1."
    )
  }

  design <- generate_target_learning_design(
    n_users = n_users,
    n_targets_per_user = n_targets_per_user,
    rounds_per_target = rounds_per_target,
    availability_matrix = availability_matrix
  )

  n_eligible_targets <- attr(
    design,
    "n_eligible_targets"
  )

  # Empirically calibrated Who Knows correctness DGP.
  # Baseline negativity is generated independently of baseline correctness.
  dat <- simulate_correctness(
    design = design,
    item_properties = item_properties,
    include_exposure_effects = TRUE,
    rho_negativity_accuracy = 0,
    keep_components = TRUE
  )

  # The generic correctness helper starts played_games at zero within the
  # supplied design. Replace that practice term with the appropriate exposure
  # after the minimum 20 ordinary-use rounds required for module eligibility.
  lp_base <- (
    dat$linear_predictor -
      B_LOG_PLAYED_GAMES *
        log1p(
          dat$played_games
        ) +
      B_LOG_PLAYED_GAMES *
        log1p(
          dat$total_games_before
        )
  )

  user_ids <- sort(
    unique(
      dat$user_id
    )
  )

  n_users_actual <- length(
    user_ids
  )

  negativity_by_user <- tapply(
    dat$negativity_z,
    dat$user_id,
    function(x) x[1]
  )

  negativity_by_user <- as.numeric(
    negativity_by_user[
      as.character(
        user_ids
      )
    ]
  )

  beta_negativity_learning <- (
    rho_negativity_learning *
      TL_SD_LEARNING
  )

  residual_learning_sd <- (
    TL_SD_LEARNING *
      sqrt(
        1 -
          rho_negativity_learning^2
      )
  )

  learning_residual <- rnorm(
    n_users_actual,
    mean = 0,
    sd = residual_learning_sd
  )

  person_table <- data.frame(
    user_id = user_ids,
    negativity_z_person = negativity_by_user,
    learning_residual = learning_residual
  )

  dat <- merge(
    dat,
    person_table,
    by = "user_id",
    all.x = TRUE,
    sort = FALSE
  )

  dat <- dat[
    order(
      dat$user_id,
      dat$round,
      dat$judgment_within_round
    ),
  ]

  rownames(dat) <- NULL

  dat$learning_slope_person <- (
    TL_MEAN_LEARNING +
      beta_negativity_learning *
        dat$negativity_z_person +
      dat$learning_residual
  )

  dat$learning_effect <- (
    dat$learning_slope_person *
      dat$target_progress
  )

  dat$linear_predictor_learning <- (
    lp_base +
      dat$learning_effect
  )

  dat$p_correct_learning <- plogis(
    dat$linear_predictor_learning
  )

  dat$is_correct <- rbinom(
    nrow(dat),
    size = 1L,
    prob = dat$p_correct_learning
  )

  # Restore useful exposure variable to the module-relevant value.
  dat$played_games <- dat$total_games_before

  beta_true <- beta_negativity_learning

  if (!isTRUE(keep_components)) {

    keep <- c(
      "user_id",
      "target_block",
      "within_target_round",
      "round",
      "target_id",
      "user_target_id",
      "item_id",
      "judgment_within_round",
      "item_type",
      "target_progress",
      "played_games",
      "item_repetition",
      "negativity_z_person",
      "is_correct"
    )

    dat <- dat[
      ,
      keep
    ]
  }

  attr(
    dat,
    "beta_negativity_learning"
  ) <- beta_true

  attr(
    dat,
    "mean_learning"
  ) <- TL_MEAN_LEARNING

  attr(
    dat,
    "n_eligible_targets"
  ) <- n_eligible_targets

  dat
}


# ------------------------------------------------------------------------------
# Aggregate to user x target x target-round counts
# ------------------------------------------------------------------------------

aggregate_target_learning <- function(
  dat
) {

  dat$one <- 1L

  agg <- aggregate(
    cbind(
      n_correct = is_correct,
      n_total = one
    ) ~
      user_id +
      target_id +
      user_target_id +
      target_block +
      within_target_round +
      target_progress +
      played_games +
      negativity_z_person,
    data = dat,
    FUN = sum
  )

  agg$n_incorrect <- (
    agg$n_total -
      agg$n_correct
  )

  agg$user_id <- factor(
    agg$user_id
  )

  agg$target_id <- factor(
    agg$target_id
  )

  agg$user_target_id <- factor(
    agg$user_target_id
  )

  agg
}
