# ==============================================================================
# helpers/simulate_correctness.R
# Generate binary correctness outcomes for a Who Knows trial-level design
# ==============================================================================

# This file defines functions only. It assumes that config.R has already been
# sourced by the calling script.


# ------------------------------------------------------------------------------
# Add exposure / repetition variables
# ------------------------------------------------------------------------------

add_exposure_variables <- function(design) {

  required_columns <- c(
    "user_id",
    "round",
    "target_id",
    "item_id",
    "judgment_within_round"
  )

  missing_columns <- setdiff(required_columns, names(design))

  if (length(missing_columns) > 0L) {
    stop(
      "design is missing required columns: ",
      paste(missing_columns, collapse = ", ")
    )
  }

  original_order <- seq_len(nrow(design))

  ord <- order(
    design$user_id,
    design$round,
    design$judgment_within_round
  )

  dat <- design[ord, , drop = FALSE]
  dat$.original_order <- original_order[ord]

  # Number of games completed before the current judgment.
  dat$played_games <- dat$round - 1L

  # Number of previous encounters with the same target.
  dat$target_repetition <- (dat$round - 1L) %/% N_TARGETS

  # Number of previous encounters with the same item for the same user.
  item_user_key <- paste(dat$user_id, dat$item_id, sep = "_")

  dat$item_repetition <- ave(
    seq_len(nrow(dat)),
    item_user_key,
    FUN = function(x) seq_along(x) - 1L
  )

  dat$item_repetition <- as.integer(dat$item_repetition)

  dat <- dat[order(dat$.original_order), , drop = FALSE]
  dat$.original_order <- NULL
  rownames(dat) <- NULL

  dat
}


# ------------------------------------------------------------------------------
# Generate random-effect contributions
# ------------------------------------------------------------------------------

generate_correctness_random_effects <- function(
  design,
  sd_user = SD_USER
) {

  if (nrow(design) == 0L) {
    stop("design contains no observations.")
  }

  if (any(design$user_id < 1L) ||
      any(design$item_id < 1L) ||
      any(design$target_id < 1L)) {
    stop("user_id, item_id, and target_id must be positive integers.")
  }

  n_users <- max(design$user_id)

  if (max(design$item_id) > N_ITEMS) {
    stop("design contains item_id values larger than N_ITEMS.")
  }

  if (max(design$target_id) > N_TARGETS) {
    stop("design contains target_id values larger than N_TARGETS.")
  }

  # Main random intercepts ------------------------------------------------------

  re_user_values <- rnorm(
    n = n_users,
    mean = 0,
    sd = sd_user
  )

  re_item_values <- rnorm(
    n = N_ITEMS,
    mean = 0,
    sd = SD_ITEM
  )

  re_target_values <- rnorm(
    n = N_TARGETS,
    mean = 0,
    sd = SD_TARGET
  )

  re_user <- re_user_values[design$user_id]
  re_item <- re_item_values[design$item_id]
  re_target <- re_target_values[design$target_id]


  # Item × target ---------------------------------------------------------------

  item_target_key <- (
    (design$target_id - 1L) * N_ITEMS +
      design$item_id
  )

  item_target_levels <- unique(item_target_key)

  re_item_target_values <- rnorm(
    n = length(item_target_levels),
    mean = 0,
    sd = SD_ITEM_TARGET
  )

  re_item_target <- re_item_target_values[
    match(item_target_key, item_target_levels)
  ]


  # Item × user -----------------------------------------------------------------

  item_user_key <- (
    (design$user_id - 1) * N_ITEMS +
      design$item_id
  )

  item_user_levels <- unique(item_user_key)

  re_item_user_values <- rnorm(
    n = length(item_user_levels),
    mean = 0,
    sd = SD_ITEM_USER
  )

  re_item_user <- re_item_user_values[
    match(item_user_key, item_user_levels)
  ]


  # Target × user ---------------------------------------------------------------

  target_user_key <- (
    (design$user_id - 1) * N_TARGETS +
      design$target_id
  )

  target_user_levels <- unique(target_user_key)

  re_target_user_values <- rnorm(
    n = length(target_user_levels),
    mean = 0,
    sd = SD_TARGET_USER
  )

  re_target_user <- re_target_user_values[
    match(target_user_key, target_user_levels)
  ]


  data.frame(
    re_user = re_user,
    re_item = re_item,
    re_target = re_target,
    re_item_target = re_item_target,
    re_item_user = re_item_user,
    re_target_user = re_target_user
  )
}


# ------------------------------------------------------------------------------
# Simulate binary correctness
# ------------------------------------------------------------------------------

simulate_correctness <- function(
  design,
  item_properties,
  include_exposure_effects = TRUE,
  rho_negativity_accuracy = 0,
  keep_components = FALSE
) {

  required_item_columns <- c("item_id", "item_type")

  missing_item_columns <- setdiff(
    required_item_columns,
    names(item_properties)
  )

  if (length(missing_item_columns) > 0L) {
    stop(
      "item_properties is missing required columns: ",
      paste(missing_item_columns, collapse = ", ")
    )
  }

  if (anyDuplicated(item_properties$item_id)) {
    stop("item_properties must contain exactly one row per item_id.")
  }

  if (!all(unique(design$item_id) %in% item_properties$item_id)) {
    stop("Some design item IDs are missing from item_properties.")
  }

  valid_item_types <- c(
    "knowledge",
    "true_false",
    "open",
    "scale"
  )

  if (!all(item_properties$item_type %in% valid_item_types)) {
    stop("Unknown item_type value found in item_properties.")
  }

  dat <- add_exposure_variables(design)

  # Focal person-level predictor ------------------------------------------------

  if (
    length(rho_negativity_accuracy) != 1L ||
    !is.finite(rho_negativity_accuracy) ||
    abs(rho_negativity_accuracy) >= 1
  ) {
    stop(
      "rho_negativity_accuracy must be a single finite value between -1 and 1."
    )
  }

  n_users <- max(dat$user_id)

  # Standardized person-level generalized negativity.
  negativity_values <- as.numeric(
    scale(rnorm(n_users))
  )

  dat$negativity_z <- negativity_values[dat$user_id]

  # Parameterize the focal association as a correlation between generalized
  # negativity and the latent person-level correctness propensity while
  # preserving the empirically calibrated total user-level SD.
  b_negativity_accuracy <- (
    rho_negativity_accuracy * SD_USER
  )

  sd_user_residual <- (
    SD_USER * sqrt(1 - rho_negativity_accuracy^2)
  )

  negativity_effect <- (
    b_negativity_accuracy * dat$negativity_z
  )

  # Attach item type without changing trial order.
  item_match <- match(dat$item_id, item_properties$item_id)
  dat$item_type <- item_properties$item_type[item_match]

  # Item-type fixed effect. Knowledge items are the reference category.
  item_type_effect <- numeric(nrow(dat))

  item_type_effect[dat$item_type == "open"] <-
    B_ITEM_TYPE_OPEN

  item_type_effect[dat$item_type == "scale"] <-
    B_ITEM_TYPE_SCALE

  item_type_effect[dat$item_type == "true_false"] <-
    B_ITEM_TYPE_TRUE_FALSE

  # Exposure effects ------------------------------------------------------------

  exposure_effect <- numeric(nrow(dat))

  if (include_exposure_effects) {
    exposure_effect <- (
      B_LOG_PLAYED_GAMES * log1p(dat$played_games) +
        B_LOG_TARGET_REPETITION * log1p(dat$target_repetition) +
        B_LOG_ITEM_REPETITION * log1p(dat$item_repetition)
    )
  }

  # Random effects --------------------------------------------------------------

  random_effects <- generate_correctness_random_effects(
    design = dat,
    sd_user = sd_user_residual
  )

  random_effect_total <- rowSums(random_effects)

  # Linear predictor and Bernoulli outcome --------------------------------------

  linear_predictor <- (
    CORRECTNESS_INTERCEPT +
      item_type_effect +
      exposure_effect +
      negativity_effect +
      random_effect_total
  )

  p_correct <- plogis(linear_predictor)

  dat$is_correct <- rbinom(
    n = nrow(dat),
    size = 1L,
    prob = p_correct
  )

  # Use the empirical model's reference category first.
  dat$item_type <- factor(
    dat$item_type,
    levels = c(
      "knowledge",
      "open",
      "scale",
      "true_false"
    )
  )

  if (keep_components) {

    dat$item_type_effect <- item_type_effect
    dat$exposure_effect <- exposure_effect
    dat$negativity_effect <- negativity_effect
    dat$b_negativity_accuracy <- b_negativity_accuracy
    dat$sd_user_residual <- sd_user_residual

    dat <- cbind(
      dat,
      random_effects
    )

    dat$random_effect_total <- random_effect_total
    dat$linear_predictor <- linear_predictor
    dat$p_correct <- p_correct
  }

  dat
}
