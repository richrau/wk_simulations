# ==============================================================================
# scripts/01_calibrate_design.R
# Generate and inspect the neutral Who Knows simulation design
# ==============================================================================

source(here::here("config.R"))
source(here::here("helpers", "generate_design.R"))


# ------------------------------------------------------------------------------
# Output folders
# ------------------------------------------------------------------------------

dir.create(
  here::here("data", "calibration"),
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  here::here("output", "tables"),
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  here::here("output", "figures"),
  recursive = TRUE,
  showWarnings = FALSE
)


# ------------------------------------------------------------------------------
# 1. Generate and save the fixed target × item availability matrix
# ------------------------------------------------------------------------------

set.seed(SEED_DESIGN)

availability_matrix <- generate_availability_matrix()

stopifnot(
  is.matrix(availability_matrix),
  nrow(availability_matrix) == N_TARGETS,
  ncol(availability_matrix) == N_ITEMS,
  sum(availability_matrix) == N_ITEM_TARGET_PAIRS,
  all(rowSums(availability_matrix) >= JUDGMENTS_PER_ROUND),
  all(colSums(availability_matrix) >= 1L)
)

saveRDS(
  availability_matrix,
  here::here("data", "calibration", "availability_matrix.rds")
)

items_per_target <- rowSums(availability_matrix)
targets_per_item <- colSums(availability_matrix)


# Generate fixed item-type assignments independently of availability.
set.seed(SEED_ITEM_PROPERTIES)

item_properties <- generate_item_properties()

observed_type_counts <- table(item_properties$item_type)

stopifnot(
  nrow(item_properties) == N_ITEMS,
  all(
    observed_type_counts[names(ITEM_TYPE_COUNTS)] ==
      ITEM_TYPE_COUNTS
  )
)

saveRDS(
  item_properties,
  here::here("data", "calibration", "item_properties.rds")
)

availability_by_target <- data.frame(
  target_id = seq_len(N_TARGETS),
  n_available_items = items_per_target
)

availability_by_item <- merge(
  data.frame(
    item_id = seq_len(N_ITEMS),
    n_available_targets = targets_per_item
  ),
  item_properties,
  by = "item_id",
  sort = FALSE
)

write.csv(
  availability_by_target,
  here::here("output", "tables", "availability_by_target.csv"),
  row.names = FALSE
)

write.csv(
  availability_by_item,
  here::here("output", "tables", "availability_by_item.csv"),
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# 2. Generate a large synthetic user sample for design checking
# ------------------------------------------------------------------------------

# Use a separate deterministic RNG stream so that changing the availability
# generator does not automatically alter the engagement sample.
set.seed(SEED_DESIGN + 1L)

design_check <- generate_design(
  n_users = N_USERS_DESIGN_CHECK,
  availability_matrix = availability_matrix
)

round_counts <- attr(design_check, "round_counts")

stopifnot(
  length(round_counts) == N_USERS_DESIGN_CHECK,
  nrow(design_check) == sum(round_counts) * JUDGMENTS_PER_ROUND
)


# ------------------------------------------------------------------------------
# 3. User-level design summaries
# ------------------------------------------------------------------------------

observations_per_user <- as.integer(
  table(factor(design_check$user_id, levels = seq_len(N_USERS_DESIGN_CHECK)))
)

distinct_targets_per_user <- as.integer(
  tapply(
    design_check$target_id,
    design_check$user_id,
    function(x) length(unique(x))
  )
)

distinct_items_per_user <- as.integer(
  tapply(
    design_check$item_id,
    design_check$user_id,
    function(x) length(unique(x))
  )
)

# Under randomized 75-target cycles, users should see no repeated target until
# they have seen all 75 targets once.
stopifnot(
  all(observations_per_user == round_counts * JUDGMENTS_PER_ROUND),
  all(distinct_targets_per_user == pmin(round_counts, N_TARGETS))
)

user_summary <- data.frame(
  user_id = seq_len(N_USERS_DESIGN_CHECK),
  n_rounds = round_counts,
  n_judgments = observations_per_user,
  n_distinct_targets = distinct_targets_per_user,
  n_distinct_items = distinct_items_per_user
)

write.csv(
  user_summary,
  here::here("output", "tables", "design_check_user_summary.csv"),
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# 4. Item and target exposure in the generated design
# ------------------------------------------------------------------------------

item_observations <- tabulate(
  design_check$item_id,
  nbins = N_ITEMS
)

target_observations <- tabulate(
  design_check$target_id,
  nbins = N_TARGETS
)

item_usage <- merge(
  data.frame(
    item_id = seq_len(N_ITEMS),
    n_available_targets = targets_per_item,
    n_observations = item_observations
  ),
  item_properties,
  by = "item_id",
  sort = FALSE
)

target_usage <- data.frame(
  target_id = seq_len(N_TARGETS),
  n_available_items = items_per_target,
  n_observations = target_observations
)

write.csv(
  item_usage,
  here::here("output", "tables", "design_check_item_usage.csv"),
  row.names = FALSE
)

write.csv(
  target_usage,
  here::here("output", "tables", "design_check_target_usage.csv"),
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# 5. Compact diagnostic summary
# ------------------------------------------------------------------------------

q_rounds <- quantile(
  round_counts,
  probs = c(.10, .25, .50, .75, .90, .95, .99),
  names = FALSE
)

design_summary <- data.frame(
  metric = c(
    "users",
    "total_rounds",
    "total_judgments",
    "mean_rounds",
    "sd_rounds",
    "median_rounds",
    "p10_rounds",
    "p25_rounds",
    "p75_rounds",
    "p90_rounds",
    "p95_rounds",
    "p99_rounds",
    "proportion_10plus_rounds",
    "proportion_20plus_rounds",
    "proportion_30plus_rounds",
    "proportion_75plus_rounds",
    "proportion_100plus_rounds",
    "proportion_at_max_rounds",
    "mean_items_per_target",
    "sd_items_per_target",
    "min_items_per_target",
    "max_items_per_target",
    "mean_targets_per_item",
    "sd_targets_per_item",
    "min_targets_per_item",
    "max_targets_per_item",
    "item_availability_usage_correlation",
    "target_exposure_cv"
  ),
  value = c(
    N_USERS_DESIGN_CHECK,
    sum(round_counts),
    nrow(design_check),
    mean(round_counts),
    sd(round_counts),
    median(round_counts),
    q_rounds[1],
    q_rounds[2],
    q_rounds[4],
    q_rounds[5],
    q_rounds[6],
    q_rounds[7],
    mean(round_counts >= 10),
    mean(round_counts >= 20),
    mean(round_counts >= 30),
    mean(round_counts >= 75),
    mean(round_counts >= 100),
    mean(round_counts == MAX_ROUNDS),
    mean(items_per_target),
    sd(items_per_target),
    min(items_per_target),
    max(items_per_target),
    mean(targets_per_item),
    sd(targets_per_item),
    min(targets_per_item),
    max(targets_per_item),
    cor(targets_per_item, item_observations),
    sd(target_observations) / mean(target_observations)
  ),
  note = c(
    "",
    "",
    "",
    "Historical gated sample: M = 19.6; not treated as a target",
    "Historical gated sample: SD = 31.9; not treated as a target",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "Should be strongly positive because items available for more targets are sampled more often",
    "Should be small because targets are balanced within randomized 75-target cycles"
  )
)

write.csv(
  design_summary,
  here::here("output", "tables", "design_check_summary.csv"),
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# 6. Diagnostic figures
# ------------------------------------------------------------------------------

# Engagement distribution ------------------------------------------------------

round_counts_plot <- pmin(round_counts, 100L)

png(
  filename = here::here(
    "output",
    "figures",
    "design_check_engagement_distribution.png"
  ),
  width = 1400,
  height = 900,
  res = 150
)

hist(
  round_counts_plot,
  breaks = seq(0.5, 100.5, by = 1),
  main = "Simulated engagement distribution",
  xlab = "Rounds played (100 = 100 or more)",
  ylab = "Number of users",
  xlim = c(0, 100)
)

dev.off()


# Number of targets for which each item is available ---------------------------

png(
  filename = here::here(
    "output",
    "figures",
    "design_check_targets_per_item.png"
  ),
  width = 1200,
  height = 900,
  res = 150
)

hist(
  targets_per_item,
  breaks = seq(
    min(targets_per_item) - 0.5,
    max(targets_per_item) + 0.5,
    by = 1
  ),
  main = "Sparse item availability",
  xlab = "Number of targets for which an item is available",
  ylab = "Number of items"
)

dev.off()


# Number of available items for each target ------------------------------------

png(
  filename = here::here(
    "output",
    "figures",
    "design_check_items_per_target.png"
  ),
  width = 1200,
  height = 900,
  res = 150
)

hist(
  items_per_target,
  breaks = seq(
    min(items_per_target) - 0.5,
    max(items_per_target) + 0.5,
    by = 1
  ),
  main = "Available items across targets",
  xlab = "Number of available items",
  ylab = "Number of targets"
)

dev.off()


# Item availability versus empirical exposure ----------------------------------

png(
  filename = here::here(
    "output",
    "figures",
    "design_check_item_availability_vs_usage.png"
  ),
  width = 1200,
  height = 900,
  res = 150
)

plot(
  targets_per_item,
  item_observations,
  pch = 16,
  cex = 0.7,
  xlab = "Number of targets for which item is available",
  ylab = "Number of simulated observations",
  main = "Item availability and resulting exposure"
)

dev.off()


# ------------------------------------------------------------------------------
# 7. Console summary
# ------------------------------------------------------------------------------

cat("\n")
cat("Design calibration complete\n")
cat("===========================\n")
cat("Users:              ", N_USERS_DESIGN_CHECK, "\n")
cat("Total rounds:       ", sum(round_counts), "\n")
cat("Total judgments:    ", nrow(design_check), "\n")
cat("Mean rounds:        ", round(mean(round_counts), 2), "\n")
cat("SD rounds:          ", round(sd(round_counts), 2), "\n")
cat("Median rounds:      ", median(round_counts), "\n")
cat("30+ rounds:         ", round(100 * mean(round_counts >= 30), 1), "%\n")
cat("75+ rounds:         ", round(100 * mean(round_counts >= 75), 1), "%\n")
cat("100+ rounds:        ", round(100 * mean(round_counts >= 100), 1), "%\n")
cat(
  "Items per target:   ",
  round(mean(items_per_target), 1),
  " [",
  min(items_per_target),
  ", ",
  max(items_per_target),
  "]\n",
  sep = ""
)
cat(
  "Targets per item:   ",
  round(mean(targets_per_item), 1),
  " [",
  min(targets_per_item),
  ", ",
  max(targets_per_item),
  "]\n",
  sep = ""
)
cat(
  "Availability-usage r: ",
  round(cor(targets_per_item, item_observations), 3),
  "\n",
  sep = ""
)
cat(
  "Target exposure CV: ",
  round(sd(target_observations) / mean(target_observations), 4),
  "\n",
  sep = ""
)
cat("\nItem-type counts\n")
print(observed_type_counts)

cat("\nMean available targets per item, by item type\n")
print(
  aggregate(
    n_available_targets ~ item_type,
    data = availability_by_item,
    FUN = mean
  ),
  row.names = FALSE
)

cat("\n")
cat(
  "Availability matrix saved to data/calibration/availability_matrix.rds\n"
)
cat(
  "Item properties saved to data/calibration/item_properties.rds\n"
)
cat("Diagnostic tables saved to output/tables/\n")
cat("Diagnostic figures saved to output/figures/\n")
