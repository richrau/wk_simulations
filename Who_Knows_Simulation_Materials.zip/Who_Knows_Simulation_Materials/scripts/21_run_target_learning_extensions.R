# ==============================================================================
# scripts/21_run_target_learning_extensions.R
# Simulation 4: compare more completers with more targets per completer.
# Primary DGP/model from Script 19; rho = .20; 100 replications per design.
# Run in the existing simulation R project. No changes to helpers/config needed.
# Each completed attempt is checkpointed, including failed fits. Rerun to resume.
# Increase EXT_N_REP to 200 later to add replications with stable seeds.
# Output files are separate from the original Simulation 4 results.
# ==============================================================================

local({
  for (pkg in c("here", "glmmTMB")) {
    if (!requireNamespace(pkg, quietly = TRUE)) stop("Package required: ", pkg)
  }
  source(here::here("config.R"), local = TRUE)
  source(here::here("config_target_learning.R"), local = TRUE)
  source(here::here("helpers", "simulate_correctness.R"), local = TRUE)
  source(here::here("helpers", "simulate_target_learning.R"), local = TRUE)

  EXT_N_REP <- 100L
  EXT_RHO <- .20
  EXT_ROUNDS <- 5L
  designs <- data.frame(
    scenario = c("more_users_1500", "more_targets_15"),
    n_users = c(1500L, 1000L),
    n_targets = c(10L, 15L),
    seed_offset = c(500000L, 600000L)
  )
  stopifnot(EXT_N_REP >= 1L, EXT_N_REP < 100000L,
            TL_JUDGMENTS_PER_ROUND == 5L)

  availability_matrix <- readRDS(TL_AVAILABILITY_FILE)
  item_properties <- readRDS(TL_ITEM_PROPERTIES_FILE)
  out_dir <- here::here("output", "tables")
  checkpoint_dir <- here::here("output", "checkpoints", "target_learning_extensions")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
  raw_file <- file.path(out_dir, "target_learning_extensions_raw.csv")
  summary_file <- file.path(out_dir, "target_learning_extensions_summary_clean.csv")

  # Refuse to mix results generated with different helpers, parameters or inputs.
  # Replication count is deliberately excluded so a later extension can resume.
  inputs <- c(
    here::here("config.R"), here::here("config_target_learning.R"),
    here::here("helpers", "simulate_correctness.R"),
    here::here("helpers", "simulate_target_learning.R"),
    CORRECTNESS_CALIBRATION_FILE, TL_AVAILABILITY_FILE, TL_ITEM_PROPERTIES_FILE
  )
  if (any(!file.exists(inputs))) stop("Missing simulation input file.")
  signature <- list(version = 1L, hashes = unname(tools::md5sum(inputs)),
                    designs = designs, rho = EXT_RHO, rounds = EXT_ROUNDS)
  manifest_file <- file.path(checkpoint_dir, "settings.rds")
  if (file.exists(manifest_file)) {
    if (!identical(readRDS(manifest_file), signature)) {
      stop("Inputs/settings changed since this extension started. Use a new checkpoint/output location.")
    }
  } else {
    saveRDS(signature, manifest_file)
  }

extract_wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) {
    return(c(estimate = NA_real_, se = NA_real_, p = NA_real_))
  }
  c(
    estimate = unname(tab[hit, "Estimate"]),
    se = unname(tab[hit, "Std. Error"]),
    p = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe_fit <- function(expr) {
  warnings <- character()
  error <- NA_character_
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      error <<- conditionMessage(e)
      NULL
    }
  )
  list(value = value, warnings = unique(warnings), error = error)
}

fit_target_learning <- function(dat) {
  agg <- aggregate_target_learning(dat)

    fit <- glmmTMB::glmmTMB(
      cbind(n_correct, n_incorrect) ~
        target_progress * negativity_z_person +
        log1p(played_games) +
        (1 | user_id) +
        (0 + target_progress | user_id) +
        (1 | target_id) +
        (1 | user_target_id),
      data = agg,
      family = binomial()
    )

  focal <- extract_wald(
    fit,
    "^(target_progress:negativity_z_person|negativity_z_person:target_progress)$"
  )
  mean_learning <- extract_wald(fit, "^target_progress$")

  list(
    beta = focal["estimate"],
    beta_se = focal["se"],
    beta_p = focal["p"],
    mean_learning = mean_learning["estimate"],
    mean_learning_se = mean_learning["se"],
    mean_learning_p = mean_learning["p"],
    convergence = fit$fit$convergence,
    pdHess = fit$sdr$pdHess,
    n_aggregated_rows = nrow(agg)
  )
}


  valid_test <- function(est, se, p) {
    is.finite(est) & is.finite(se) & se > 0 & is.finite(p) & p >= 0 & p <= 1
  }
  average <- function(z) if (length(z)) mean(z) else NA_real_
  summarize_results <- function(results) {
    groups <- split(results, results$scenario)
    out <- do.call(rbind, lapply(groups, function(x) {
      fit_ok <- !is.na(x$convergence) & x$convergence == 0 &
        !is.na(x$pdHess) & x$pdHess
      usable <- fit_ok & valid_test(x$beta_estimated, x$beta_se, x$beta_p)
      learn <- fit_ok & valid_test(x$mean_learning_estimated,
                                  x$mean_learning_se, x$mean_learning_p)
      n <- sum(usable)
      rate <- average(x$beta_p[usable] < .05)
      data.frame(
        scenario = x$scenario[1], n_users = x$n_users[1],
        n_targets = x$n_targets[1], rounds_per_target = EXT_ROUNDS,
        judgments_per_user = x$judgments_per_user[1],
        total_judgments = x$n_users[1] * x$judgments_per_user[1],
        rho_generating = EXT_RHO, beta_generating = x$beta_generating[1],
        sd_user_learning = TL_SD_LEARNING, sd_user_target_learning = 0,
        n_rep_completed = nrow(x), n_test_usable_clean = n,
        n_excluded_clean = sum(!usable), excluded_fraction = mean(!usable),
        rejection_rate_clean = rate,
        mcse_rejection_clean = if (n > 0L) sqrt(rate * (1 - rate) / n) else NA_real_,
        mean_beta_estimated_clean = average(x$beta_estimated[usable]),
        mean_beta_se_clean = average(x$beta_se[usable]),
        n_mean_learning_usable = sum(learn),
        mean_learning_estimated_clean = average(x$mean_learning_estimated[learn]),
        mean_learning_rejection_rate_clean = average(x$mean_learning_p[learn] < .05),
        n_nonzero_or_missing_convergence = sum(is.na(x$convergence) | x$convergence != 0),
        n_non_pd_or_missing_hessian = sum(is.na(x$pdHess) | !x$pdHess),
        mean_fit_seconds = average(x$elapsed_seconds)
      )
    }))
    rownames(out) <- NULL
    out
  }

  # Interleave the two designs. Seeds do not depend on order or EXT_N_REP.
  grid <- expand.grid(design_index = seq_len(nrow(designs)),
                      replication = seq_len(EXT_N_REP))
  results <- NULL
  started <- Sys.time()
  cat("\nSIMULATION 4 EXTENSIONS: rho=.20, primary model\n")
  print(designs[, c("scenario", "n_users", "n_targets")], row.names = FALSE)
  cat("Replications per design: ", EXT_N_REP, "\n", sep = "")

  for (j in seq_len(nrow(grid))) {
    job <- designs[grid$design_index[j], ]
    rep_id <- grid$replication[j]
    checkpoint <- file.path(checkpoint_dir,
                            sprintf("%s_rep%05d.rds", job$scenario, rep_id))
    seed <- SEED_TARGET_LEARNING + job$seed_offset + rep_id
    if (file.exists(checkpoint)) {
      row <- readRDS(checkpoint)
      if (nrow(row) != 1L || row$scenario != job$scenario ||
          row$replication != rep_id || row$seed != seed) {
        stop("Unexpected checkpoint contents: ", checkpoint)
      }
    } else {
      set.seed(seed)
      dat <- simulate_target_learning_dataset(
        n_users = job$n_users, n_targets_per_user = job$n_targets,
        rounds_per_target = EXT_ROUNDS,
        availability_matrix = availability_matrix, item_properties = item_properties,
        rho_negativity_learning = EXT_RHO, keep_components = FALSE
      )
      timed <- system.time(fit_safe <- safe_fit(fit_target_learning(dat)))
      if (is.null(fit_safe$value)) {
        z <- list(beta = NA_real_, beta_se = NA_real_, beta_p = NA_real_,
                  mean_learning = NA_real_, mean_learning_se = NA_real_,
                  mean_learning_p = NA_real_, convergence = NA_integer_,
                  pdHess = NA, n_aggregated_rows = NA_integer_)
      } else {
        z <- fit_safe$value
      }
      row <- data.frame(
        scenario = job$scenario, n_users = job$n_users, n_targets = job$n_targets,
        rounds_per_target = EXT_ROUNDS,
        judgments_per_user = job$n_targets * EXT_ROUNDS * TL_JUDGMENTS_PER_ROUND,
        rho_generating = EXT_RHO, beta_generating = EXT_RHO * TL_SD_LEARNING,
        mean_learning_generating = TL_MEAN_LEARNING, sd_user_learning = TL_SD_LEARNING,
        sd_user_target_learning = 0, replication = rep_id, seed = seed,
        beta_estimated = unname(z$beta), beta_se = unname(z$beta_se),
        beta_p = unname(z$beta_p), mean_learning_estimated = unname(z$mean_learning),
        mean_learning_se = unname(z$mean_learning_se),
        mean_learning_p = unname(z$mean_learning_p),
        convergence = z$convergence, pdHess = z$pdHess,
        n_aggregated_rows = z$n_aggregated_rows,
        elapsed_seconds = unname(timed["elapsed"]),
        warnings = paste(fit_safe$warnings, collapse = " | "), error = fit_safe$error,
        stringsAsFactors = FALSE
      )
      # Rename a completed temporary checkpoint; interrupted writes are ignored.
      temporary <- paste0(checkpoint, ".tmp")
      saveRDS(row, temporary)
      if (!file.rename(temporary, checkpoint)) stop("Could not save checkpoint: ", checkpoint)
      cat(j, "/", nrow(grid), " | ", job$scenario, " | rep=", rep_id,
          " | fit=", round(row$elapsed_seconds, 1), "s",
          " | elapsed=", round(as.numeric(difftime(Sys.time(), started, units = "mins")), 1),
          "min\n", sep = "")
      rm(dat)
    }
    results <- if (is.null(results)) row else rbind(results, row)
  }

  # Rebuild exports from every checkpoint, including any later completed reps
  # if EXT_N_REP has subsequently been reduced. Checkpoints are authoritative.
  saved <- list.files(checkpoint_dir, pattern = "_rep[0-9]+[.]rds$", full.names = TRUE)
  results <- do.call(rbind, lapply(saved, readRDS))
  results <- results[order(results$scenario, results$replication), ]
  summary_out <- summarize_results(results)
  write.csv(results, raw_file, row.names = FALSE)
  write.csv(summary_out, summary_file, row.names = FALSE)
  cat("\nSIMULATION 4 EXTENSIONS: CLEANED SUMMARY\n")
  print(summary_out, row.names = FALSE)
  cat("\nRates are conditional on usable fits; exclusion counts are reported.\n")
  cat("These effect-only extensions do not estimate null rejection rates.\n")
  cat("\nRaw results: ", raw_file, "\nSummary: ", summary_file, "\n", sep = "")
  cat("Each completed attempt is saved; rerun this script to resume.\n")
})
