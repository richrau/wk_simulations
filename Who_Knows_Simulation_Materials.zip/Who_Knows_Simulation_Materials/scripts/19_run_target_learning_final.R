# ==============================================================================
# scripts/19_run_target_learning_final.R
# Final Simulation 4: target-specific learning
#
# Current module design:
#   N = 1000 module completers
#   10 targets/user x 5 rounds/target x 5 judgments/round = 250 judgments/user
#
# Primary scenario:
#   person-level heterogeneity in learning
#   rho(negativity, learning) = 0 / .20
#   200 replications per cell
#
# Robustness scenario:
#   additionally allows user x target heterogeneity in learning slopes
#   SD(user x target learning slope) = .20
#   rho(negativity, person-level learning) = 0 / .20
#   100 replications per cell
#
# The robustness SD is deliberately demanding and is not empirically calibrated.
# Saves after every replication and safely resumes.
# ==============================================================================

source(here::here("config.R"))
source(here::here("config_target_learning.R"))
source(here::here("helpers", "simulate_correctness.R"))
source(here::here("helpers", "simulate_target_learning.R"))

if (!requireNamespace("glmmTMB", quietly = TRUE)) {
  stop("Package 'glmmTMB' is required.")
}

# ------------------------------------------------------------------------------
# Fixed design
# ------------------------------------------------------------------------------

N_USERS_MODULE <- 1000L
N_TARGETS_MODULE <- 10L
ROUNDS_PER_TARGET_MODULE <- 5L
RHO_VALUES <- c(0, .20)
N_REP_PRIMARY <- 200L
N_REP_ROBUST <- 100L
SD_USER_TARGET_LEARNING <- .20

START_TIME <- Sys.time()

availability_matrix <- readRDS(TL_AVAILABILITY_FILE)
item_properties <- readRDS(TL_ITEM_PROPERTIES_FILE)

out_dir <- here::here("output", "tables")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
raw_file <- file.path(out_dir, "target_learning_final_raw.csv")
summary_file <- file.path(out_dir, "target_learning_final_summary.csv")

# ------------------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------------------

elapsed_minutes <- function() {
  as.numeric(difftime(Sys.time(), START_TIME, units = "mins"))
}

extract_wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) {
    return(c(estimate = NA_real_, se = NA_real_, p = NA_real_))
  }
  c(
    estimate = unname(tab[hit, "Estimate"]),
    se = unname(tab[hit, "Std. Error"]),
    p = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe_fit <- function(expr) {
  warnings <- character()
  error <- NA_character_
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      error <<- conditionMessage(e)
      NULL
    }
  )
  list(value = value, warnings = unique(warnings), error = error)
}

read_existing <- function(path) {
  if (!file.exists(path)) return(NULL)
  x <- read.csv(path, stringsAsFactors = FALSE)
  if (!nrow(x)) NULL else x
}

append_save <- function(existing, new_row, path) {
  out <- if (is.null(existing)) new_row else rbind(existing, new_row)
  key <- out[, c("scenario", "rho_generating", "replication")]
  out <- out[!duplicated(key), ]
  write.csv(out, path, row.names = FALSE)
  out
}

# ------------------------------------------------------------------------------
# Robustness DGP: add user x target learning-slope heterogeneity
# ------------------------------------------------------------------------------

add_user_target_learning_heterogeneity <- function(dat, sd_user_target_learning) {
  ids <- unique(dat$user_target_id)
  map <- data.frame(
    user_target_id = ids,
    learning_deviation_user_target = rnorm(
      length(ids), mean = 0, sd = sd_user_target_learning
    )
  )

  dat <- merge(dat, map, by = "user_target_id", all.x = TRUE, sort = FALSE)
  dat <- dat[order(dat$user_id, dat$round, dat$judgment_within_round), ]
  rownames(dat) <- NULL

  dat$linear_predictor_learning_heterogeneous <- (
    dat$linear_predictor_learning +
      dat$learning_deviation_user_target * dat$target_progress
  )

  dat$p_correct_learning_heterogeneous <- plogis(
    dat$linear_predictor_learning_heterogeneous
  )

  dat$is_correct <- rbinom(
    nrow(dat), size = 1L, prob = dat$p_correct_learning_heterogeneous
  )

  dat
}

# ------------------------------------------------------------------------------
# Fitted models
# ------------------------------------------------------------------------------

fit_target_learning <- function(dat, include_user_target_learning = FALSE) {
  agg <- aggregate_target_learning(dat)

  if (!include_user_target_learning) {
    fit <- glmmTMB::glmmTMB(
      cbind(n_correct, n_incorrect) ~
        target_progress * negativity_z_person +
        log1p(played_games) +
        (1 | user_id) +
        (0 + target_progress | user_id) +
        (1 | target_id) +
        (1 | user_target_id),
      data = agg,
      family = binomial()
    )
  } else {
    fit <- glmmTMB::glmmTMB(
      cbind(n_correct, n_incorrect) ~
        target_progress * negativity_z_person +
        log1p(played_games) +
        (1 | user_id) +
        (0 + target_progress | user_id) +
        (1 | target_id) +
        (1 | user_target_id) +
        (0 + target_progress | user_target_id),
      data = agg,
      family = binomial()
    )
  }

  focal <- extract_wald(
    fit,
    "^(target_progress:negativity_z_person|negativity_z_person:target_progress)$"
  )
  mean_learning <- extract_wald(fit, "^target_progress$")

  list(
    beta = focal["estimate"],
    beta_se = focal["se"],
    beta_p = focal["p"],
    mean_learning = mean_learning["estimate"],
    mean_learning_se = mean_learning["se"],
    mean_learning_p = mean_learning["p"],
    convergence = fit$fit$convergence,
    pdHess = fit$sdr$pdHess,
    n_aggregated_rows = nrow(agg)
  )
}

# ------------------------------------------------------------------------------
# Final grid
# ------------------------------------------------------------------------------

grid_primary <- expand.grid(
  scenario = "primary",
  rho = RHO_VALUES,
  replication = seq_len(N_REP_PRIMARY),
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)

grid_robust <- expand.grid(
  scenario = "robust_user_target_heterogeneity",
  rho = RHO_VALUES,
  replication = seq_len(N_REP_ROBUST),
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)

grid <- rbind(grid_primary, grid_robust)
grid <- grid[order(grid$scenario, grid$replication, grid$rho), ]
grid$seed <- SEED_TARGET_LEARNING + 300000L + seq_len(nrow(grid))

results <- read_existing(raw_file)

# ------------------------------------------------------------------------------
# Run
# ------------------------------------------------------------------------------

cat("\nFinal Simulation 4: target-specific learning\n")
cat("--------------------------------------------\n")
cat(
  "Design: N=", N_USERS_MODULE,
  ", ", N_TARGETS_MODULE, " targets x ",
  ROUNDS_PER_TARGET_MODULE, " rounds x ",
  TL_JUDGMENTS_PER_ROUND, " judgments = ",
  N_TARGETS_MODULE * ROUNDS_PER_TARGET_MODULE * TL_JUDGMENTS_PER_ROUND,
  " judgments/user\n\n",
  sep = ""
)

for (j in seq_len(nrow(grid))) {
  job <- grid[j, ]

  already_done <- FALSE
  if (!is.null(results)) {
    already_done <- any(
      results$scenario == job$scenario &
        abs(results$rho_generating - job$rho) < 1e-12 &
        results$replication == job$replication
    )
  }
  if (already_done) next

  set.seed(job$seed)

  dat <- simulate_target_learning_dataset(
    n_users = N_USERS_MODULE,
    n_targets_per_user = N_TARGETS_MODULE,
    rounds_per_target = ROUNDS_PER_TARGET_MODULE,
    availability_matrix = availability_matrix,
    item_properties = item_properties,
    rho_negativity_learning = job$rho,
    keep_components = TRUE
  )

  include_user_target_learning <- (
    job$scenario == "robust_user_target_heterogeneity"
  )

  if (include_user_target_learning) {
    dat <- add_user_target_learning_heterogeneity(
      dat = dat,
      sd_user_target_learning = SD_USER_TARGET_LEARNING
    )
  }

  beta_true <- job$rho * TL_SD_LEARNING

  timed <- system.time(
    fit_safe <- safe_fit(
      fit_target_learning(
        dat,
        include_user_target_learning = include_user_target_learning
      )
    )
  )

  if (is.null(fit_safe$value)) {
    z <- list(
      beta = NA_real_, beta_se = NA_real_, beta_p = NA_real_,
      mean_learning = NA_real_, mean_learning_se = NA_real_,
      mean_learning_p = NA_real_, convergence = NA_integer_,
      pdHess = NA, n_aggregated_rows = NA_integer_
    )
  } else {
    z <- fit_safe$value
  }

  new_row <- data.frame(
    scenario = job$scenario,
    n_users = N_USERS_MODULE,
    n_targets = N_TARGETS_MODULE,
    rounds_per_target = ROUNDS_PER_TARGET_MODULE,
    judgments_per_user = (
      N_TARGETS_MODULE * ROUNDS_PER_TARGET_MODULE * TL_JUDGMENTS_PER_ROUND
    ),
    rho_generating = job$rho,
    beta_generating = beta_true,
    mean_learning_generating = TL_MEAN_LEARNING,
    sd_user_learning = TL_SD_LEARNING,
    sd_user_target_learning = if (include_user_target_learning) {
      SD_USER_TARGET_LEARNING
    } else {
      0
    },
    replication = job$replication,
    beta_estimated = unname(z$beta),
    beta_se = unname(z$beta_se),
    beta_p = unname(z$beta_p),
    mean_learning_estimated = unname(z$mean_learning),
    mean_learning_se = unname(z$mean_learning_se),
    mean_learning_p = unname(z$mean_learning_p),
    convergence = z$convergence,
    pdHess = z$pdHess,
    n_aggregated_rows = z$n_aggregated_rows,
    elapsed_seconds = timed["elapsed"],
    warnings = paste(fit_safe$warnings, collapse = " | "),
    error = fit_safe$error,
    stringsAsFactors = FALSE
  )

  results <- append_save(results, new_row, raw_file)

  cat(
    j, "/", nrow(grid),
    " | ", job$scenario,
    " | rho=", job$rho,
    " | rep=", job$replication,
    " | fit=", round(timed["elapsed"], 1), "s",
    " | total=", round(elapsed_minutes(), 1), "min\n",
    sep = ""
  )
}

# ------------------------------------------------------------------------------
# Summaries
# ------------------------------------------------------------------------------

groups <- split(
  results,
  interaction(results$scenario, results$rho_generating, drop = TRUE)
)

summary_rows <- lapply(groups, function(x) {
  usable <- is.finite(x$beta_estimated) & is.finite(x$beta_p)
  rr <- mean(x$beta_p[usable] < .05, na.rm = TRUE)
  n_usable <- sum(usable)

  data.frame(
    scenario = x$scenario[1],
    n_users = x$n_users[1],
    n_targets = x$n_targets[1],
    rounds_per_target = x$rounds_per_target[1],
    judgments_per_user = x$judgments_per_user[1],
    rho_generating = x$rho_generating[1],
    beta_generating = x$beta_generating[1],
    sd_user_learning = x$sd_user_learning[1],
    sd_user_target_learning = x$sd_user_target_learning[1],
    n_rep_completed = nrow(x),
    n_test_usable = n_usable,
    mean_beta_estimated = mean(x$beta_estimated[usable], na.rm = TRUE),
    mean_beta_se = mean(x$beta_se[usable], na.rm = TRUE),
    bias_beta = mean(
      x$beta_estimated[usable] - x$beta_generating[usable],
      na.rm = TRUE
    ),
    rejection_rate_05 = rr,
    mcse_rejection = sqrt(rr * (1 - rr) / n_usable),
    mean_learning_estimated = mean(x$mean_learning_estimated, na.rm = TRUE),
    mean_learning_rejection_rate = mean(
      x$mean_learning_p < .05, na.rm = TRUE
    ),
    nonzero_convergence_rate = mean(x$convergence != 0, na.rm = TRUE),
    non_pd_hessian_rate = mean(!as.logical(x$pdHess), na.rm = TRUE),
    mean_fit_seconds = mean(x$elapsed_seconds, na.rm = TRUE)
  )
})

summary_out <- do.call(rbind, summary_rows)
summary_out <- summary_out[
  order(summary_out$scenario, summary_out$rho_generating),
]

write.csv(summary_out, summary_file, row.names = FALSE)

cat("\nFINAL SIMULATION 4 SUMMARY\n")
print(summary_out, row.names = FALSE)

cat(
  "\nFinished after ", round(elapsed_minutes(), 1), " minutes.\n",
  sep = ""
)
cat(
  "Raw results were saved after every replication; rerun to resume incomplete cells.\n"
)
