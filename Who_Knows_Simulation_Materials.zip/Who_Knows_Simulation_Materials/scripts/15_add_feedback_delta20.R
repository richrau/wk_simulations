# scripts/15_add_feedback_delta20.R
# Extend Simulation 3 with feedback delta = .20 and report only
# feedback delta = 0, .10, .20 for symmetry.
#
# Assumes scripts/14_run_metacognition_final.R has already completed and that
# output/tables/metacognition_final_pre_raw.csv and
# output/tables/metacognition_final_feedback_raw.csv exist.
#
# Saves after every replication and safely resumes.

source(here::here("config.R"))
source(here::here("config_metacognition.R"))
source(here::here("helpers", "generate_design.R"))
source(here::here("helpers", "simulate_correctness.R"))
source(here::here("helpers", "simulate_metacognition.R"))

if (!requireNamespace("glmmTMB", quietly = TRUE)) {
  stop("Package 'glmmTMB' is required.")
}

NREP <- 200L
N <- 1000L
R <- 20L
DELTA_NEW <- .20
t0 <- Sys.time()

availability_matrix <- readRDS(META_AVAILABILITY_FILE)
item_properties <- readRDS(META_ITEM_PROPERTIES_FILE)

out <- here::here("output", "tables")
final_pre <- file.path(out, "metacognition_final_pre_raw.csv")
final_fb  <- file.path(out, "metacognition_final_feedback_raw.csv")
revised_summary_file <- file.path(out, "metacognition_final_summary_reported.csv")

if (!file.exists(final_pre)) {
  stop("Missing metacognition_final_pre_raw.csv. Run script 14 first.")
}
if (!file.exists(final_fb)) {
  stop("Missing metacognition_final_feedback_raw.csv. Run script 14 first.")
}

pre <- read.csv(final_pre, stringsAsFactors = FALSE)
fb  <- read.csv(final_fb, stringsAsFactors = FALSE)

elapsed_min <- function() {
  as.numeric(difftime(Sys.time(), t0, units = "mins"))
}

wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) {
    return(c(est = NA_real_, se = NA_real_, p = NA_real_))
  }
  c(
    est = unname(tab[hit, "Estimate"]),
    se  = unname(tab[hit, "Std. Error"]),
    p   = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe <- function(expr) {
  ww <- character()
  err <- NA_character_
  val <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        ww <<- c(ww, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      err <<- conditionMessage(e)
      NULL
    }
  )
  list(value = val, warnings = unique(ww), error = err)
}

aggregate_meta <- function(dat) {
  dat$one <- 1L

  a <- aggregate(
    cbind(n_correct = is_correct, n_total = one) ~
      user_id + phase + post + feedback_condition +
      negativity_z_person + confidence,
    data = dat,
    FUN = sum
  )

  a$weighted_conf <- a$confidence * a$n_total

  pm <- aggregate(
    cbind(weighted_conf = weighted_conf, phase_n = n_total) ~
      user_id + phase,
    data = a,
    FUN = sum
  )

  pm$confidence_pm_phase <- pm$weighted_conf / pm$phase_n

  a <- merge(
    a,
    pm[, c("user_id", "phase", "confidence_pm_phase")],
    by = c("user_id", "phase"),
    all.x = TRUE,
    sort = FALSE
  )

  a$confidence_wc_phase <- a$confidence - a$confidence_pm_phase
  a$n_incorrect <- a$n_total - a$n_correct
  a$user_id <- factor(a$user_id)

  a
}

fit_fb <- function(dat) {
  a <- aggregate_meta(dat)

  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase +
      confidence_wc_phase * post * feedback_condition +
      (1 | user_id) +
      (0 + confidence_wc_phase | user_id),
    data = a,
    family = binomial()
  )

  z <- wald(
    fit,
    "^confidence_wc_phase:post:feedback_conditionfeedback$|^confidence_wc_phase:feedback_conditionfeedback:post$|^post:confidence_wc_phase:feedback_conditionfeedback$|^post:feedback_conditionfeedback:confidence_wc_phase$|^feedback_conditionfeedback:confidence_wc_phase:post$|^feedback_conditionfeedback:post:confidence_wc_phase$"
  )

  list(
    est = z["est"],
    se = z["se"],
    p = z["p"],
    convergence = fit$fit$convergence,
    pdHess = fit$sdr$pdHess,
    n_agg = nrow(a)
  )
}

dedupe_fb <- function(x) {
  key <- x[, c(
    "n_users",
    "n_rounds_per_phase",
    "feedback_delta_generating",
    "replication"
  )]
  x[!duplicated(key), ]
}

have <- fb$replication[
  fb$n_users == N &
    fb$n_rounds_per_phase == R &
    abs(fb$feedback_delta_generating - DELTA_NEW) < 1e-12
]

todo <- setdiff(seq_len(NREP), have)

cat(
  "\nAdding feedback delta = .20: ",
  length(have), " existing, ",
  length(todo), " remaining\n",
  sep = ""
)

for (rep in todo) {

  set.seed(
    SEED_METACOGNITION +
      1000000L +
      30000L +
      rep
  )

  dat <- simulate_metacognition_dataset(
    n_users = N,
    n_pre_rounds = R,
    n_post_rounds = R,
    availability_matrix = availability_matrix,
    item_properties = item_properties,
    rho_negativity_sensitivity = 0,
    feedback_delta = DELTA_NEW,
    randomized_feedback = TRUE,
    keep_components = FALSE
  )

  tm <- system.time(
    s <- safe(
      fit_fb(dat)
    )
  )

  z <- if (is.null(s$value)) {
    list(
      est = NA_real_,
      se = NA_real_,
      p = NA_real_,
      convergence = NA_integer_,
      pdHess = NA,
      n_agg = NA_integer_
    )
  } else {
    s$value
  }

  row <- data.frame(
    n_users = N,
    n_rounds_per_phase = R,
    feedback_delta_generating = DELTA_NEW,
    replication = rep,
    delta_estimated = unname(z$est),
    se_estimated = unname(z$se),
    wald_p = unname(z$p),
    convergence = z$convergence,
    pdHess = z$pdHess,
    n_aggregated_rows = z$n_agg,
    elapsed_seconds = tm["elapsed"],
    warnings = paste(s$warnings, collapse = " | "),
    error = s$error,
    stringsAsFactors = FALSE
  )

  fb <- dedupe_fb(rbind(fb, row))
  write.csv(fb, final_fb, row.names = FALSE)

  cat(
    "delta=.20 rep=", rep, "/", NREP,
    " | fit=", round(tm["elapsed"], 1), "s",
    " | total=", round(elapsed_min(), 1), "min\n",
    sep = ""
  )
}

summarize_cell <- function(dat, estvar, truevar, label) {
  ok <- is.finite(dat[[estvar]]) & is.finite(dat$wald_p)
  rr <- mean(dat$wald_p[ok] < .05)
  nn <- sum(ok)

  data.frame(
    analysis = label,
    n_rep = nrow(dat),
    n_usable = nn,
    generating_effect = dat[[truevar]][1],
    mean_estimate = mean(dat[[estvar]][ok]),
    bias = mean(dat[[estvar]][ok] - dat[[truevar]][ok]),
    mean_se = mean(dat$se_estimated[ok]),
    rejection_rate_05 = rr,
    mcse_rejection = sqrt(rr * (1 - rr) / nn),
    nonzero_convergence_rate = mean(dat$convergence != 0, na.rm = TRUE),
    non_pd_hessian_rate = mean(!as.logical(dat$pdHess), na.rm = TRUE),
    mean_fit_seconds = mean(dat$elapsed_seconds, na.rm = TRUE)
  )
}

P0 <- pre[abs(pre$rho_generating - 0) < 1e-12, ]
P2 <- pre[abs(pre$rho_generating - .20) < 1e-12, ]

F0 <- fb[
  fb$n_users == N &
    fb$n_rounds_per_phase == R &
    abs(fb$feedback_delta_generating - 0) < 1e-12,
]

F1 <- fb[
  fb$n_users == N &
    fb$n_rounds_per_phase == R &
    abs(fb$feedback_delta_generating - .10) < 1e-12,
]

F2 <- fb[
  fb$n_users == N &
    fb$n_rounds_per_phase == R &
    abs(fb$feedback_delta_generating - .20) < 1e-12,
]

summary_reported <- rbind(
  summarize_cell(
    P0,
    "beta_estimated",
    "beta_generating",
    "Pre-feedback: rho = 0"
  ),
  summarize_cell(
    P2,
    "beta_estimated",
    "beta_generating",
    "Pre-feedback: rho = .20"
  ),
  summarize_cell(
    F0,
    "delta_estimated",
    "feedback_delta_generating",
    "Feedback: delta = 0"
  ),
  summarize_cell(
    F1,
    "delta_estimated",
    "feedback_delta_generating",
    "Feedback: delta = .10"
  ),
  summarize_cell(
    F2,
    "delta_estimated",
    "feedback_delta_generating",
    "Feedback: delta = .20"
  )
)

write.csv(
  summary_reported,
  revised_summary_file,
  row.names = FALSE
)

cat("\nREVISED SIMULATION 3 SUMMARY FOR REPORTING\n")
print(summary_reported, row.names = FALSE)

cat(
  "\nThe delta = .05 condition remains in the raw results but is intentionally omitted from the reporting summary.\n"
)
