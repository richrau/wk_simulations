# scripts/13_run_metacognition_aggregated_pilot.R
# Fast pilot for Simulation 3 using user x phase x confidence binomial counts.

source(here::here("config.R"))
source(here::here("config_metacognition.R"))
source(here::here("helpers", "generate_design.R"))
source(here::here("helpers", "simulate_correctness.R"))
source(here::here("helpers", "simulate_metacognition.R"))

if (!requireNamespace("glmmTMB", quietly = TRUE)) stop("Package 'glmmTMB' is required.")

N_REP <- 100L
MAX_RUNTIME_MINUTES <- 30
START_TIME <- Sys.time()

availability_matrix <- readRDS(META_AVAILABILITY_FILE)
item_properties <- readRDS(META_ITEM_PROPERTIES_FILE)

out_dir <- here::here("output", "tables")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

pre_file <- file.path(out_dir, "metacognition_aggregated_pre_pilot_raw.csv")
fb_file  <- file.path(out_dir, "metacognition_aggregated_feedback_pilot_raw.csv")

elapsed_minutes <- function() {
  as.numeric(difftime(Sys.time(), START_TIME, units = "mins"))
}

extract_wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) return(c(est = NA_real_, se = NA_real_, p = NA_real_))
  c(
    est = unname(tab[hit, "Estimate"]),
    se  = unname(tab[hit, "Std. Error"]),
    p   = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe_fit <- function(expr) {
  warnings <- character()
  error <- NA_character_
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      error <<- conditionMessage(e)
      NULL
    }
  )
  list(value = value, warnings = unique(warnings), error = error)
}

aggregate_meta <- function(dat) {
  dat$one <- 1L
  agg <- aggregate(
    cbind(n_correct = is_correct, n_total = one) ~
      user_id + phase + post + feedback_condition +
      negativity_z_person + confidence,
    data = dat,
    FUN = sum
  )
  agg$weighted_conf <- agg$confidence * agg$n_total
  pm <- aggregate(
    cbind(weighted_conf = weighted_conf, phase_n = n_total) ~ user_id + phase,
    data = agg,
    FUN = sum
  )
  pm$confidence_pm_phase <- pm$weighted_conf / pm$phase_n
  agg <- merge(
    agg,
    pm[, c("user_id", "phase", "confidence_pm_phase")],
    by = c("user_id", "phase"),
    all.x = TRUE,
    sort = FALSE
  )
  agg$confidence_wc_phase <- agg$confidence - agg$confidence_pm_phase
  agg$n_incorrect <- agg$n_total - agg$n_correct
  agg$user_id <- factor(agg$user_id)
  agg
}

fit_pre <- function(dat) {
  agg <- aggregate_meta(dat[dat$post == 0L, ])
  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase +
      negativity_z_person +
      confidence_wc_phase * negativity_z_person +
      (1 | user_id) +
      (0 + confidence_wc_phase | user_id),
    data = agg,
    family = binomial()
  )
  w <- extract_wald(
    fit,
    "^(confidence_wc_phase:negativity_z_person|negativity_z_person:confidence_wc_phase)$"
  )
  c(
    est = w["est"], se = w["se"], p = w["p"],
    conv = fit$fit$convergence,
    pdHess = as.integer(fit$sdr$pdHess),
    n_agg = nrow(agg)
  )
}

fit_fb <- function(dat) {
  agg <- aggregate_meta(dat)
  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase +
      confidence_wc_phase * post * feedback_condition +
      (1 | user_id) +
      (0 + confidence_wc_phase | user_id),
    data = agg,
    family = binomial()
  )
  w <- extract_wald(
    fit,
    "^confidence_wc_phase:post:feedback_conditionfeedback$|^confidence_wc_phase:feedback_conditionfeedback:post$|^post:confidence_wc_phase:feedback_conditionfeedback$|^post:feedback_conditionfeedback:confidence_wc_phase$|^feedback_conditionfeedback:confidence_wc_phase:post$|^feedback_conditionfeedback:post:confidence_wc_phase$"
  )
  c(
    est = w["est"], se = w["se"], p = w["p"],
    conv = fit$fit$convergence,
    pdHess = as.integer(fit$sdr$pdHess),
    n_agg = nrow(agg)
  )
}

read_existing <- function(path) {
  if (!file.exists(path)) return(NULL)
  x <- read.csv(path, stringsAsFactors = FALSE)
  if (nrow(x) == 0L) NULL else x
}

append_save <- function(old, row, path) {
  out <- if (is.null(old)) row else rbind(old, row)
  write.csv(out, path, row.names = FALSE)
  out
}

done_pre <- function(x, N, rounds, rho, rep) {
  !is.null(x) && any(
    x$n_users == N & x$n_pre_rounds == rounds &
      abs(x$rho_generating - rho) < 1e-12 & x$replication == rep
  )
}

done_fb <- function(x, N, rounds, delta, rep) {
  !is.null(x) && any(
    x$n_users == N & x$n_rounds_per_phase == rounds &
      abs(x$feedback_delta_generating - delta) < 1e-12 & x$replication == rep
  )
}

pre_results <- read_existing(pre_file)
fb_results <- read_existing(fb_file)

pre_grid <- expand.grid(
  n_users = c(500L, 1000L),
  n_pre_rounds = c(10L, 20L),
  rho = c(0, .20),
  replication = seq_len(N_REP),
  KEEP.OUT.ATTRS = FALSE
)
pre_grid$seed <- SEED_METACOGNITION + 700000L + seq_len(nrow(pre_grid))

cat("\nAggregated Simulation 3A pilot\n")
for (j in seq_len(nrow(pre_grid))) {
  if (elapsed_minutes() >= MAX_RUNTIME_MINUTES) break
  job <- pre_grid[j, ]
  if (done_pre(pre_results, job$n_users, job$n_pre_rounds, job$rho, job$replication)) next

  set.seed(job$seed)
  dat <- simulate_metacognition_dataset(
    n_users = job$n_users,
    n_pre_rounds = job$n_pre_rounds,
    n_post_rounds = 0L,
    availability_matrix = availability_matrix,
    item_properties = item_properties,
    rho_negativity_sensitivity = job$rho,
    feedback_delta = 0,
    randomized_feedback = FALSE,
    keep_components = FALSE
  )

  tm <- system.time(res <- safe_fit(fit_pre(dat)))
  z <- if (is.null(res$value)) rep(NA_real_, 6) else unname(res$value)

  row <- data.frame(
    n_users = job$n_users,
    n_pre_rounds = job$n_pre_rounds,
    rho_generating = job$rho,
    beta_generating = job$rho * META_SD_SENSITIVITY,
    replication = job$replication,
    beta_estimated = z[1],
    se_estimated = z[2],
    wald_p = z[3],
    convergence = z[4],
    pdHess = z[5],
    n_aggregated_rows = z[6],
    elapsed_seconds = tm["elapsed"],
    warnings = paste(res$warnings, collapse = " | "),
    error = res$error
  )
  pre_results <- append_save(pre_results, row, pre_file)

  cat(
    "PRE ", j, "/", nrow(pre_grid),
    " | N=", job$n_users,
    ", rounds=", job$n_pre_rounds,
    ", rho=", job$rho,
    " | fit=", round(tm["elapsed"], 1), "s",
    " | total=", round(elapsed_minutes(), 1), "min\n",
    sep = ""
  )
}

fb_grid <- expand.grid(
  n_users = c(500L, 1000L),
  n_rounds_per_phase = c(10L, 20L),
  feedback_delta = c(0, .10),
  replication = seq_len(N_REP),
  KEEP.OUT.ATTRS = FALSE
)
fb_grid$seed <- SEED_METACOGNITION + 800000L + seq_len(nrow(fb_grid))

cat("\nAggregated Simulation 3B pilot\n")
for (j in seq_len(nrow(fb_grid))) {
  if (elapsed_minutes() >= MAX_RUNTIME_MINUTES) break
  job <- fb_grid[j, ]
  if (done_fb(fb_results, job$n_users, job$n_rounds_per_phase, job$feedback_delta, job$replication)) next

  set.seed(job$seed)
  dat <- simulate_metacognition_dataset(
    n_users = job$n_users,
    n_pre_rounds = job$n_rounds_per_phase,
    n_post_rounds = job$n_rounds_per_phase,
    availability_matrix = availability_matrix,
    item_properties = item_properties,
    rho_negativity_sensitivity = 0,
    feedback_delta = job$feedback_delta,
    randomized_feedback = TRUE,
    keep_components = FALSE
  )

  tm <- system.time(res <- safe_fit(fit_fb(dat)))
  z <- if (is.null(res$value)) rep(NA_real_, 6) else unname(res$value)

  row <- data.frame(
    n_users = job$n_users,
    n_rounds_per_phase = job$n_rounds_per_phase,
    feedback_delta_generating = job$feedback_delta,
    replication = job$replication,
    delta_estimated = z[1],
    se_estimated = z[2],
    wald_p = z[3],
    convergence = z[4],
    pdHess = z[5],
    n_aggregated_rows = z[6],
    elapsed_seconds = tm["elapsed"],
    warnings = paste(res$warnings, collapse = " | "),
    error = res$error
  )
  fb_results <- append_save(fb_results, row, fb_file)

  cat(
    "FB ", j, "/", nrow(fb_grid),
    " | N=", job$n_users,
    ", rounds=", job$n_rounds_per_phase,
    ", delta=", job$feedback_delta,
    " | fit=", round(tm["elapsed"], 1), "s",
    " | total=", round(elapsed_minutes(), 1), "min\n",
    sep = ""
  )
}

summ <- function(dat, groups, est, truth) {
  if (is.null(dat) || nrow(dat) == 0L) return(NULL)
  spl <- split(dat, interaction(dat[, groups, drop = FALSE], drop = TRUE))
  do.call(rbind, lapply(spl, function(x) {
    ok <- is.finite(x[[est]]) & is.finite(x$wald_p)
    cbind(
      x[1, groups, drop = FALSE],
      data.frame(
        n_rep_completed = nrow(x),
        n_test_usable = sum(ok),
        mean_estimated = mean(x[[est]][ok], na.rm = TRUE),
        mean_se = mean(x$se_estimated[ok], na.rm = TRUE),
        bias = mean(x[[est]][ok] - x[[truth]][ok], na.rm = TRUE),
        rejection_rate_05 = mean(x$wald_p[ok] < .05, na.rm = TRUE),
        nonzero_convergence_rate = mean(x$convergence != 0, na.rm = TRUE),
        non_pd_hessian_rate = mean(x$pdHess != 1, na.rm = TRUE),
        mean_fit_seconds = mean(x$elapsed_seconds, na.rm = TRUE)
      )
    )
  }))
}

pre_summary <- summ(
  pre_results,
  c("n_users", "n_pre_rounds", "rho_generating", "beta_generating"),
  "beta_estimated",
  "beta_generating"
)

fb_summary <- summ(
  fb_results,
  c("n_users", "n_rounds_per_phase", "feedback_delta_generating"),
  "delta_estimated",
  "feedback_delta_generating"
)

if (!is.null(pre_summary)) {
  write.csv(
    pre_summary,
    file.path(out_dir, "metacognition_aggregated_pre_pilot_summary.csv"),
    row.names = FALSE
  )
  cat("\nPRE-FEEDBACK AGGREGATED PILOT SUMMARY\n")
  print(pre_summary, row.names = FALSE)
}

if (!is.null(fb_summary)) {
  write.csv(
    fb_summary,
    file.path(out_dir, "metacognition_aggregated_feedback_pilot_summary.csv"),
    row.names = FALSE
  )
  cat("\nFEEDBACK AGGREGATED PILOT SUMMARY\n")
  print(fb_summary, row.names = FALSE)
}

cat("\nFinished after ", round(elapsed_minutes(), 1), " minutes.\n", sep = "")
cat("Results are saved after every replication; rerun to resume.\n")
