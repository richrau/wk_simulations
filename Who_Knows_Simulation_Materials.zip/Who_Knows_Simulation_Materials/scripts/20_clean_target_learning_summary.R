# ==============================================================================
# scripts/20_clean_target_learning_summary.R
# Re-summarize existing Simulation 4 results; no simulation or model fitting.
# Run from the same R project as Script 19. Requires only 'here'.
# Preserves the original raw CSV and summary.
# ==============================================================================

local({
  if (!requireNamespace("here", quietly = TRUE)) {
    stop("Package 'here' is required to locate the project output directory.")
  }
  out_dir <- here::here("output", "tables")
  raw_file <- file.path(out_dir, "target_learning_final_raw.csv")
  if (!file.exists(raw_file)) stop("Raw results not found: ", raw_file)

  x <- read.csv(raw_file, stringsAsFactors = FALSE)
  required <- c(
    "scenario", "rho_generating", "replication", "n_users", "n_targets",
    "rounds_per_target", "judgments_per_user", "beta_generating",
    "sd_user_learning", "sd_user_target_learning", "beta_estimated", "beta_se",
    "beta_p", "mean_learning_estimated", "mean_learning_se", "mean_learning_p",
    "convergence", "pdHess"
  )
  missing <- setdiff(required, names(x))
  if (length(missing)) stop("Missing columns: ", paste(missing, collapse = ", "))
  if (!nrow(x)) stop("The raw results file is empty.")
  keys <- c("scenario", "rho_generating", "replication")
  if (anyNA(x[keys])) stop("Missing scenario, rho, or replication identifiers.")
  if (anyDuplicated(x[keys])) stop("Duplicate replication identifiers in raw results.")

  # Accept the TRUE/FALSE values written by Script 19, and numeric 1/0.
  hessian_text <- tolower(trimws(as.character(x$pdHess)))
  known_hessian <- is.na(hessian_text) |
    hessian_text %in% c("true", "false", "1", "0", "na", "")
  if (any(!known_hessian)) stop("Unrecognized pdHess values in raw results.")
  hessian_ok <- !is.na(hessian_text) & hessian_text %in% c("true", "1")
  convergence_ok <- !is.na(x$convergence) & x$convergence == 0
  fit_ok <- convergence_ok & hessian_ok
  valid_test <- function(estimate, se, p) {
    is.finite(estimate) & is.finite(se) & se > 0 &
      is.finite(p) & p >= 0 & p <= 1
  }
  focal_ok <- valid_test(x$beta_estimated, x$beta_se, x$beta_p)
  learning_ok <- valid_test(
    x$mean_learning_estimated, x$mean_learning_se, x$mean_learning_p
  )
  x$clean_focal_usable <- fit_ok & focal_ok
  x$clean_learning_usable <- fit_ok & learning_ok

  # Reasons can overlap. The overall excluded count counts each fit only once.
  reasons <- rep("", nrow(x))
  add_reason <- function(flag, label) {
    reasons[flag] <<- ifelse(
      reasons[flag] == "", label, paste(reasons[flag], label, sep = "; ")
    )
  }
  add_reason(!convergence_ok, "nonzero or missing convergence code")
  add_reason(!hessian_ok, "non-positive-definite or missing Hessian status")
  add_reason(!focal_ok, "invalid focal estimate, SE, or p-value")
  add_reason(!learning_ok, "invalid mean-learning estimate, SE, or p-value")
  x$cleanup_reason <- reasons

  average <- function(z) if (length(z)) mean(z) else NA_real_
  mcse <- function(rate, n) if (n > 0L) sqrt(rate * (1 - rate) / n) else NA_real_
  groups <- split(x, interaction(x$scenario, x$rho_generating, drop = TRUE))
  summaries <- lapply(groups, function(g) {
    metadata <- c(
      "scenario", "n_users", "n_targets", "rounds_per_target",
      "judgments_per_user", "rho_generating", "beta_generating",
      "sd_user_learning", "sd_user_target_learning"
    )
    for (nm in metadata) {
      if (length(unique(g[[nm]])) != 1L || anyNA(g[[nm]])) {
        stop("Inconsistent or missing design metadata within cell: ", nm)
      }
    }
    # Reproduce Script 19's original focal inclusion rule for comparison.
    old <- is.finite(g$beta_estimated) & is.finite(g$beta_p)
    use <- g$clean_focal_usable
    learn <- g$clean_learning_usable
    rate_old <- average(g$beta_p[old] < .05)
    rate <- average(g$beta_p[use] < .05)
    n <- sum(use)
    cbind(g[1, metadata, drop = FALSE], data.frame(
      n_rep_completed = nrow(g),
      n_test_usable_original = sum(old),
      n_test_usable_clean = n,
      n_excluded_clean = sum(!use),
      excluded_fraction = mean(!use),
      rejection_rate_original = rate_old,
      rejection_rate_clean = rate,
      change_percentage_points = 100 * (rate - rate_old),
      mcse_rejection_clean = mcse(rate, n),
      mean_beta_estimated_clean = average(g$beta_estimated[use]),
      mean_beta_se_clean = average(g$beta_se[use]),
      n_mean_learning_usable = sum(learn),
      mean_learning_estimated_clean = average(g$mean_learning_estimated[learn]),
      mean_learning_rejection_rate_clean = average(g$mean_learning_p[learn] < .05)
    ))
  })
  summary_out <- do.call(rbind, summaries)
  summary_out <- summary_out[
    order(summary_out$scenario, summary_out$rho_generating), , drop = FALSE
  ]
  rownames(summary_out) <- NULL

  summary_file <- file.path(out_dir, "target_learning_final_summary_clean.csv")
  audit_file <- file.path(out_dir, "target_learning_final_excluded_fits.csv")
  write.csv(summary_out, summary_file, row.names = FALSE)
  excluded <- x[!x$clean_focal_usable | !x$clean_learning_usable, , drop = FALSE]
  write.csv(excluded, audit_file, row.names = FALSE)

  cat("\nSIMULATION 4: CLEANED SUMMARY\n")
  print(summary_out, row.names = FALSE)
  cat("\nClean rates are conditional on usable fits; exclusions are reported separately.\n")
  cat("Generating beta is retained as scenario metadata, not a bias benchmark\n")
  cat("for the deliberately aggregated analysis.\n")
  cat("\nSummary: ", summary_file, "\n", sep = "")
  cat("Excluded-fit audit: ", audit_file, "\n", sep = "")
  cat("\nNo models were refitted. Original results were preserved.\n")
})
