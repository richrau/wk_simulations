# scripts/22_run_bfi_power_extension_n3000.R
# Simulation 2: N=3000, 3x engagement, rho=.20; 200 replications.
# Place in scripts/ and source from your existing simulation R project.
# Uses your current configs, helpers and calibration files without modifying them.
# Corrected engagement scope: matches Script 10 global sourcing.
# Runs sequentially, saves each attempt, and resumes when sourced again.
(function() {
for (pkg in c("here", "lme4")) {
  if (!requireNamespace(pkg, quietly = TRUE)) stop("Package required: ", pkg)
}
source_files <- c(here::here("config.R"), here::here("config_bfi_accuracy.R"),
  here::here("helpers", "generate_design.R"), here::here("helpers", "generate_bfi_design.R"), here::here("helpers", "simulate_bfi_moderation.R"))
if (any(!file.exists(source_files))) stop("Missing source file: ",
  paste(source_files[!file.exists(source_files)], collapse = ", "))
# generate_bfi_design temporarily changes ENGAGEMENT_MEANLOG in .GlobalEnv.
# Both configs and helper closures must therefore use that same environment,
# exactly as in the original Script 10.
for (file in source_files) source(file, local = .GlobalEnv)
N_REP <- 200L
RUN_NAME <- "bfi_power_extension_n3000_engagement3x_fixed"
settings <- list(n_users = 3000L, engagement_scale = 3, rho = .20,
                 seed_base = SEED_BFI_SIMULATION + 3000000L)
calibration_files <- c(CORRECTNESS_CALIBRATION_FILE,
                      BFI_ITEM_PARAMETERS_FILE, BFI_TARGET_RESPONSES_FILE)
item_parameters <- read.csv(BFI_ITEM_PARAMETERS_FILE, stringsAsFactors = FALSE)
target_responses <- read.csv(BFI_TARGET_RESPONSES_FILE, stringsAsFactors = FALSE)
extract_focal_beta <- function(fit) {

  b <- lme4::fixef(fit)

  candidates <- c(
    "negativity_z:criterion_z",
    "criterion_z:negativity_z"
  )

  hit <- candidates[candidates %in% names(b)]

  if (length(hit) != 1L) {
    return(NA_real_)
  }

  unname(b[hit])
}


# ------------------------------------------------------------------------------
# One-replication helper
# ------------------------------------------------------------------------------

run_one_bfi_moderation_replication <- function(
  scenario_name,
  n_users,
  engagement_scale,
  rho,
  replication,
  seed,
  item_parameters,
  target_responses
) {

  # Independent check of the exact intended round-count vector. Resetting the
  # seed before generation preserves the simulation RNG sequence.
  stopifnot(ENGAGEMENT_DISTRIBUTION == "lognormal")
  set.seed(seed)
  expected_round_counts <- pmin(MAX_ROUNDS, pmax(MIN_ROUNDS,
    as.integer(round(rlnorm(n_users,
      meanlog = ENGAGEMENT_MEANLOG + log(engagement_scale),
      sdlog = ENGAGEMENT_SDLOG)))))
  set.seed(seed)

  # --------------------------------------------------------------------------
  # Generate sparse design and simulated judgments
  # --------------------------------------------------------------------------

  design <- generate_bfi_design(
    n_users = n_users,
    target_responses = target_responses,
    engagement_scale = engagement_scale
  )

  round_counts <- attr(design, "round_counts")
  if (!identical(as.integer(round_counts), as.integer(expected_round_counts))) {
    stop("Engagement check failed: generated round counts do not match the requested multiplier.")
  }
  if (nrow(design) != sum(expected_round_counts)) {
    stop("Design check failed: expected one BFI judgment per generated round.")
  }

  dat <- simulate_bfi_moderation(
    design = design,
    item_parameters = item_parameters,
    rho_negativity_accuracy = rho,
    keep_components = FALSE
  )

  beta_generating <- attr(dat, "beta_negativity_accuracy")

  rm(design)

  dat$user_id <- factor(dat$user_id)
  dat$item_id <- factor(dat$item_id)

  # --------------------------------------------------------------------------
  # Analysis model
  #
  # Negativity is now an independently measured person-level predictor.
  # The focal parameter is negativity_z x criterion_z.
  #
  # negativity_z x desirability_z is retained so that the ordinary evaluative
  # manifestation of negativity does not get conflated with accuracy.
  #
  # The user intercept and residual criterion slope are fitted as uncorrelated
  # nuisance random effects; their covariance is not a substantive target.
  # --------------------------------------------------------------------------

  formula_full <- (
    judgment ~
      item_id +
      negativity_z +
      criterion_z +
      negativity_z:desirability_z +
      negativity_z:criterion_z +
      (1 + criterion_z || user_id)
  )

  formula_reduced <- (
    judgment ~
      item_id +
      negativity_z +
      criterion_z +
      negativity_z:desirability_z +
      (1 + criterion_z || user_id)
  )

  control <- lme4::lmerControl(
    optimizer = "bobyqa",
    optCtrl = list(maxfun = 100000)
  )

  warning_messages <- character(0)
  error_message <- NA_character_

  fit_reduced <- NULL
  fit_full <- NULL

  elapsed <- system.time({

    fits <- tryCatch(
      withCallingHandlers(
        {
          fit_reduced_local <- lme4::lmer(
            formula_reduced,
            data = dat,
            REML = FALSE,
            control = control
          )

          fit_full_local <- lme4::lmer(
            formula_full,
            data = dat,
            REML = FALSE,
            control = control
          )

          list(
            reduced = fit_reduced_local,
            full = fit_full_local
          )
        },
        warning = function(w) {
          warning_messages <<- c(
            warning_messages,
            conditionMessage(w)
          )
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) {
        error_message <<- conditionMessage(e)
        NULL
      }
    )

    if (!is.null(fits)) {
      fit_reduced <- fits$reduced
      fit_full <- fits$full
    }

  })["elapsed"]

  # --------------------------------------------------------------------------
  # Failed fit
  # --------------------------------------------------------------------------

  if (is.null(fit_reduced) || is.null(fit_full)) {

    return(data.frame(
      scenario = scenario_name,
      n_users = n_users,
      engagement_scale = engagement_scale,
      rho_generating = rho,
      beta_generating = beta_generating,
      replication = replication,
      seed = seed,
      n_judgments = nrow(dat),
      mean_rounds = mean(round_counts),
      median_rounds = median(round_counts),
      beta_estimated = NA_real_,
      lrt_chisq = NA_real_,
      lrt_p = NA_real_,
      reject_05 = NA,
      mean_accuracy_slope_est = NA_real_,
      sd_accuracy_residual_est = NA_real_,
      residual_sd_est = NA_real_,
      optimizer_full = NA_integer_,
      optimizer_reduced = NA_integer_,
      convergence_messages_full = NA_character_,
      convergence_messages_reduced = NA_character_,
      singular_full = NA,
      singular_reduced = NA,
      elapsed_seconds = as.numeric(elapsed),
      n_warnings = length(unique(warning_messages)),
      warnings = paste(unique(warning_messages), collapse = " | "),
      error = error_message,
      stringsAsFactors = FALSE
    ))
  }

  # --------------------------------------------------------------------------
  # Extract focal interaction and likelihood-ratio test
  # --------------------------------------------------------------------------

  beta_estimated <- extract_focal_beta(fit_full)

  lrt <- tryCatch(
    anova(fit_reduced, fit_full, refit = FALSE),
    error = function(e) NULL
  )

  if (!is.null(lrt) && nrow(lrt) >= 2L) {
    lrt_chisq <- lrt$Chisq[2]
    lrt_p <- lrt$`Pr(>Chisq)`[2]
  } else {
    lrt_chisq <- NA_real_
    lrt_p <- NA_real_
  }

  fixed_effects <- lme4::fixef(fit_full)

  mean_accuracy_slope_est <- if (
    "criterion_z" %in% names(fixed_effects)
  ) {
    unname(fixed_effects["criterion_z"])
  } else {
    NA_real_
  }

  vc <- as.data.frame(lme4::VarCorr(fit_full))

  slope_row <- vc[
    vc$var1 == "criterion_z" &
      is.na(vc$var2),
    ,
    drop = FALSE
  ]

  sd_accuracy_residual_est <- if (nrow(slope_row) == 1L) {
    slope_row$sdcor[1]
  } else {
    NA_real_
  }

  data.frame(
    scenario = scenario_name,
    n_users = n_users,
    engagement_scale = engagement_scale,
    rho_generating = rho,
    beta_generating = beta_generating,
    replication = replication,
    seed = seed,
    n_judgments = nrow(dat),
    mean_rounds = mean(round_counts),
    median_rounds = median(round_counts),
    beta_estimated = beta_estimated,
    lrt_chisq = lrt_chisq,
    lrt_p = lrt_p,
    reject_05 = !is.na(lrt_p) && lrt_p < .05,
    mean_accuracy_slope_est = mean_accuracy_slope_est,
    sd_accuracy_residual_est = sd_accuracy_residual_est,
    residual_sd_est = sigma(fit_full),
    optimizer_full = as.integer(fit_full@optinfo$conv$opt[1]),
    optimizer_reduced = as.integer(fit_reduced@optinfo$conv$opt[1]),
    convergence_messages_full = paste(fit_full@optinfo$conv$lme4$messages, collapse = " | "),
    convergence_messages_reduced = paste(fit_reduced@optinfo$conv$lme4$messages, collapse = " | "),
    singular_full = lme4::isSingular(fit_full),
    singular_reduced = lme4::isSingular(fit_reduced),
    elapsed_seconds = as.numeric(elapsed),
    n_warnings = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    error = NA_character_,
    stringsAsFactors = FALSE
  )
}



average <- function(x) if (length(x)) mean(x) else NA_real_
mcse <- function(p, n) if (n > 0L) sqrt(p * (1 - p) / n) else NA_real_
valid_test <- function(est, se, p) {
  is.finite(est) & is.finite(se) & se > 0 & is.finite(p) & p >= 0 & p <= 1
}

run_one <- function(rep_id, seed) {
  run_one_bfi_moderation_replication(RUN_NAME, settings$n_users,
    settings$engagement_scale, settings$rho, rep_id, seed,
    item_parameters, target_responses)
}
audit_rows <- function(x) {
  !is.finite(x$lrt_p) | is.na(x$optimizer_full) | x$optimizer_full != 0 |
    is.na(x$optimizer_reduced) | x$optimizer_reduced != 0 |
    is.na(x$singular_full) | x$singular_full |
    is.na(x$singular_reduced) | x$singular_reduced |
    is.na(x$convergence_messages_full) | nzchar(x$convergence_messages_full) |
    is.na(x$convergence_messages_reduced) | nzchar(x$convergence_messages_reduced) |
    x$n_warnings > 0
}
summarize_results <- function(x) {
  ok <- is.finite(x$lrt_p)  # Same usability rule as Script 10.
  beta_ok <- is.finite(x$beta_estimated)
  rate <- average(x$lrt_p[ok] < .05)
  data.frame(scenario = RUN_NAME, n_users = settings$n_users,
    engagement_scale = settings$engagement_scale, rho_generating = settings$rho,
    beta_generating = settings$rho * BFI_SD_ACCURACY,
    n_rep_completed = nrow(x), n_test_usable = sum(ok),
    n_excluded = sum(!ok), rejection_rate_05 = rate,
    mcse_rejection = mcse(rate, sum(ok)),
    mean_beta_estimated = average(x$beta_estimated[beta_ok]),
    mean_rounds = mean(x$mean_rounds, na.rm = TRUE),
    mean_n_judgments = mean(x$n_judgments, na.rm = TRUE),
    singular_full_rate = mean(x$singular_full, na.rm = TRUE),
    singular_reduced_rate = mean(x$singular_reduced, na.rm = TRUE),
    n_nonzero_or_missing_optimizer_full = sum(is.na(x$optimizer_full) | x$optimizer_full != 0),
    n_nonzero_or_missing_optimizer_reduced = sum(is.na(x$optimizer_reduced) | x$optimizer_reduced != 0),
    n_flagged_for_review = sum(audit_rows(x)),
    mean_fit_seconds = mean(x$elapsed_seconds, na.rm = TRUE))
}
SUMMARY_NOTE <- "Power uses finite LRT p-values, as in Script 10. Singular fits are retained and reported; the audit records diagnostics."

# Separate checkpoints; each completed attempt (including failed fits) is saved.
# Increasing N_REP adds replications. Changing scientific inputs stops resumption.
stopifnot(length(N_REP) == 1L, N_REP >= 1L, N_REP < 100000L)
output_dir <- here::here("output", "tables")
checkpoint_dir <- here::here("output", "checkpoints", RUN_NAME)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
raw_file <- file.path(output_dir, paste0(RUN_NAME, "_raw.csv"))
summary_file <- file.path(output_dir, paste0(RUN_NAME, "_summary.csv"))
audit_file <- file.path(output_dir, paste0(RUN_NAME, "_fit_audit.csv"))
input_files <- unique(c(source_files, calibration_files))
if (any(!file.exists(input_files))) stop("Missing inputs: ",
  paste(input_files[!file.exists(input_files)], collapse = ", "))
# Includes loaded config/helper/calibration bytes and the local analysis functions.
run_environment <- environment()
function_names <- ls(envir = run_environment)
function_names <- function_names[vapply(function_names, function(nm)
  is.function(get(nm, envir = run_environment, inherits = FALSE)), logical(1))]
function_code <- lapply(function_names, function(nm)
  paste(deparse(get(nm, envir = run_environment, inherits = FALSE)), collapse = "\n"))
names(function_code) <- function_names
signature <- list(version = 1L, hashes = unname(tools::md5sum(input_files)),
                  settings = settings, functions = function_code)
manifest <- file.path(checkpoint_dir, "settings.rds")
if (file.exists(manifest)) {
  if (!identical(readRDS(manifest), signature))
    stop("Inputs, model or settings changed. Use a new RUN_NAME; existing results are preserved.")
} else {
  saveRDS(signature, manifest)
}
capture.output(sessionInfo(), file = file.path(checkpoint_dir, "session_info_latest.txt"))
rows <- list()
started <- Sys.time()
cat("\n", RUN_NAME, " | ", N_REP, " replications | effect-only extension\n", sep = "")
print(settings)
for (rep_id in seq_len(N_REP)) {
  seed <- settings$seed_base + rep_id
  checkpoint <- file.path(checkpoint_dir, sprintf("rep_%05d.rds", rep_id))
  if (file.exists(checkpoint)) {
    row <- readRDS(checkpoint)
    if (!is.data.frame(row) || nrow(row) != 1L ||
        !identical(as.integer(row$replication), as.integer(rep_id)) ||
        !identical(as.integer(row$seed), as.integer(seed)))
      stop("Invalid checkpoint: ", checkpoint)
  } else {
    # Generation errors stop the run; completed earlier fits remain available.
    row <- run_one(rep_id, seed)
    stopifnot(is.data.frame(row), nrow(row) == 1L)
    temporary <- paste0(checkpoint, ".tmp")
    saveRDS(row, temporary)
    if (!file.rename(temporary, checkpoint)) stop("Cannot save: ", checkpoint)
    cat(rep_id, "/", N_REP, " | fit=", round(row$elapsed_seconds, 1),
        "s | elapsed=", round(as.numeric(difftime(Sys.time(), started, units="mins")), 1),
        "min\n", sep = "")
  }
  rows[[rep_id]] <- row
  # CSV exports are disposable views of the authoritative per-replication RDS files.
  results <- do.call(rbind, rows)
  write.csv(results, raw_file, row.names = FALSE)
  write.csv(summarize_results(results), summary_file, row.names = FALSE)
}
# Include all saved replications even if N_REP was subsequently reduced.
saved <- list.files(checkpoint_dir, pattern = "^rep_[0-9]+[.]rds$", full.names = TRUE)
results <- do.call(rbind, lapply(saved, readRDS))
results <- results[order(results$replication), , drop = FALSE]
summary_out <- summarize_results(results)
write.csv(results, raw_file, row.names = FALSE)
write.csv(summary_out, summary_file, row.names = FALSE)
write.csv(results[audit_rows(results), , drop = FALSE], audit_file, row.names = FALSE)
cat("\nSUMMARY\n")
print(summary_out, row.names = FALSE)
cat("\n", SUMMARY_NOTE, "\nNo null rejection rate is estimated by this extension.\n", sep = "")
cat("Raw results: ", raw_file, "\nSummary: ", summary_file,
    "\nFit audit: ", audit_file, "\nRerun this script to resume.\n", sep = "")

})()
