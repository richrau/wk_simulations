# scripts/14_run_metacognition_final.R
# Final five-cell Monte Carlo for Simulation 3.
# Reuses matching pilot rows, saves after every replication, safely resumes.

source(here::here("config.R"))
source(here::here("config_metacognition.R"))
source(here::here("helpers", "generate_design.R"))
source(here::here("helpers", "simulate_correctness.R"))
source(here::here("helpers", "simulate_metacognition.R"))

if (!requireNamespace("glmmTMB", quietly = TRUE)) stop("Package 'glmmTMB' is required.")

NREP <- 200L
N <- 1000L
R <- 20L
t0 <- Sys.time()

availability_matrix <- readRDS(META_AVAILABILITY_FILE)
item_properties <- readRDS(META_ITEM_PROPERTIES_FILE)

out <- here::here("output", "tables")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

pilot_pre <- file.path(out, "metacognition_aggregated_pre_pilot_raw.csv")
pilot_fb  <- file.path(out, "metacognition_aggregated_feedback_pilot_raw.csv")
final_pre <- file.path(out, "metacognition_final_pre_raw.csv")
final_fb  <- file.path(out, "metacognition_final_feedback_raw.csv")
final_sum <- file.path(out, "metacognition_final_summary.csv")

elapsed_min <- function() as.numeric(difftime(Sys.time(), t0, units = "mins"))

read0 <- function(path) {
  if (!file.exists(path)) return(NULL)
  x <- read.csv(path, stringsAsFactors = FALSE)
  if (!nrow(x)) NULL else x
}

wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) return(c(est = NA, se = NA, p = NA))
  c(est = tab[hit, "Estimate"], se = tab[hit, "Std. Error"], p = tab[hit, "Pr(>|z|)"])
}

safe <- function(expr) {
  ww <- character()
  err <- NA_character_
  val <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        ww <<- c(ww, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      err <<- conditionMessage(e)
      NULL
    }
  )
  list(value = val, warnings = unique(ww), error = err)
}

aggregate_meta <- function(dat) {
  dat$one <- 1L
  a <- aggregate(
    cbind(n_correct = is_correct, n_total = one) ~
      user_id + phase + post + feedback_condition + negativity_z_person + confidence,
    data = dat, FUN = sum
  )
  a$weighted_conf <- a$confidence * a$n_total
  pm <- aggregate(
    cbind(weighted_conf = weighted_conf, phase_n = n_total) ~ user_id + phase,
    data = a, FUN = sum
  )
  pm$confidence_pm_phase <- pm$weighted_conf / pm$phase_n
  a <- merge(
    a, pm[, c("user_id", "phase", "confidence_pm_phase")],
    by = c("user_id", "phase"), all.x = TRUE, sort = FALSE
  )
  a$confidence_wc_phase <- a$confidence - a$confidence_pm_phase
  a$n_incorrect <- a$n_total - a$n_correct
  a$user_id <- factor(a$user_id)
  a
}

fit_pre <- function(dat) {
  a <- aggregate_meta(dat[dat$post == 0L, ])
  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase + negativity_z_person +
      confidence_wc_phase * negativity_z_person +
      (1 | user_id) + (0 + confidence_wc_phase | user_id),
    data = a, family = binomial()
  )
  z <- wald(
    fit,
    "^(confidence_wc_phase:negativity_z_person|negativity_z_person:confidence_wc_phase)$"
  )
  list(
    est = unname(z["est"]), se = unname(z["se"]), p = unname(z["p"]),
    convergence = fit$fit$convergence, pdHess = fit$sdr$pdHess, n_agg = nrow(a)
  )
}

fit_fb <- function(dat) {
  a <- aggregate_meta(dat)
  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase + confidence_wc_phase * post * feedback_condition +
      (1 | user_id) + (0 + confidence_wc_phase | user_id),
    data = a, family = binomial()
  )
  z <- wald(
    fit,
    "^confidence_wc_phase:post:feedback_conditionfeedback$|^confidence_wc_phase:feedback_conditionfeedback:post$|^post:confidence_wc_phase:feedback_conditionfeedback$|^post:feedback_conditionfeedback:confidence_wc_phase$|^feedback_conditionfeedback:confidence_wc_phase:post$|^feedback_conditionfeedback:post:confidence_wc_phase$"
  )
  list(
    est = unname(z["est"]), se = unname(z["se"]), p = unname(z["p"]),
    convergence = fit$fit$convergence, pdHess = fit$sdr$pdHess, n_agg = nrow(a)
  )
}

dedupe_pre <- function(x) {
  if (is.null(x)) return(NULL)
  key <- x[, c("n_users", "n_pre_rounds", "rho_generating", "replication")]
  x[!duplicated(key), ]
}

dedupe_fb <- function(x) {
  if (is.null(x)) return(NULL)
  key <- x[, c("n_users", "n_rounds_per_phase", "feedback_delta_generating", "replication")]
  x[!duplicated(key), ]
}

# Initialize final files from existing pilot results, unless final files already exist.
pre <- read0(final_pre)
if (is.null(pre)) {
  p <- read0(pilot_pre)
  if (!is.null(p)) {
    pre <- p[
      p$n_users == N & p$n_pre_rounds == R &
      p$rho_generating %in% c(0, .20) & p$replication <= NREP,
    ]
    pre <- dedupe_pre(pre)
    if (nrow(pre)) write.csv(pre, final_pre, row.names = FALSE)
  }
}

fb <- read0(final_fb)
if (is.null(fb)) {
  p <- read0(pilot_fb)
  if (!is.null(p)) {
    fb <- p[
      p$n_users == N & p$n_rounds_per_phase == R &
      p$feedback_delta_generating %in% c(0, .05, .10) & p$replication <= NREP,
    ]
    fb <- dedupe_fb(fb)
    if (nrow(fb)) write.csv(fb, final_fb, row.names = FALSE)
  }
}

cat("\nFINAL SIMULATION 3A: PRE-FEEDBACK\n")

for (rho in c(0, .20)) {
  have <- if (is.null(pre)) integer() else pre$replication[
    pre$n_users == N & pre$n_pre_rounds == R & abs(pre$rho_generating - rho) < 1e-12
  ]
  todo <- setdiff(seq_len(NREP), have)
  cat("\nrho=", rho, ": ", length(have), " existing, ", length(todo), " remaining\n", sep = "")

  for (rep in todo) {
    off <- if (rho == 0) 0L else 10000L
    set.seed(SEED_METACOGNITION + 900000L + off + rep)

    dat <- simulate_metacognition_dataset(
      n_users = N, n_pre_rounds = R, n_post_rounds = 0L,
      availability_matrix = availability_matrix, item_properties = item_properties,
      rho_negativity_sensitivity = rho, feedback_delta = 0,
      randomized_feedback = FALSE, keep_components = FALSE
    )

    tm <- system.time(s <- safe(fit_pre(dat)))
    z <- if (is.null(s$value)) {
      list(est = NA, se = NA, p = NA, convergence = NA, pdHess = NA, n_agg = NA)
    } else s$value

    row <- data.frame(
      n_users = N, n_pre_rounds = R, rho_generating = rho,
      beta_generating = rho * META_SD_SENSITIVITY, replication = rep,
      beta_estimated = z$est, se_estimated = z$se, wald_p = z$p,
      convergence = z$convergence, pdHess = z$pdHess,
      n_aggregated_rows = z$n_agg, elapsed_seconds = tm["elapsed"],
      warnings = paste(s$warnings, collapse = " | "), error = s$error
    )

    pre <- dedupe_pre(if (is.null(pre)) row else rbind(pre, row))
    write.csv(pre, final_pre, row.names = FALSE)

    cat("PRE rho=", rho, " rep=", rep, "/", NREP,
        " | fit=", round(tm["elapsed"], 1), "s",
        " | total=", round(elapsed_min(), 1), "min\n", sep = "")
  }
}

cat("\nFINAL SIMULATION 3B: FEEDBACK\n")

for (delta in c(0, .05, .10)) {
  have <- if (is.null(fb)) integer() else fb$replication[
    fb$n_users == N & fb$n_rounds_per_phase == R &
      abs(fb$feedback_delta_generating - delta) < 1e-12
  ]
  todo <- setdiff(seq_len(NREP), have)
  cat("\ndelta=", delta, ": ", length(have), " existing, ", length(todo), " remaining\n", sep = "")

  for (rep in todo) {
    off <- if (delta == 0) 0L else if (delta == .05) 10000L else 20000L
    set.seed(SEED_METACOGNITION + 1000000L + off + rep)

    dat <- simulate_metacognition_dataset(
      n_users = N, n_pre_rounds = R, n_post_rounds = R,
      availability_matrix = availability_matrix, item_properties = item_properties,
      rho_negativity_sensitivity = 0, feedback_delta = delta,
      randomized_feedback = TRUE, keep_components = FALSE
    )

    tm <- system.time(s <- safe(fit_fb(dat)))
    z <- if (is.null(s$value)) {
      list(est = NA, se = NA, p = NA, convergence = NA, pdHess = NA, n_agg = NA)
    } else s$value

    row <- data.frame(
      n_users = N, n_rounds_per_phase = R,
      feedback_delta_generating = delta, replication = rep,
      delta_estimated = z$est, se_estimated = z$se, wald_p = z$p,
      convergence = z$convergence, pdHess = z$pdHess,
      n_aggregated_rows = z$n_agg, elapsed_seconds = tm["elapsed"],
      warnings = paste(s$warnings, collapse = " | "), error = s$error
    )

    fb <- dedupe_fb(if (is.null(fb)) row else rbind(fb, row))
    write.csv(fb, final_fb, row.names = FALSE)

    cat("FB delta=", delta, " rep=", rep, "/", NREP,
        " | fit=", round(tm["elapsed"], 1), "s",
        " | total=", round(elapsed_min(), 1), "min\n", sep = "")
  }
}

summarize_cell <- function(dat, estvar, truevar, label) {
  ok <- is.finite(dat[[estvar]]) & is.finite(dat$wald_p)
  rr <- mean(dat$wald_p[ok] < .05)
  nn <- sum(ok)
  data.frame(
    analysis = label,
    n_rep = nrow(dat),
    n_usable = nn,
    generating_effect = dat[[truevar]][1],
    mean_estimate = mean(dat[[estvar]][ok]),
    bias = mean(dat[[estvar]][ok] - dat[[truevar]][ok]),
    mean_se = mean(dat$se_estimated[ok]),
    rejection_rate_05 = rr,
    mcse_rejection = sqrt(rr * (1 - rr) / nn),
    nonzero_convergence_rate = mean(dat$convergence != 0, na.rm = TRUE),
    non_pd_hessian_rate = mean(!as.logical(dat$pdHess), na.rm = TRUE),
    mean_fit_seconds = mean(dat$elapsed_seconds, na.rm = TRUE)
  )
}

P0 <- pre[abs(pre$rho_generating - 0) < 1e-12, ]
P2 <- pre[abs(pre$rho_generating - .20) < 1e-12, ]
F0 <- fb[abs(fb$feedback_delta_generating - 0) < 1e-12, ]
F5 <- fb[abs(fb$feedback_delta_generating - .05) < 1e-12, ]
F1 <- fb[abs(fb$feedback_delta_generating - .10) < 1e-12, ]

summary_final <- rbind(
  summarize_cell(P0, "beta_estimated", "beta_generating", "Pre-feedback: rho = 0"),
  summarize_cell(P2, "beta_estimated", "beta_generating", "Pre-feedback: rho = .20"),
  summarize_cell(F0, "delta_estimated", "feedback_delta_generating", "Feedback: delta = 0"),
  summarize_cell(F5, "delta_estimated", "feedback_delta_generating", "Feedback: delta = .05"),
  summarize_cell(F1, "delta_estimated", "feedback_delta_generating", "Feedback: delta = .10")
)

write.csv(summary_final, final_sum, row.names = FALSE)

cat("\nFINAL SIMULATION 3 SUMMARY\n")
print(summary_final, row.names = FALSE)
cat("\nFinished after ", round(elapsed_min(), 1), " minutes.\n", sep = "")
cat("Raw results were saved after every replication; rerunning safely resumes incomplete cells.\n")
