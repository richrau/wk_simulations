# scripts/23_run_feedback_power_extension_n1500.R
# Simulation 3 feedback: N=1500, 20+20 rounds, delta=.10; 200 replications.
# Place in scripts/ and source from your existing simulation R project.
# Uses your current configs, helpers and calibration files without modifying them.
# Runs sequentially, saves each attempt, and resumes when sourced again.
(function() {
for (pkg in c("here", "glmmTMB")) {
  if (!requireNamespace(pkg, quietly = TRUE)) stop("Package required: ", pkg)
}
source_files <- c(here::here("config.R"), here::here("config_metacognition.R"),
  here::here("helpers", "generate_design.R"), here::here("helpers", "simulate_correctness.R"), here::here("helpers", "simulate_metacognition.R"))
if (any(!file.exists(source_files))) stop("Missing source file: ",
  paste(source_files[!file.exists(source_files)], collapse = ", "))
for (file in source_files) source(file, local = environment())
N_REP <- 200L
RUN_NAME <- "feedback_power_extension_n1500"
settings <- list(n_users = 1500L, rounds_per_phase = 20L, delta = .10,
                 rho = 0, seed_base = SEED_METACOGNITION + 4000000L)
stopifnot(META_JUDGMENTS_PER_ROUND == 5L)
calibration_files <- c(CORRECTNESS_CALIBRATION_FILE, META_AVAILABILITY_FILE, META_ITEM_PROPERTIES_FILE)
availability_matrix <- readRDS(META_AVAILABILITY_FILE)
item_properties <- readRDS(META_ITEM_PROPERTIES_FILE)
wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) {
    return(c(est = NA_real_, se = NA_real_, p = NA_real_))
  }
  c(
    est = unname(tab[hit, "Estimate"]),
    se  = unname(tab[hit, "Std. Error"]),
    p   = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe <- function(expr) {
  ww <- character()
  err <- NA_character_
  val <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        ww <<- c(ww, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      err <<- conditionMessage(e)
      NULL
    }
  )
  list(value = val, warnings = unique(ww), error = err)
}

aggregate_meta <- function(dat) {
  dat$one <- 1L

  a <- aggregate(
    cbind(n_correct = is_correct, n_total = one) ~
      user_id + phase + post + feedback_condition +
      negativity_z_person + confidence,
    data = dat,
    FUN = sum
  )

  a$weighted_conf <- a$confidence * a$n_total

  pm <- aggregate(
    cbind(weighted_conf = weighted_conf, phase_n = n_total) ~
      user_id + phase,
    data = a,
    FUN = sum
  )

  pm$confidence_pm_phase <- pm$weighted_conf / pm$phase_n

  a <- merge(
    a,
    pm[, c("user_id", "phase", "confidence_pm_phase")],
    by = c("user_id", "phase"),
    all.x = TRUE,
    sort = FALSE
  )

  a$confidence_wc_phase <- a$confidence - a$confidence_pm_phase
  a$n_incorrect <- a$n_total - a$n_correct
  a$user_id <- factor(a$user_id)

  a
}

fit_fb <- function(dat) {
  a <- aggregate_meta(dat)

  fit <- glmmTMB::glmmTMB(
    cbind(n_correct, n_incorrect) ~
      confidence_pm_phase +
      confidence_wc_phase * post * feedback_condition +
      (1 | user_id) +
      (0 + confidence_wc_phase | user_id),
    data = a,
    family = binomial()
  )

  z <- wald(
    fit,
    "^confidence_wc_phase:post:feedback_conditionfeedback$|^confidence_wc_phase:feedback_conditionfeedback:post$|^post:confidence_wc_phase:feedback_conditionfeedback$|^post:feedback_conditionfeedback:confidence_wc_phase$|^feedback_conditionfeedback:confidence_wc_phase:post$|^feedback_conditionfeedback:post:confidence_wc_phase$"
  )

  list(
    est = z["est"],
    se = z["se"],
    p = z["p"],
    convergence = fit$fit$convergence,
    pdHess = fit$sdr$pdHess,
    n_agg = nrow(a)
  )
}


average <- function(x) if (length(x)) mean(x) else NA_real_
mcse <- function(p, n) if (n > 0L) sqrt(p * (1 - p) / n) else NA_real_
valid_test <- function(est, se, p) {
  is.finite(est) & is.finite(se) & se > 0 & is.finite(p) & p >= 0 & p <= 1
}

run_one <- function(rep_id, seed) {
  set.seed(seed)
  dat <- simulate_metacognition_dataset(
    n_users = settings$n_users, n_pre_rounds = settings$rounds_per_phase,
    n_post_rounds = settings$rounds_per_phase, availability_matrix = availability_matrix,
    item_properties = item_properties, rho_negativity_sensitivity = settings$rho,
    feedback_delta = settings$delta, randomized_feedback = TRUE, keep_components = FALSE)
  tm <- system.time(s <- safe(fit_fb(dat)))
  z <- if (is.null(s$value)) list(est=NA_real_, se=NA_real_, p=NA_real_,
    convergence=NA_integer_, pdHess=NA, n_agg=NA_integer_) else s$value
  data.frame(n_users = settings$n_users, n_rounds_per_phase = settings$rounds_per_phase,
    feedback_delta_generating = settings$delta, rho_generating = settings$rho,
    replication = rep_id, seed = seed, delta_estimated = unname(z$est),
    se_estimated = unname(z$se), wald_p = unname(z$p),
    convergence = z$convergence, pdHess = z$pdHess, n_aggregated_rows = z$n_agg,
    elapsed_seconds = unname(tm["elapsed"]),
    warnings = paste(s$warnings, collapse = " | "), error = s$error,
    stringsAsFactors = FALSE)
}
clean_tests <- function(x) {
  valid_test(x$delta_estimated, x$se_estimated, x$wald_p) &
    !is.na(x$convergence) & x$convergence == 0 & !is.na(x$pdHess) & x$pdHess
}
audit_rows <- function(x) !clean_tests(x) | nzchar(x$warnings)
summarize_results <- function(x) {
  ok <- is.finite(x$delta_estimated) & is.finite(x$wald_p) # Script 15 rule.
  clean <- clean_tests(x)
  rate <- average(x$wald_p[ok] < .05)
  rate_clean <- average(x$wald_p[clean] < .05)
  data.frame(analysis = "Feedback delta=.10", n_users = settings$n_users,
    n_rounds_per_phase = settings$rounds_per_phase, feedback_delta_generating = settings$delta,
    n_rep_completed = nrow(x), n_test_usable_original = sum(ok),
    rejection_rate_original = rate, mcse_rejection_original = mcse(rate, sum(ok)),
    n_test_usable_clean = sum(clean), n_excluded_clean = sum(!clean),
    rejection_rate_clean = rate_clean, mcse_rejection_clean = mcse(rate_clean, sum(clean)),
    mean_estimate_clean = average(x$delta_estimated[clean]),
    mean_se_clean = average(x$se_estimated[clean]),
    n_nonzero_or_missing_convergence = sum(is.na(x$convergence) | x$convergence != 0),
    n_non_pd_or_missing_hessian = sum(is.na(x$pdHess) | !x$pdHess),
    mean_fit_seconds = mean(x$elapsed_seconds))
}
SUMMARY_NOTE <- "Original rate follows Script 15. Clean rate additionally requires convergence=0, positive-definite Hessian and valid SE. Generating delta is metadata, not a bias benchmark for the aggregated fit."

# Separate checkpoints; each completed attempt (including failed fits) is saved.
# Increasing N_REP adds replications. Changing scientific inputs stops resumption.
stopifnot(length(N_REP) == 1L, N_REP >= 1L, N_REP < 100000L)
output_dir <- here::here("output", "tables")
checkpoint_dir <- here::here("output", "checkpoints", RUN_NAME)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
raw_file <- file.path(output_dir, paste0(RUN_NAME, "_raw.csv"))
summary_file <- file.path(output_dir, paste0(RUN_NAME, "_summary.csv"))
audit_file <- file.path(output_dir, paste0(RUN_NAME, "_fit_audit.csv"))
input_files <- unique(c(source_files, calibration_files))
if (any(!file.exists(input_files))) stop("Missing inputs: ",
  paste(input_files[!file.exists(input_files)], collapse = ", "))
# Includes loaded config/helper/calibration bytes and the local analysis functions.
run_environment <- environment()
function_names <- ls(envir = run_environment)
function_names <- function_names[vapply(function_names, function(nm)
  is.function(get(nm, envir = run_environment, inherits = FALSE)), logical(1))]
function_code <- lapply(function_names, function(nm)
  paste(deparse(get(nm, envir = run_environment, inherits = FALSE)), collapse = "\n"))
names(function_code) <- function_names
signature <- list(version = 1L, hashes = unname(tools::md5sum(input_files)),
                  settings = settings, functions = function_code)
manifest <- file.path(checkpoint_dir, "settings.rds")
if (file.exists(manifest)) {
  if (!identical(readRDS(manifest), signature))
    stop("Inputs, model or settings changed. Use a new RUN_NAME; existing results are preserved.")
} else {
  saveRDS(signature, manifest)
}
capture.output(sessionInfo(), file = file.path(checkpoint_dir, "session_info_latest.txt"))
rows <- list()
started <- Sys.time()
cat("\n", RUN_NAME, " | ", N_REP, " replications | effect-only extension\n", sep = "")
print(settings)
for (rep_id in seq_len(N_REP)) {
  seed <- settings$seed_base + rep_id
  checkpoint <- file.path(checkpoint_dir, sprintf("rep_%05d.rds", rep_id))
  if (file.exists(checkpoint)) {
    row <- readRDS(checkpoint)
    if (!is.data.frame(row) || nrow(row) != 1L ||
        !identical(as.integer(row$replication), as.integer(rep_id)) ||
        !identical(as.integer(row$seed), as.integer(seed)))
      stop("Invalid checkpoint: ", checkpoint)
  } else {
    # Generation errors stop the run; completed earlier fits remain available.
    row <- run_one(rep_id, seed)
    stopifnot(is.data.frame(row), nrow(row) == 1L)
    temporary <- paste0(checkpoint, ".tmp")
    saveRDS(row, temporary)
    if (!file.rename(temporary, checkpoint)) stop("Cannot save: ", checkpoint)
    cat(rep_id, "/", N_REP, " | fit=", round(row$elapsed_seconds, 1),
        "s | elapsed=", round(as.numeric(difftime(Sys.time(), started, units="mins")), 1),
        "min\n", sep = "")
  }
  rows[[rep_id]] <- row
  # CSV exports are disposable views of the authoritative per-replication RDS files.
  results <- do.call(rbind, rows)
  write.csv(results, raw_file, row.names = FALSE)
  write.csv(summarize_results(results), summary_file, row.names = FALSE)
}
# Include all saved replications even if N_REP was subsequently reduced.
saved <- list.files(checkpoint_dir, pattern = "^rep_[0-9]+[.]rds$", full.names = TRUE)
results <- do.call(rbind, lapply(saved, readRDS))
results <- results[order(results$replication), , drop = FALSE]
summary_out <- summarize_results(results)
write.csv(results, raw_file, row.names = FALSE)
write.csv(summary_out, summary_file, row.names = FALSE)
write.csv(results[audit_rows(results), , drop = FALSE], audit_file, row.names = FALSE)
cat("\nSUMMARY\n")
print(summary_out, row.names = FALSE)
cat("\n", SUMMARY_NOTE, "\nNo null rejection rate is estimated by this extension.\n", sep = "")
cat("Raw results: ", raw_file, "\nSummary: ", summary_file,
    "\nFit audit: ", audit_file, "\nRerun this script to resume.\n", sep = "")

})()
