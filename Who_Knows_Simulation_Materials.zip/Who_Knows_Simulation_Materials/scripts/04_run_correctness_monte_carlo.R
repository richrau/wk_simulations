# ==============================================================================
# scripts/05_run_correctness_monte_carlo.R
# Parallel Monte Carlo design analysis for generalized negativity and correctness
# ==============================================================================

source(here::here("config.R"))
source(here::here("helpers", "generate_design.R"))
source(here::here("helpers", "simulate_correctness.R"))

if (!requireNamespace("glmmTMB", quietly = TRUE)) {
  stop(
    "Package 'glmmTMB' is required. ",
    "Install it with install.packages('glmmTMB')."
  )
}


# ------------------------------------------------------------------------------
# Run mode
# ------------------------------------------------------------------------------

# "pilot" = 1 replication per cell
# "dev"   = N_REP_DEV replications per cell
# "final" = N_REP_FINAL replications per cell
#
# The completed pilot fits are reused automatically from the checkpoint.
RUN_MODE <- "final"

N_REP_PILOT <- 1L

N_REP <- switch(
  RUN_MODE,
  pilot = N_REP_PILOT,
  dev = N_REP_DEV,
  final = N_REP_FINAL,
  stop("RUN_MODE must be 'pilot', 'dev', or 'final'.")
)


# ------------------------------------------------------------------------------
# Parallel settings
# ------------------------------------------------------------------------------

# Leave some capacity for Windows/RStudio and avoid excessive RAM pressure.
# Edit MAX_WORKERS if you deliberately want a different cap.
N_LOGICAL_CORES <- parallel::detectCores(logical = TRUE)

if (is.na(N_LOGICAL_CORES)) {
  N_LOGICAL_CORES <- 4L
}

MAX_WORKERS <- 10L

N_WORKERS <- max(
  1L,
  min(
    MAX_WORKERS,
    N_LOGICAL_CORES - 2L
  )
)

# Run a modest number of fits between checkpoints. parLapplyLB load-balances
# jobs within each batch, which matters because the design scenarios differ
# substantially in fitting time.
BATCH_SIZE <- max(
  N_WORKERS,
  2L * N_WORKERS
)


# ------------------------------------------------------------------------------
# Design scenarios
# ------------------------------------------------------------------------------

# Engagement_scale multiplies the latent lognormal round-count distribution
# while preserving its shape.
#
# baseline:          median ~8, mean ~18 rounds
# lower_engagement:  approximately 2/3 as many rounds
# higher_engagement: approximately 1.5 times as many rounds

design_scenarios <- data.frame(
  scenario = c(
    "lower_n",
    "baseline",
    "higher_n",
    "lower_engagement",
    "higher_engagement"
  ),
  n_users = c(
    500L,
    1000L,
    1500L,
    1000L,
    1000L
  ),
  engagement_scale = c(
    1,
    1,
    1,
    2 / 3,
    1.5
  ),
  stringsAsFactors = FALSE
)

rho_scenarios <- RHO_NEGATIVITY_ACCURACY_SCENARIOS

if (!identical(sort(as.numeric(rho_scenarios)), c(0, 0.15, 0.30))) {
  warning(
    "RHO_NEGATIVITY_ACCURACY_SCENARIOS is not exactly c(0, .15, .30). ",
    "The script will use the values currently defined in config.R."
  )
}


# ------------------------------------------------------------------------------
# Output and checkpoint files
# ------------------------------------------------------------------------------

dir.create(
  here::here("data", "cache"),
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  here::here("output", "tables"),
  recursive = TRUE,
  showWarnings = FALSE
)

checkpoint_file <- here::here(
  "data",
  "cache",
  "correctness_monte_carlo_checkpoint.rds"
)

raw_output_file <- here::here(
  "output",
  "tables",
  "correctness_monte_carlo_raw.csv"
)

summary_output_file <- here::here(
  "output",
  "tables",
  "correctness_monte_carlo_summary.csv"
)

# ------------------------------------------------------------------------------
# Fixed calibration objects
# ------------------------------------------------------------------------------

availability_matrix <- readRDS(
  here::here("data", "calibration", "availability_matrix.rds")
)

item_properties <- readRDS(
  here::here("data", "calibration", "item_properties.rds")
)


# ------------------------------------------------------------------------------
# Preserve baseline engagement parameters
# ------------------------------------------------------------------------------

BASE_ENGAGEMENT_MEANLOG <- ENGAGEMENT_MEANLOG
BASE_ENGAGEMENT_SDLOG <- ENGAGEMENT_SDLOG


# ------------------------------------------------------------------------------
# One-replication fitting helper
# ------------------------------------------------------------------------------

run_one_replication <- function(
  scenario_name,
  n_users,
  engagement_scale,
  rho,
  replication,
  seed
) {

  # --------------------------------------------------------------------------
  # Set scenario-specific engagement
  # --------------------------------------------------------------------------

  assign(
    "ENGAGEMENT_MEANLOG",
    BASE_ENGAGEMENT_MEANLOG + log(engagement_scale),
    envir = .GlobalEnv
  )

  assign(
    "ENGAGEMENT_SDLOG",
    BASE_ENGAGEMENT_SDLOG,
    envir = .GlobalEnv
  )

  set.seed(seed)

  # --------------------------------------------------------------------------
  # Generate sparse trial structure and outcome
  # --------------------------------------------------------------------------

  design <- generate_design(
    n_users = n_users,
    availability_matrix = availability_matrix
  )

  round_counts <- attr(design, "round_counts")

  dat <- simulate_correctness(
    design = design,
    item_properties = item_properties,
    include_exposure_effects = TRUE,
    rho_negativity_accuracy = rho,
    keep_components = FALSE
  )

  rm(design)

  # --------------------------------------------------------------------------
  # Grouping factors
  # --------------------------------------------------------------------------

  dat$user_id <- factor(dat$user_id)
  dat$item_id <- factor(dat$item_id)
  dat$target_id <- factor(dat$target_id)

  dat$item_target_id <- interaction(
    dat$item_id,
    dat$target_id,
    drop = TRUE
  )

  # --------------------------------------------------------------------------
  # Analysis model
  # --------------------------------------------------------------------------

  formula_focal <- (
    is_correct ~
      negativity_z +
      item_type +
      log1p(played_games) +
      log1p(target_repetition) +
      log1p(item_repetition) +
      (1 | user_id) +
      (1 | item_id) +
      (1 | target_id) +
      (1 | item_target_id)
  )

  warning_messages <- character(0)
  error_message <- NA_character_

  elapsed <- system.time({

    fit <- tryCatch(
      withCallingHandlers(
        glmmTMB::glmmTMB(
          formula = formula_focal,
          data = dat,
          family = binomial(link = "logit"),
          control = glmmTMB::glmmTMBControl(
            parallel = 1L,
            optCtrl = list(
              iter.max = 1000,
              eval.max = 1000
            )
          )
        ),
        warning = function(w) {
          warning_messages <<- c(
            warning_messages,
            conditionMessage(w)
          )
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) {
        error_message <<- conditionMessage(e)
        NULL
      }
    )

  })["elapsed"]

  true_beta <- rho * SD_USER

  # --------------------------------------------------------------------------
  # Failed fit
  # --------------------------------------------------------------------------

  if (is.null(fit)) {

    return(
      data.frame(
        scenario = scenario_name,
        n_users = n_users,
        engagement_scale = engagement_scale,
        rho = rho,
        replication = replication,
        seed = seed,
        n_judgments = nrow(dat),
        mean_rounds = mean(round_counts),
        median_rounds = median(round_counts),
        hit_rate = mean(dat$is_correct),
        true_beta = true_beta,
        estimate = NA_real_,
        std_error = NA_real_,
        ci_lower = NA_real_,
        ci_upper = NA_real_,
        ci_width = NA_real_,
        p_value = NA_real_,
        significant = NA,
        bias = NA_real_,
        squared_error = NA_real_,
        covers_true = NA,
        fit_success = FALSE,
        convergence_code = NA_integer_,
        pd_hessian = NA,
        usable_fit = FALSE,
        elapsed_seconds = as.numeric(elapsed),
        n_warnings = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        error = error_message,
        stringsAsFactors = FALSE
      )
    )
  }

  # --------------------------------------------------------------------------
  # Successful fit
  # --------------------------------------------------------------------------

  coef_table <- summary(fit)$coefficients$cond

  estimate <- coef_table["negativity_z", "Estimate"]
  std_error <- coef_table["negativity_z", "Std. Error"]
  p_value <- coef_table["negativity_z", "Pr(>|z|)"]

  ci_lower <- estimate - 1.96 * std_error
  ci_upper <- estimate + 1.96 * std_error

  convergence_code <- fit$fit$convergence

  pd_hessian <- if (!is.null(fit$sdr)) {
    isTRUE(fit$sdr$pdHess)
  } else {
    NA
  }

  usable_fit <- (
    isTRUE(convergence_code == 0L) &&
      isTRUE(pd_hessian) &&
      is.finite(estimate) &&
      is.finite(std_error) &&
      std_error > 0
  )

  data.frame(
    scenario = scenario_name,
    n_users = n_users,
    engagement_scale = engagement_scale,
    rho = rho,
    replication = replication,
    seed = seed,
    n_judgments = nrow(dat),
    mean_rounds = mean(round_counts),
    median_rounds = median(round_counts),
    hit_rate = mean(dat$is_correct),
    true_beta = true_beta,
    estimate = estimate,
    std_error = std_error,
    ci_lower = ci_lower,
    ci_upper = ci_upper,
    ci_width = ci_upper - ci_lower,
    p_value = p_value,
    significant = p_value < 0.05,
    bias = estimate - true_beta,
    squared_error = (estimate - true_beta)^2,
    covers_true = (
      ci_lower <= true_beta &&
        ci_upper >= true_beta
    ),
    fit_success = TRUE,
    convergence_code = convergence_code,
    pd_hessian = pd_hessian,
    usable_fit = usable_fit,
    elapsed_seconds = as.numeric(elapsed),
    n_warnings = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    error = NA_character_,
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# Worker wrapper
# ------------------------------------------------------------------------------

run_task <- function(task) {

  result <- run_one_replication(
    scenario_name = task$scenario,
    n_users = as.integer(task$n_users),
    engagement_scale = as.numeric(task$engagement_scale),
    rho = as.numeric(task$rho),
    replication = as.integer(task$replication),
    seed = as.integer(task$seed)
  )

  result$key <- task$key

  result
}


# ------------------------------------------------------------------------------
# Construct deterministic task grid
# ------------------------------------------------------------------------------

task_grid <- expand.grid(
  scenario_index = seq_len(nrow(design_scenarios)),
  rho_index = seq_along(rho_scenarios),
  replication = seq_len(N_REP),
  KEEP.OUT.ATTRS = FALSE,
  stringsAsFactors = FALSE
)

task_grid$scenario <- design_scenarios$scenario[
  task_grid$scenario_index
]

task_grid$n_users <- design_scenarios$n_users[
  task_grid$scenario_index
]

task_grid$engagement_scale <- design_scenarios$engagement_scale[
  task_grid$scenario_index
]

task_grid$rho <- rho_scenarios[
  task_grid$rho_index
]

# Stable seed that does not depend on RUN_MODE or the number of replications.
task_grid$seed <- (
  SEED_SIMULATION +
    task_grid$scenario_index * 100000L +
    task_grid$rho_index * 10000L +
    task_grid$replication
)

task_grid$key <- paste(
  task_grid$scenario,
  sprintf("%.5f", task_grid$rho),
  task_grid$replication,
  sep = "__"
)


# ------------------------------------------------------------------------------
# Load checkpoint and identify unfinished tasks
# ------------------------------------------------------------------------------

if (file.exists(checkpoint_file)) {

  results <- readRDS(checkpoint_file)

  if (!is.data.frame(results)) {
    stop("Existing Monte Carlo checkpoint is not a data frame.")
  }

  results$key <- paste(
    results$scenario,
    sprintf("%.5f", results$rho),
    results$replication,
    sep = "__"
  )

} else {

  results <- NULL
}

completed_keys <- if (is.null(results)) {
  character(0)
} else {
  unique(results$key)
}

tasks_remaining <- task_grid[
  !task_grid$key %in% completed_keys,
  ,
  drop = FALSE
]


# ------------------------------------------------------------------------------
# Console header
# ------------------------------------------------------------------------------

cat("\n")
cat("Correctness Monte Carlo\n")
cat("=======================\n")
cat("Run mode:              ", RUN_MODE, "\n")
cat("Replications per cell: ", N_REP, "\n")
cat("Design scenarios:      ", nrow(design_scenarios), "\n")
cat("Effect scenarios:      ", length(rho_scenarios), "\n")
cat("Total requested fits:  ", nrow(task_grid), "\n")
cat("Already completed:     ", length(completed_keys), "\n")
cat("Remaining fits:        ", nrow(tasks_remaining), "\n")
cat("Logical cores:         ", N_LOGICAL_CORES, "\n")
cat("Parallel workers:      ", N_WORKERS, "\n")
cat("Fits per checkpoint:   ", BATCH_SIZE, "\n")
cat("\n")


# ------------------------------------------------------------------------------
# Run unfinished replications in parallel batches
# ------------------------------------------------------------------------------

if (nrow(tasks_remaining) > 0L) {

  project_root <- here::here()

  cl <- parallel::makeCluster(
    N_WORKERS,
    type = "PSOCK"
  )

  # Give each worker the project root, source the same configuration/helper
  # files, and load the fixed calibration objects once.
  tryCatch({

    parallel::clusterExport(
      cl,
      varlist = "project_root",
      envir = environment()
    )

    parallel::clusterEvalQ(
      cl,
      {
        source(file.path(project_root, "config.R"))
        source(file.path(project_root, "helpers", "generate_design.R"))
        source(file.path(project_root, "helpers", "simulate_correctness.R"))

        availability_matrix <- readRDS(
          file.path(
            project_root,
            "data",
            "calibration",
            "availability_matrix.rds"
          )
        )

        item_properties <- readRDS(
          file.path(
            project_root,
            "data",
            "calibration",
            "item_properties.rds"
          )
        )

        BASE_ENGAGEMENT_MEANLOG <- ENGAGEMENT_MEANLOG
        BASE_ENGAGEMENT_SDLOG <- ENGAGEMENT_SDLOG

        NULL
      }
    )

    parallel::clusterExport(
      cl,
      varlist = c(
        "run_one_replication",
        "run_task"
      ),
      envir = environment()
    )

    n_batches <- ceiling(
      nrow(tasks_remaining) /
        BATCH_SIZE
    )

    run_start <- Sys.time()
    fits_completed_this_run <- 0L

    for (batch_index in seq_len(n_batches)) {

    first_row <- (
      (batch_index - 1L) *
        BATCH_SIZE +
        1L
    )

    last_row <- min(
      batch_index * BATCH_SIZE,
      nrow(tasks_remaining)
    )

    batch <- tasks_remaining[
      first_row:last_row,
      ,
      drop = FALSE
    ]

    batch_tasks <- lapply(
      seq_len(nrow(batch)),
      function(i) {
        as.list(
          batch[
            i,
            c(
              "scenario",
              "n_users",
              "engagement_scale",
              "rho",
              "replication",
              "seed",
              "key"
            )
          ]
        )
      }
    )

    cat(
      "[batch ",
      batch_index,
      "/",
      n_batches,
      "] running ",
      nrow(batch),
      " fits ...\n",
      sep = ""
    )

    batch_start <- Sys.time()

    batch_results_list <- parallel::parLapplyLB(
      cl,
      batch_tasks,
      run_task
    )

    batch_results <- do.call(
      rbind,
      batch_results_list
    )

    if (is.null(results)) {
      results <- batch_results
    } else {
      results <- rbind(
        results,
        batch_results
      )
    }

    # Checkpoint immediately after each parallel batch.
    saveRDS(
      results,
      checkpoint_file
    )

    fits_completed_this_run <- (
      fits_completed_this_run +
        nrow(batch)
    )

    batch_wall_seconds <- as.numeric(
      difftime(
        Sys.time(),
        batch_start,
        units = "secs"
      )
    )

    elapsed_run_seconds <- as.numeric(
      difftime(
        Sys.time(),
        run_start,
        units = "secs"
      )
    )

    remaining_this_run <- (
      nrow(tasks_remaining) -
        fits_completed_this_run
    )

    usable_batch <- sum(
      batch_results$usable_fit %in% TRUE
    )

    cat(
      "  completed ",
      nrow(batch),
      " fits; usable ",
      usable_batch,
      "/",
      nrow(batch),
      "; batch wall time ",
      round(batch_wall_seconds / 60, 1),
      " min\n",
      sep = ""
    )

    if (remaining_this_run > 0L) {

      wall_seconds_per_fit <- (
        elapsed_run_seconds /
          fits_completed_this_run
      )

      eta_hours <- (
        wall_seconds_per_fit *
          remaining_this_run /
          3600
      )

      cat(
        "  approximate remaining wall time: ",
        round(eta_hours, 1),
        " h\n",
        sep = ""
      )
    }

    rm(
      batch_results_list,
      batch_results
    )

      gc(verbose = FALSE)
    }

  }, finally = {
    parallel::stopCluster(cl)
  })
}


# ------------------------------------------------------------------------------
# Restore baseline engagement values
# ------------------------------------------------------------------------------

ENGAGEMENT_MEANLOG <- BASE_ENGAGEMENT_MEANLOG
ENGAGEMENT_SDLOG <- BASE_ENGAGEMENT_SDLOG


# ------------------------------------------------------------------------------
# Save raw results as CSV
# ------------------------------------------------------------------------------

results$key <- NULL

results <- results[
  order(
    match(results$scenario, design_scenarios$scenario),
    results$rho,
    results$replication
  ),
  ,
  drop = FALSE
]

write.csv(
  results,
  raw_output_file,
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# Summarize Monte Carlo performance by cell
# ------------------------------------------------------------------------------

cell_keys <- interaction(
  results$scenario,
  sprintf("%.5f", results$rho),
  drop = TRUE,
  lex.order = TRUE
)

split_results <- split(
  results,
  cell_keys
)

summarize_cell <- function(x) {

  usable <- x[
    x$usable_fit %in% TRUE,
    ,
    drop = FALSE
  ]

  n_attempted <- nrow(x)
  n_usable <- nrow(usable)

  if (n_usable == 0L) {

    return(
      data.frame(
        scenario = x$scenario[1],
        n_users = x$n_users[1],
        engagement_scale = x$engagement_scale[1],
        rho = x$rho[1],
        true_beta = x$true_beta[1],
        n_attempted = n_attempted,
        n_usable = 0L,
        usable_rate = 0,
        mean_judgments = mean(x$n_judgments),
        mean_rounds = mean(x$mean_rounds),
        mean_estimate = NA_real_,
        mean_se = NA_real_,
        bias = NA_real_,
        rmse = NA_real_,
        coverage = NA_real_,
        mean_ci_width = NA_real_,
        rejection_rate = NA_real_,
        mcse_rejection = NA_real_,
        estimand = ifelse(
          x$rho[1] == 0,
          "type_I_error",
          "power"
        ),
        mean_elapsed_seconds = mean(x$elapsed_seconds),
        stringsAsFactors = FALSE
      )
    )
  }

  rejection_rate <- mean(
    usable$significant
  )

  data.frame(
    scenario = x$scenario[1],
    n_users = x$n_users[1],
    engagement_scale = x$engagement_scale[1],
    rho = x$rho[1],
    true_beta = x$true_beta[1],
    n_attempted = n_attempted,
    n_usable = n_usable,
    usable_rate = n_usable / n_attempted,
    mean_judgments = mean(x$n_judgments),
    mean_rounds = mean(x$mean_rounds),
    mean_estimate = mean(usable$estimate),
    mean_se = mean(usable$std_error),
    bias = mean(usable$bias),
    rmse = sqrt(
      mean(usable$squared_error)
    ),
    coverage = mean(
      usable$covers_true
    ),
    mean_ci_width = mean(
      usable$ci_width
    ),
    rejection_rate = rejection_rate,
    mcse_rejection = sqrt(
      rejection_rate *
        (1 - rejection_rate) /
        n_usable
    ),
    estimand = ifelse(
      x$rho[1] == 0,
      "type_I_error",
      "power"
    ),
    mean_elapsed_seconds = mean(
      x$elapsed_seconds
    ),
    stringsAsFactors = FALSE
  )
}

summary_results <- do.call(
  rbind,
  lapply(
    split_results,
    summarize_cell
  )
)

rownames(summary_results) <- NULL

summary_results <- summary_results[
  order(
    match(
      summary_results$scenario,
      design_scenarios$scenario
    ),
    summary_results$rho
  ),
  ,
  drop = FALSE
]

write.csv(
  summary_results,
  summary_output_file,
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# Console summary
# ------------------------------------------------------------------------------

cat("\n")
cat("Monte Carlo run complete\n")
cat("========================\n")
cat("Raw results:\n  ", raw_output_file, "\n", sep = "")
cat("Summary:\n  ", summary_output_file, "\n", sep = "")
cat("Checkpoint:\n  ", checkpoint_file, "\n", sep = "")
cat("\n")

print(
  summary_results[
    ,
    c(
      "scenario",
      "n_users",
      "engagement_scale",
      "rho",
      "n_attempted",
      "n_usable",
      "usable_rate",
      "mean_se",
      "coverage",
      "rejection_rate",
      "estimand"
    )
  ],
  row.names = FALSE
)

cat("\n")

if (RUN_MODE == "pilot") {
  cat(
    "For the pilot run, rejection rates are not interpretable as power or ",
    "Type-I error estimates; the purpose is to verify the full workflow.\n",
    sep = ""
  )
}
