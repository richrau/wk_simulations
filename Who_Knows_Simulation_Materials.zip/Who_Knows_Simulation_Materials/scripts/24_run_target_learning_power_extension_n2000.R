# scripts/24_run_target_learning_power_extension_n2000.R
# Simulation 4: N=2000, 10 targets, 5 rounds, rho=.20; 200 replications.
# Place in scripts/ and source from your existing simulation R project.
# Uses your current configs, helpers and calibration files without modifying them.
# Runs sequentially, saves each attempt, and resumes when sourced again.
(function() {
for (pkg in c("here", "glmmTMB")) {
  if (!requireNamespace(pkg, quietly = TRUE)) stop("Package required: ", pkg)
}
source_files <- c(here::here("config.R"), here::here("config_target_learning.R"),
  here::here("helpers", "simulate_correctness.R"), here::here("helpers", "simulate_target_learning.R"))
if (any(!file.exists(source_files))) stop("Missing source file: ",
  paste(source_files[!file.exists(source_files)], collapse = ", "))
for (file in source_files) source(file, local = environment())
N_REP <- 200L
RUN_NAME <- "target_learning_power_extension_n2000"
EXT_RHO <- .20
EXT_ROUNDS <- 5L
settings <- list(n_users = 2000L, n_targets = 10L, rounds_per_target = EXT_ROUNDS,
                 rho = EXT_RHO, seed_base = SEED_TARGET_LEARNING + 5000000L)
stopifnot(TL_JUDGMENTS_PER_ROUND == 5L)
calibration_files <- c(CORRECTNESS_CALIBRATION_FILE, TL_AVAILABILITY_FILE, TL_ITEM_PROPERTIES_FILE)
availability_matrix <- readRDS(TL_AVAILABILITY_FILE)
item_properties <- readRDS(TL_ITEM_PROPERTIES_FILE)
extract_wald <- function(fit, pattern) {
  tab <- summary(fit)$coefficients$cond
  hit <- grep(pattern, rownames(tab), value = TRUE)
  if (length(hit) != 1L) {
    return(c(estimate = NA_real_, se = NA_real_, p = NA_real_))
  }
  c(
    estimate = unname(tab[hit, "Estimate"]),
    se = unname(tab[hit, "Std. Error"]),
    p = unname(tab[hit, "Pr(>|z|)"])
  )
}

safe_fit <- function(expr) {
  warnings <- character()
  error <- NA_character_
  value <- tryCatch(
    withCallingHandlers(
      expr,
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      error <<- conditionMessage(e)
      NULL
    }
  )
  list(value = value, warnings = unique(warnings), error = error)
}

fit_target_learning <- function(dat) {
  agg <- aggregate_target_learning(dat)

    fit <- glmmTMB::glmmTMB(
      cbind(n_correct, n_incorrect) ~
        target_progress * negativity_z_person +
        log1p(played_games) +
        (1 | user_id) +
        (0 + target_progress | user_id) +
        (1 | target_id) +
        (1 | user_target_id),
      data = agg,
      family = binomial()
    )

  focal <- extract_wald(
    fit,
    "^(target_progress:negativity_z_person|negativity_z_person:target_progress)$"
  )
  mean_learning <- extract_wald(fit, "^target_progress$")

  list(
    beta = focal["estimate"],
    beta_se = focal["se"],
    beta_p = focal["p"],
    mean_learning = mean_learning["estimate"],
    mean_learning_se = mean_learning["se"],
    mean_learning_p = mean_learning["p"],
    convergence = fit$fit$convergence,
    pdHess = fit$sdr$pdHess,
    n_aggregated_rows = nrow(agg)
  )
}


  valid_test <- function(est, se, p) {
    is.finite(est) & is.finite(se) & se > 0 & is.finite(p) & p >= 0 & p <= 1
  }
  average <- function(z) if (length(z)) mean(z) else NA_real_
  summarize_results <- function(results) {
    groups <- split(results, results$scenario)
    out <- do.call(rbind, lapply(groups, function(x) {
      fit_ok <- !is.na(x$convergence) & x$convergence == 0 &
        !is.na(x$pdHess) & x$pdHess
      usable <- fit_ok & valid_test(x$beta_estimated, x$beta_se, x$beta_p)
      learn <- fit_ok & valid_test(x$mean_learning_estimated,
                                  x$mean_learning_se, x$mean_learning_p)
      n <- sum(usable)
      rate <- average(x$beta_p[usable] < .05)
      data.frame(
        scenario = x$scenario[1], n_users = x$n_users[1],
        n_targets = x$n_targets[1], rounds_per_target = EXT_ROUNDS,
        judgments_per_user = x$judgments_per_user[1],
        total_judgments = x$n_users[1] * x$judgments_per_user[1],
        rho_generating = EXT_RHO, beta_generating = x$beta_generating[1],
        sd_user_learning = TL_SD_LEARNING, sd_user_target_learning = 0,
        n_rep_completed = nrow(x), n_test_usable_clean = n,
        n_excluded_clean = sum(!usable), excluded_fraction = mean(!usable),
        rejection_rate_clean = rate,
        mcse_rejection_clean = if (n > 0L) sqrt(rate * (1 - rate) / n) else NA_real_,
        mean_beta_estimated_clean = average(x$beta_estimated[usable]),
        mean_beta_se_clean = average(x$beta_se[usable]),
        n_mean_learning_usable = sum(learn),
        mean_learning_estimated_clean = average(x$mean_learning_estimated[learn]),
        mean_learning_rejection_rate_clean = average(x$mean_learning_p[learn] < .05),
        n_nonzero_or_missing_convergence = sum(is.na(x$convergence) | x$convergence != 0),
        n_non_pd_or_missing_hessian = sum(is.na(x$pdHess) | !x$pdHess),
        mean_fit_seconds = average(x$elapsed_seconds)
      )
    }))
    rownames(out) <- NULL
    out
  }


run_one <- function(rep_id, seed) {
  set.seed(seed)
  dat <- simulate_target_learning_dataset(n_users = settings$n_users,
    n_targets_per_user = settings$n_targets, rounds_per_target = EXT_ROUNDS,
    availability_matrix = availability_matrix, item_properties = item_properties,
    rho_negativity_learning = EXT_RHO, keep_components = FALSE)
  tm <- system.time(s <- safe_fit(fit_target_learning(dat)))
  z <- if (is.null(s$value)) list(beta=NA_real_, beta_se=NA_real_, beta_p=NA_real_,
    mean_learning=NA_real_, mean_learning_se=NA_real_, mean_learning_p=NA_real_,
    convergence=NA_integer_, pdHess=NA, n_aggregated_rows=NA_integer_) else s$value
  data.frame(scenario = RUN_NAME, n_users = settings$n_users, n_targets = settings$n_targets,
    rounds_per_target = EXT_ROUNDS,
    judgments_per_user = settings$n_targets * EXT_ROUNDS * TL_JUDGMENTS_PER_ROUND,
    rho_generating = EXT_RHO, beta_generating = EXT_RHO * TL_SD_LEARNING,
    mean_learning_generating = TL_MEAN_LEARNING, sd_user_learning = TL_SD_LEARNING,
    sd_user_target_learning = 0, replication = rep_id, seed = seed,
    beta_estimated = unname(z$beta), beta_se = unname(z$beta_se), beta_p = unname(z$beta_p),
    mean_learning_estimated = unname(z$mean_learning),
    mean_learning_se = unname(z$mean_learning_se), mean_learning_p = unname(z$mean_learning_p),
    convergence = z$convergence, pdHess = z$pdHess, n_aggregated_rows = z$n_aggregated_rows,
    elapsed_seconds = unname(tm["elapsed"]), warnings = paste(s$warnings, collapse = " | "),
    error = s$error, stringsAsFactors = FALSE)
}
audit_rows <- function(x) {
  !valid_test(x$beta_estimated, x$beta_se, x$beta_p) |
    is.na(x$convergence) | x$convergence != 0 | is.na(x$pdHess) | !x$pdHess |
    nzchar(x$warnings)
}
SUMMARY_NOTE <- "Clean rates follow Script 21 and are conditional on usable fits; exclusions are reported. Generating beta is metadata, not a bias benchmark for the aggregated fit."

# Separate checkpoints; each completed attempt (including failed fits) is saved.
# Increasing N_REP adds replications. Changing scientific inputs stops resumption.
stopifnot(length(N_REP) == 1L, N_REP >= 1L, N_REP < 100000L)
output_dir <- here::here("output", "tables")
checkpoint_dir <- here::here("output", "checkpoints", RUN_NAME)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
raw_file <- file.path(output_dir, paste0(RUN_NAME, "_raw.csv"))
summary_file <- file.path(output_dir, paste0(RUN_NAME, "_summary.csv"))
audit_file <- file.path(output_dir, paste0(RUN_NAME, "_fit_audit.csv"))
input_files <- unique(c(source_files, calibration_files))
if (any(!file.exists(input_files))) stop("Missing inputs: ",
  paste(input_files[!file.exists(input_files)], collapse = ", "))
# Includes loaded config/helper/calibration bytes and the local analysis functions.
run_environment <- environment()
function_names <- ls(envir = run_environment)
function_names <- function_names[vapply(function_names, function(nm)
  is.function(get(nm, envir = run_environment, inherits = FALSE)), logical(1))]
function_code <- lapply(function_names, function(nm)
  paste(deparse(get(nm, envir = run_environment, inherits = FALSE)), collapse = "\n"))
names(function_code) <- function_names
signature <- list(version = 1L, hashes = unname(tools::md5sum(input_files)),
                  settings = settings, functions = function_code)
manifest <- file.path(checkpoint_dir, "settings.rds")
if (file.exists(manifest)) {
  if (!identical(readRDS(manifest), signature))
    stop("Inputs, model or settings changed. Use a new RUN_NAME; existing results are preserved.")
} else {
  saveRDS(signature, manifest)
}
capture.output(sessionInfo(), file = file.path(checkpoint_dir, "session_info_latest.txt"))
rows <- list()
started <- Sys.time()
cat("\n", RUN_NAME, " | ", N_REP, " replications | effect-only extension\n", sep = "")
print(settings)
for (rep_id in seq_len(N_REP)) {
  seed <- settings$seed_base + rep_id
  checkpoint <- file.path(checkpoint_dir, sprintf("rep_%05d.rds", rep_id))
  if (file.exists(checkpoint)) {
    row <- readRDS(checkpoint)
    if (!is.data.frame(row) || nrow(row) != 1L ||
        !identical(as.integer(row$replication), as.integer(rep_id)) ||
        !identical(as.integer(row$seed), as.integer(seed)))
      stop("Invalid checkpoint: ", checkpoint)
  } else {
    # Generation errors stop the run; completed earlier fits remain available.
    row <- run_one(rep_id, seed)
    stopifnot(is.data.frame(row), nrow(row) == 1L)
    temporary <- paste0(checkpoint, ".tmp")
    saveRDS(row, temporary)
    if (!file.rename(temporary, checkpoint)) stop("Cannot save: ", checkpoint)
    cat(rep_id, "/", N_REP, " | fit=", round(row$elapsed_seconds, 1),
        "s | elapsed=", round(as.numeric(difftime(Sys.time(), started, units="mins")), 1),
        "min\n", sep = "")
  }
  rows[[rep_id]] <- row
  # CSV exports are disposable views of the authoritative per-replication RDS files.
  results <- do.call(rbind, rows)
  write.csv(results, raw_file, row.names = FALSE)
  write.csv(summarize_results(results), summary_file, row.names = FALSE)
}
# Include all saved replications even if N_REP was subsequently reduced.
saved <- list.files(checkpoint_dir, pattern = "^rep_[0-9]+[.]rds$", full.names = TRUE)
results <- do.call(rbind, lapply(saved, readRDS))
results <- results[order(results$replication), , drop = FALSE]
summary_out <- summarize_results(results)
write.csv(results, raw_file, row.names = FALSE)
write.csv(summary_out, summary_file, row.names = FALSE)
write.csv(results[audit_rows(results), , drop = FALSE], audit_file, row.names = FALSE)
cat("\nSUMMARY\n")
print(summary_out, row.names = FALSE)
cat("\n", SUMMARY_NOTE, "\nNo null rejection rate is estimated by this extension.\n", sep = "")
cat("Raw results: ", raw_file, "\nSummary: ", summary_file,
    "\nFit audit: ", audit_file, "\nRerun this script to resume.\n", sep = "")

})()
