# ==============================================================================
# scripts/08_run_bfi_moderation_monte_carlo.R
# Simulation 2: baseline negativity as moderator of distinctive accuracy
# ==============================================================================

source(here::here("config.R"))
source(here::here("config_bfi_accuracy.R"))
source(here::here("helpers", "generate_design.R"))
source(here::here("helpers", "generate_bfi_design.R"))
source(here::here("helpers", "simulate_bfi_moderation.R"))

if (!requireNamespace("lme4", quietly = TRUE)) {
  stop(
    "Package 'lme4' is required. ",
    "Install it with install.packages('lme4')."
  )
}


# ------------------------------------------------------------------------------
# Run mode
# ------------------------------------------------------------------------------

# Start with "dev". If recovery and Type-I error look clean, switch to "final".
#
# "pilot" = 1 replication per cell
# "dev"   = 25 replications per cell
# "final" = 200 replications per cell
RUN_MODE <- "final"

N_REP <- switch(
  RUN_MODE,
  pilot = BFI_N_REP_PILOT,
  dev = BFI_N_REP_DEV,
  final = BFI_N_REP_FINAL,
  stop("RUN_MODE must be 'pilot', 'dev', or 'final'.")
)


# ------------------------------------------------------------------------------
# Parallel settings
# ------------------------------------------------------------------------------

N_LOGICAL_CORES <- parallel::detectCores(logical = TRUE)

if (is.na(N_LOGICAL_CORES)) {
  N_LOGICAL_CORES <- 4L
}

MAX_WORKERS <- 10L

N_WORKERS <- max(
  1L,
  min(MAX_WORKERS, N_LOGICAL_CORES - 2L)
)

BATCH_SIZE <- max(N_WORKERS, 2L * N_WORKERS)


# ------------------------------------------------------------------------------
# Design scenarios
# ------------------------------------------------------------------------------

# Same design grid as Simulations 1 and the earlier Simulation 2 attempt.
design_scenarios <- data.frame(
  scenario = c(
    "lower_n",
    "baseline",
    "higher_n",
    "lower_engagement",
    "higher_engagement"
  ),
  n_users = c(
    500L,
    1000L,
    1500L,
    1000L,
    1000L
  ),
  engagement_scale = c(
    1,
    1,
    1,
    2 / 3,
    1.5
  ),
  stringsAsFactors = FALSE
)

rho_scenarios <- BFI_RHO_NEGATIVITY_ACCURACY


# ------------------------------------------------------------------------------
# Output/checkpoint files
# ------------------------------------------------------------------------------

dir.create(
  here::here("data", "cache"),
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  here::here("output", "tables"),
  recursive = TRUE,
  showWarnings = FALSE
)

checkpoint_file <- here::here(
  "data",
  "cache",
  "bfi_moderation_monte_carlo_checkpoint.rds"
)

raw_output_file <- here::here(
  "output",
  "tables",
  "bfi_moderation_monte_carlo_raw.csv"
)

summary_output_file <- here::here(
  "output",
  "tables",
  "bfi_moderation_monte_carlo_summary.csv"
)


# ------------------------------------------------------------------------------
# Fixed calibration objects
# ------------------------------------------------------------------------------

item_parameters <- read.csv(
  BFI_ITEM_PARAMETERS_FILE,
  stringsAsFactors = FALSE
)

target_responses <- read.csv(
  BFI_TARGET_RESPONSES_FILE,
  stringsAsFactors = FALSE
)


# ------------------------------------------------------------------------------
# Helper for extracting the focal fixed interaction
# ------------------------------------------------------------------------------

extract_focal_beta <- function(fit) {

  b <- lme4::fixef(fit)

  candidates <- c(
    "negativity_z:criterion_z",
    "criterion_z:negativity_z"
  )

  hit <- candidates[candidates %in% names(b)]

  if (length(hit) != 1L) {
    return(NA_real_)
  }

  unname(b[hit])
}


# ------------------------------------------------------------------------------
# One-replication helper
# ------------------------------------------------------------------------------

run_one_bfi_moderation_replication <- function(
  scenario_name,
  n_users,
  engagement_scale,
  rho,
  replication,
  seed,
  item_parameters,
  target_responses
) {

  set.seed(seed)

  # --------------------------------------------------------------------------
  # Generate sparse design and simulated judgments
  # --------------------------------------------------------------------------

  design <- generate_bfi_design(
    n_users = n_users,
    target_responses = target_responses,
    engagement_scale = engagement_scale
  )

  round_counts <- attr(design, "round_counts")

  dat <- simulate_bfi_moderation(
    design = design,
    item_parameters = item_parameters,
    rho_negativity_accuracy = rho,
    keep_components = FALSE
  )

  beta_generating <- attr(dat, "beta_negativity_accuracy")

  rm(design)

  dat$user_id <- factor(dat$user_id)
  dat$item_id <- factor(dat$item_id)

  # --------------------------------------------------------------------------
  # Analysis model
  #
  # Negativity is now an independently measured person-level predictor.
  # The focal parameter is negativity_z x criterion_z.
  #
  # negativity_z x desirability_z is retained so that the ordinary evaluative
  # manifestation of negativity does not get conflated with accuracy.
  #
  # The user intercept and residual criterion slope are fitted as uncorrelated
  # nuisance random effects; their covariance is not a substantive target.
  # --------------------------------------------------------------------------

  formula_full <- (
    judgment ~
      item_id +
      negativity_z +
      criterion_z +
      negativity_z:desirability_z +
      negativity_z:criterion_z +
      (1 + criterion_z || user_id)
  )

  formula_reduced <- (
    judgment ~
      item_id +
      negativity_z +
      criterion_z +
      negativity_z:desirability_z +
      (1 + criterion_z || user_id)
  )

  control <- lme4::lmerControl(
    optimizer = "bobyqa",
    optCtrl = list(maxfun = 100000)
  )

  warning_messages <- character(0)
  error_message <- NA_character_

  fit_reduced <- NULL
  fit_full <- NULL

  elapsed <- system.time({

    fits <- tryCatch(
      withCallingHandlers(
        {
          fit_reduced_local <- lme4::lmer(
            formula_reduced,
            data = dat,
            REML = FALSE,
            control = control
          )

          fit_full_local <- lme4::lmer(
            formula_full,
            data = dat,
            REML = FALSE,
            control = control
          )

          list(
            reduced = fit_reduced_local,
            full = fit_full_local
          )
        },
        warning = function(w) {
          warning_messages <<- c(
            warning_messages,
            conditionMessage(w)
          )
          invokeRestart("muffleWarning")
        }
      ),
      error = function(e) {
        error_message <<- conditionMessage(e)
        NULL
      }
    )

    if (!is.null(fits)) {
      fit_reduced <- fits$reduced
      fit_full <- fits$full
    }

  })["elapsed"]

  # --------------------------------------------------------------------------
  # Failed fit
  # --------------------------------------------------------------------------

  if (is.null(fit_reduced) || is.null(fit_full)) {

    return(data.frame(
      scenario = scenario_name,
      n_users = n_users,
      engagement_scale = engagement_scale,
      rho_generating = rho,
      beta_generating = beta_generating,
      replication = replication,
      seed = seed,
      n_judgments = nrow(dat),
      mean_rounds = mean(round_counts),
      median_rounds = median(round_counts),
      beta_estimated = NA_real_,
      lrt_chisq = NA_real_,
      lrt_p = NA_real_,
      reject_05 = NA,
      mean_accuracy_slope_est = NA_real_,
      sd_accuracy_residual_est = NA_real_,
      residual_sd_est = NA_real_,
      singular_full = NA,
      singular_reduced = NA,
      elapsed_seconds = as.numeric(elapsed),
      n_warnings = length(unique(warning_messages)),
      warnings = paste(unique(warning_messages), collapse = " | "),
      error = error_message,
      stringsAsFactors = FALSE
    ))
  }

  # --------------------------------------------------------------------------
  # Extract focal interaction and likelihood-ratio test
  # --------------------------------------------------------------------------

  beta_estimated <- extract_focal_beta(fit_full)

  lrt <- tryCatch(
    anova(fit_reduced, fit_full, refit = FALSE),
    error = function(e) NULL
  )

  if (!is.null(lrt) && nrow(lrt) >= 2L) {
    lrt_chisq <- lrt$Chisq[2]
    lrt_p <- lrt$`Pr(>Chisq)`[2]
  } else {
    lrt_chisq <- NA_real_
    lrt_p <- NA_real_
  }

  fixed_effects <- lme4::fixef(fit_full)

  mean_accuracy_slope_est <- if (
    "criterion_z" %in% names(fixed_effects)
  ) {
    unname(fixed_effects["criterion_z"])
  } else {
    NA_real_
  }

  vc <- as.data.frame(lme4::VarCorr(fit_full))

  slope_row <- vc[
    vc$var1 == "criterion_z" &
      is.na(vc$var2),
    ,
    drop = FALSE
  ]

  sd_accuracy_residual_est <- if (nrow(slope_row) == 1L) {
    slope_row$sdcor[1]
  } else {
    NA_real_
  }

  data.frame(
    scenario = scenario_name,
    n_users = n_users,
    engagement_scale = engagement_scale,
    rho_generating = rho,
    beta_generating = beta_generating,
    replication = replication,
    seed = seed,
    n_judgments = nrow(dat),
    mean_rounds = mean(round_counts),
    median_rounds = median(round_counts),
    beta_estimated = beta_estimated,
    lrt_chisq = lrt_chisq,
    lrt_p = lrt_p,
    reject_05 = !is.na(lrt_p) && lrt_p < .05,
    mean_accuracy_slope_est = mean_accuracy_slope_est,
    sd_accuracy_residual_est = sd_accuracy_residual_est,
    residual_sd_est = sigma(fit_full),
    singular_full = lme4::isSingular(fit_full),
    singular_reduced = lme4::isSingular(fit_reduced),
    elapsed_seconds = as.numeric(elapsed),
    n_warnings = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    error = NA_character_,
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# Build complete job grid
# ------------------------------------------------------------------------------

job_grid <- merge(
  design_scenarios,
  data.frame(
    rho = rho_scenarios,
    stringsAsFactors = FALSE
  ),
  by = NULL
)

# Stable cell ID before expanding replications. This keeps seeds stable when
# moving from pilot -> dev -> final.
job_grid$cell_id <- seq_len(nrow(job_grid))

job_grid <- job_grid[
  rep(seq_len(nrow(job_grid)), each = N_REP),
  ,
  drop = FALSE
]

job_grid$replication <- rep(
  seq_len(N_REP),
  times = nrow(job_grid) / N_REP
)

job_grid$seed <- (
  SEED_BFI_SIMULATION +
    800000L +
    job_grid$cell_id * 10000L +
    job_grid$replication
)

job_grid$job_id <- paste(
  job_grid$scenario,
  sprintf("rho_%0.2f", job_grid$rho),
  sprintf("rep_%04d", job_grid$replication),
  sep = "__"
)


# ------------------------------------------------------------------------------
# Restore completed jobs from checkpoint
# ------------------------------------------------------------------------------

if (file.exists(checkpoint_file)) {
  completed <- readRDS(checkpoint_file)
} else {
  completed <- data.frame()
}

if (nrow(completed) > 0L && "job_id" %in% names(completed)) {
  remaining <- job_grid[
    !job_grid$job_id %in% completed$job_id,
    ,
    drop = FALSE
  ]
} else {
  remaining <- job_grid
}

cat("\nSimulation 2: negativity moderation of distinctive accuracy\n")
cat("-----------------------------------------------------------\n")
cat("Run mode:         ", RUN_MODE, "\n", sep = "")
cat("Replications/cell:", N_REP, "\n", sep = "")
cat("Workers:          ", N_WORKERS, "\n", sep = "")
cat("Total jobs:       ", nrow(job_grid), "\n", sep = "")
cat("Already done:     ", nrow(job_grid) - nrow(remaining), "\n", sep = "")
cat("Remaining:        ", nrow(remaining), "\n\n", sep = "")


# ------------------------------------------------------------------------------
# Parallel execution
# ------------------------------------------------------------------------------

if (nrow(remaining) > 0L) {

  cl <- parallel::makeCluster(N_WORKERS)

  on.exit(
    try(parallel::stopCluster(cl), silent = TRUE),
    add = TRUE
  )

  parallel::clusterEvalQ(cl, {
    library(lme4)
    library(here)
    NULL
  })

  project_root <- here::here()

  parallel::clusterExport(
    cl,
    varlist = c("project_root"),
    envir = environment()
  )

  parallel::clusterEvalQ(cl, {
    source(file.path(project_root, "config.R"))
    source(file.path(project_root, "config_bfi_accuracy.R"))
    source(file.path(project_root, "helpers", "generate_design.R"))
    source(file.path(project_root, "helpers", "generate_bfi_design.R"))
    source(file.path(project_root, "helpers", "simulate_bfi_moderation.R"))
    NULL
  })

  parallel::clusterExport(
    cl,
    varlist = c(
      "run_one_bfi_moderation_replication",
      "extract_focal_beta",
      "item_parameters",
      "target_responses"
    ),
    envir = environment()
  )

  batch_starts <- seq.int(
    1L,
    nrow(remaining),
    by = BATCH_SIZE
  )

  for (batch_start in batch_starts) {

    batch_end <- min(
      batch_start + BATCH_SIZE - 1L,
      nrow(remaining)
    )

    batch <- remaining[
      batch_start:batch_end,
      ,
      drop = FALSE
    ]

    batch_jobs <- split(
      batch,
      seq_len(nrow(batch))
    )

    batch_results <- parallel::parLapplyLB(
      cl,
      batch_jobs,
      function(job) {

        result <- run_one_bfi_moderation_replication(
          scenario_name = job$scenario,
          n_users = job$n_users,
          engagement_scale = job$engagement_scale,
          rho = job$rho,
          replication = job$replication,
          seed = job$seed,
          item_parameters = item_parameters,
          target_responses = target_responses
        )

        result$job_id <- job$job_id
        result
      }
    )

    batch_results <- do.call(
      rbind,
      batch_results
    )

    if (nrow(completed) == 0L) {
      completed <- batch_results
    } else {
      completed <- rbind(
        completed,
        batch_results
      )
    }

    saveRDS(
      completed,
      checkpoint_file
    )

    write.csv(
      completed,
      raw_output_file,
      row.names = FALSE
    )

    cat(
      "Completed ",
      nrow(completed),
      " / ",
      nrow(job_grid),
      " jobs\n",
      sep = ""
    )
  }

  parallel::stopCluster(cl)
}


# ------------------------------------------------------------------------------
# Final raw output
# ------------------------------------------------------------------------------

completed <- completed[
  order(
    completed$scenario,
    completed$rho_generating,
    completed$replication
  ),
]

write.csv(
  completed,
  raw_output_file,
  row.names = FALSE
)

saveRDS(
  completed,
  checkpoint_file
)


# ------------------------------------------------------------------------------
# Cell-level summary
# ------------------------------------------------------------------------------

summarize_cell <- function(dat) {

  usable_beta <- is.finite(dat$beta_estimated)
  usable_test <- is.finite(dat$lrt_p)

  data.frame(
    n_rep = nrow(dat),
    n_beta_usable = sum(usable_beta),
    n_test_usable = sum(usable_test),

    mean_n_judgments = mean(
      dat$n_judgments,
      na.rm = TRUE
    ),

    mean_rounds = mean(
      dat$mean_rounds,
      na.rm = TRUE
    ),

    beta_generating = dat$beta_generating[1],

    mean_beta_estimated = mean(
      dat$beta_estimated[usable_beta],
      na.rm = TRUE
    ),

    bias_beta = mean(
      dat$beta_estimated[usable_beta] -
        dat$beta_generating[usable_beta],
      na.rm = TRUE
    ),

    rmse_beta = sqrt(
      mean(
        (
          dat$beta_estimated[usable_beta] -
            dat$beta_generating[usable_beta]
        )^2,
        na.rm = TRUE
      )
    ),

    rejection_rate_05 = mean(
      dat$lrt_p[usable_test] < .05,
      na.rm = TRUE
    ),

    mean_accuracy_slope_est = mean(
      dat$mean_accuracy_slope_est,
      na.rm = TRUE
    ),

    mean_sd_accuracy_residual_est = mean(
      dat$sd_accuracy_residual_est,
      na.rm = TRUE
    ),

    singular_full_rate = mean(
      dat$singular_full,
      na.rm = TRUE
    ),

    mean_elapsed_seconds = mean(
      dat$elapsed_seconds,
      na.rm = TRUE
    )
  )
}


summary_list <- lapply(
  split(
    completed,
    interaction(
      completed$scenario,
      completed$rho_generating,
      drop = TRUE
    )
  ),
  function(dat) {

    out <- summarize_cell(dat)

    data.frame(
      scenario = dat$scenario[1],
      n_users = dat$n_users[1],
      engagement_scale = dat$engagement_scale[1],
      rho_generating = dat$rho_generating[1],
      out,
      row.names = NULL
    )
  }
)

summary_results <- do.call(
  rbind,
  summary_list
)

summary_results <- summary_results[
  order(
    match(
      summary_results$scenario,
      design_scenarios$scenario
    ),
    summary_results$rho_generating
  ),
]

rownames(summary_results) <- NULL

write.csv(
  summary_results,
  summary_output_file,
  row.names = FALSE
)


# ------------------------------------------------------------------------------
# Print key results
# ------------------------------------------------------------------------------

print(
  summary_results[, c(
    "scenario",
    "n_users",
    "engagement_scale",
    "rho_generating",
    "beta_generating",
    "n_test_usable",
    "mean_beta_estimated",
    "bias_beta",
    "rejection_rate_05",
    "singular_full_rate",
    "mean_elapsed_seconds"
  )],
  row.names = FALSE
)

cat("\nRaw results:     ", raw_output_file, "\n", sep = "")
cat("Summary results: ", summary_output_file, "\n", sep = "")
cat("Checkpoint:      ", checkpoint_file, "\n", sep = "")
