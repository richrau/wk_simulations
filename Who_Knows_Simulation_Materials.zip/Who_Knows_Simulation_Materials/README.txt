WHO KNOWS FOLLOW UP PROJECT
Simulation materials | October 2026

Start with Who_Knows_Simulation_Technical_Report.pdf. It describes the generating
models, analyses, design grid, sensitivity conditions and final power estimates.
The CSV files contain saved simulation outputs, not participant-level simulated
trials. No simulations need to be run to read or inspect the reported results.

FINAL PLANNING RESULTS

All four conditions below used 200 usable replications with no fit exclusions.
Power is the proportion of tests with p < .05, conditional on the stated design.

- Distinctive personality accuracy: N=3,000, tripled ordinary engagement,
  mean 51.02 BFI judgments per participant, rho=.20: power .945, MCSE .0161.
- Pre-feedback metacognitive sensitivity: N=1,500, 20 rounds, rho=.20:
  power .935, MCSE .0174.
- Feedback effect: N=1,750, 20 rounds per phase, delta=.10:
  power .965, MCSE .0130.
- Target learning: N=2,000, 10 targets, 5 rounds per target, rho=.20:
  power .955, MCSE .0147.

The metacognition recruitment target is 1,750 completers, set by the feedback
analysis. Pre-feedback power was simulated separately at N=1,500. These module
samples may overlap with one another and with the ordinary-use sample. Larger
sample extensions evaluated nonzero effects only. No evaluative-updating or
liking simulation was conducted.

CONTENTS AND FILE MAP

config*.R             Shared and outcome-specific parameters.
helpers/              Design and outcome generators used by the retained runs.
data/calibration/     Fixed availability and item properties, correctness
                      calibration, BFI item weights and target self-reports.
scripts/              Analysis scripts, with original numbering retained.
output/tables/        Replication-level results, summaries and available audits.

Scripts and corresponding result prefixes in output/tables/:

04  correctness_monte_carlo
08  bfi_moderation_monte_carlo
09  bfi_moderation_engagement_extension
10  bfi_moderation_final_power_check
14  metacognition_final_pre / metacognition_final_feedback /
    metacognition_final_summary
15  Adds delta=.20 to metacognition_final_feedback_raw.csv and writes
    metacognition_final_summary_reported.csv.
19  target_learning_final
20  Reads the target-learning results and writes summary_clean / excluded_fits;
    no model fitting.
21  target_learning_extensions
22  bfi_power_extension_n3000_engagement3x_fixed
23  Two files, explicitly named n1500 and n1750, for the corresponding
    feedback_power_extension_n1500 / feedback_power_extension_n1750 outputs.
24  target_learning_power_extension_n2000
25  metacognition_pre_power_extension_n1500

Script 01 can recreate the fixed availability and item-property objects and
produce design checks. These objects are already supplied; running it is not
necessary. Script 13 and its two aggregated pilot raw files are retained for
provenance: Script 14 reused 163 pre-feedback and 10 feedback pilot rows. These
rows also appear in the final raw files and must not be counted twice. Other
pilot runs and superseded models are omitted.

INTERPRETING THE SAVED TABLES

- Names containing raw identify one row per replication. Summary files combine
  replications within conditions. Fit-audit files may contain only a header
  when there are no flagged fits.
- The two metacognition_final_summary files overlap. The original includes
  feedback delta=.05; the reported version instead includes delta=.20. The
  final feedback raw file contains all four deltas (0, .05, .10, .20), and the
  report presents all of them. These are not independent simulation batches.
- Use target_learning_final_summary_clean.csv for reported initial target-
  learning rates; the original summary is preserved for transparency. Five
  robustness fits were excluded for non-positive-definite Hessians.
- Legacy bias columns in aggregated metacognition/target-learning outputs
  subtract generating conditional coefficients from coefficients of a model
  that averages over heterogeneity. They are not interpreted as direct bias
  estimates in the report.
- BFI likelihood-ratio tests retain singular fits when the p-value is finite.
  The final N=3,000 run had no singular fits or optimizer failures. Clean module
  summaries require convergence code zero, a positive-definite Hessian, finite
  coefficient and SE (SE > 0), and a valid p-value.

RUNNING THE CODE

Use R with packages here, glmmTMB and lme4 installed. Open simulation.Rproj in
RStudio (or set the working directory to this package root), then source the
chosen script, e.g.:

  source("scripts/22_run_bfi_power_extension_n3000.R")

Run in a working copy if preserving the archived outputs. The scripts write
results and, in several cases, resume from separate checkpoint files. Original
checkpoint directories and software-session logs are not included here; a
script that relies on checkpoints may rerun even when its CSV output exists.
R and package versions from the original runs are not pinned in this archive.
Seeds are specified in the scripts/configuration and recorded in many raw files.
Scripts 14 and 15 also resume from CSVs; their pilot-row reuse is documented
above. Run 19 before 20 when regenerating target-learning results, and 14 before
15 when regenerating the initial metacognition results. The larger-sample
extension scripts can be run independently with the supplied inputs.

Input helpers and configs retain their original numerical settings and file
bytes. Some comments describe earlier development settings; scenario-specific
values in each Monte Carlo script determine the run. The full historical
judgment dataset is not required because the calibrated inputs are provided.

ARCHIVE NOTES

The corrected Script 22 and its engagement3x_fixed results are the definitive
N=3,000 BFI extension. The superseded N=3,000 output labelled engagement_scale=3
but realizing only 17.85 rounds per participant is omitted; it did not simulate
the intended tripled engagement condition.

The uploaded feedback script was named n1500 but configured for N=1,750. It is
archived under the matching n1750 filename. The original N=1,500 script is also
included; the two versions differ only in sample size and associated labels.

Saved rejection rates and usable-fit counts were checked against replication-
level CSVs during assembly. Numerical result files were not changed and no
models were refitted. The technical report updates the earlier planning
version to the final sample-size extensions.

Item desirability source: Seitz, Wetzel, Hilbig and Meiser (2024), Behavior
Research Methods, 56, 8869-8896. DOI: 10.3758/s13428-024-02509-x.
The exact 30-item weights and mapping are in bfi30_item_parameters.csv.
