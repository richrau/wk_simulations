# ==============================================================================
# config_target_learning.R
# Simulation 4: target-specific learning
# ==============================================================================
#
# Assumes config.R has already been sourced.


# ------------------------------------------------------------------------------
# Calibration files from Simulation 1
# ------------------------------------------------------------------------------

TL_AVAILABILITY_FILE <- here::here(
  "data",
  "calibration",
  "availability_matrix.rds"
)

TL_ITEM_PROPERTIES_FILE <- here::here(
  "data",
  "calibration",
  "item_properties.rds"
)


# ------------------------------------------------------------------------------
# Working target-learning module
# ------------------------------------------------------------------------------

TL_JUDGMENTS_PER_ROUND <- JUDGMENTS_PER_ROUND

# Current proposal design.
TL_TARGETS_MAIN <- 10L
TL_ROUNDS_PER_TARGET_MAIN <- 5L

# Participants have completed at least 20 ordinary Who Knows rounds before
# becoming eligible for a project-specific module.
TL_PRIOR_NORMAL_ROUNDS <- 20L


# ------------------------------------------------------------------------------
# Learning DGP
# ------------------------------------------------------------------------------

# Progress is scaled 0...1 within each target, so these coefficients represent
# the full first-to-last-round change on the logit scale.

# Mean target-specific improvement from first to last round.
# Scenario assumption; not treated as an empirically known effect.
TL_MEAN_LEARNING <- 0.20

# Between-person SD in target-specific learning.
# Scenario assumption. Together with rho this defines the focal
# negativity x learning interaction.
TL_SD_LEARNING <- 0.20

# Pilot association between baseline negativity and person-specific learning.
# rho = .20 corresponds to beta = .04 because TL_SD_LEARNING = .20.
TL_RHO_PILOT <- c(
  0.00,
  0.20
)


# ------------------------------------------------------------------------------
# Decision-focused pilot designs
# ------------------------------------------------------------------------------

# Three plausible module variants:
#   lean_targets:     5 targets x 5 rounds = 125 judgments
#   short_repetition: 10 targets x 3 rounds = 150 judgments
#   current:          10 targets x 5 rounds = 250 judgments

TL_PILOT_DESIGNS <- data.frame(
  design = c(
    "lean_targets",
    "short_repetition",
    "current"
  ),
  n_targets = c(
    5L,
    10L,
    10L
  ),
  rounds_per_target = c(
    5L,
    3L,
    5L
  ),
  stringsAsFactors = FALSE
)

TL_PILOT_N_USERS <- c(
  500L,
  1000L
)

TL_N_REP_PILOT <- 5L


# ------------------------------------------------------------------------------
# Reproducibility
# ------------------------------------------------------------------------------

SEED_TARGET_LEARNING <- 20260929L
