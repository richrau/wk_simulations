# ==============================================================================
# config_metacognition.R
# Simulation 3: three-point confidence and metacognitive sensitivity
# ==============================================================================
#
# This file assumes config.R has already been sourced.


# ------------------------------------------------------------------------------
# Calibration files from Simulation 1
# ------------------------------------------------------------------------------

META_AVAILABILITY_FILE <- here::here(
  "data",
  "calibration",
  "availability_matrix.rds"
)

META_ITEM_PROPERTIES_FILE <- here::here(
  "data",
  "calibration",
  "item_properties.rds"
)


# ------------------------------------------------------------------------------
# Three-point confidence scale
# ------------------------------------------------------------------------------

META_CONFIDENCE_MIN <- 1L
META_CONFIDENCE_MAX <- 3L

# Confidence is generated from a latent continuous tendency and then cut into
# three categories. These values are scenario assumptions because Who Knows
# does not yet contain trial-level confidence data.
META_SD_GENERAL_CONFIDENCE <- 0.50
META_SD_TRIAL_CONFIDENCE <- 1.00

# Symmetric thresholds around zero. With no person effect this yields roughly
# 27% / 45% / 27% in the three categories.
META_CONFIDENCE_THRESHOLDS <- c(
  -0.60,
   0.60
)


# ------------------------------------------------------------------------------
# Metacognitive-sensitivity DGP
# ------------------------------------------------------------------------------

# Metacognitive sensitivity is defined in the same direction as the analysis:
# the within-person log-odds increase in correctness for a one-category increase
# in confidence.
META_MEAN_SENSITIVITY <- 0.30
META_SD_SENSITIVITY <- 0.20

META_RHO_NEGATIVITY_SENSITIVITY <- c(
  0.00,
  0.15,
  0.20,
  0.30
)

# Personalized-feedback effect on metacognitive sensitivity, expressed as an
# increment to the within-person confidence slope on the logit scale.
META_FEEDBACK_DELTAS <- c(
  0.00,
  0.05,
  0.10,
  0.15
)


# ------------------------------------------------------------------------------
# Planned module structure
# ------------------------------------------------------------------------------

META_JUDGMENTS_PER_ROUND <- JUDGMENTS_PER_ROUND

META_PRE_ROUNDS_MAIN <- 20L
META_POST_ROUNDS_MAIN <- 20L

META_N_USERS <- c(
  500L,
  1000L
)

META_ROUNDS_PER_PHASE <- c(
  10L,
  20L
)


# ------------------------------------------------------------------------------
# Monte Carlo settings
# ------------------------------------------------------------------------------

SEED_METACOGNITION <- 20260928L

META_N_REP_PILOT <- 1L
META_N_REP_DEV <- 25L
META_N_REP_FINAL <- 200L
